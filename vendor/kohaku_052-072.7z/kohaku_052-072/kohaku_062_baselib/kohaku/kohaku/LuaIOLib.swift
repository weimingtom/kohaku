//package kurumi;

//
// ** $Id: liolib.c,v 2.73.1.3 2008/01/18 17:47:43 roberto Exp $
// ** Standard I/O (and system) library
// ** See Copyright Notice in lua.h
//
//using lua_Number = System.Double;
//using lua_Integer = System.Int32;

public class LuaIOLib {

}

public class FilePtr {
    public var file:StreamProxy!
}

extension LuaIOLib {
    public static let IO_INPUT:Int = 1
    public static let IO_OUTPUT:Int = 2
    
    private static let fnames:[String] = [ "input", "output" ]

    
    private static func pushresult(L:lua_State!, i:Int, filename:CharPtr!) -> Int {
        let en:Int = CLib.errno() // calls to Lua API may change this value
        if (i != 0) {
            LuaAPI.lua_pushboolean(L: L, b: 1)
            return 1
        }
        else {
            LuaAPI.lua_pushnil(L: L)
            if (CharPtr.isNotEqual(ptr1: filename, ptr2: nil)) {
                _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: "%s: %s"), p: filename, CLib.strerror(error: en))
            }
            else {
                _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: "%s"), p: CLib.strerror(error: en))
            }
            LuaAPI.lua_pushinteger(L: L, n: en)
            return 3
        }
    }
    
    private static func fileerror(L:lua_State!, arg:Int, filename:CharPtr!) {
        _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: "%s: %s"), p: filename, CLib.strerror(error: CLib.errno()))
        _ = LuaAuxLib.luaL_argerror(L: L, narg: arg, extramsg: Lua.lua_tostring(L: L, i: -1))
    }
    
    public static func tofilep(L:lua_State!) -> FilePtr! {
        return LuaAuxLib.luaL_checkudata(L: L, ud: 1, tname: CharPtr.toCharPtr(str: LuaLib.LUA_FILEHANDLE)) as! FilePtr!
    }
    
    fileprivate static func io_type(L:lua_State!) -> Int {
        var ud:Any!
        LuaAuxLib.luaL_checkany(L: L, narg: 1);
        ud = LuaAPI.lua_touserdata(L: L, idx: 1);
        LuaAPI.lua_getfield(L: L, idx: Lua.LUA_REGISTRYINDEX, k: CharPtr.toCharPtr(str: LuaLib.LUA_FILEHANDLE))
        if (ud == nil || (LuaAPI.lua_getmetatable(L: L, objindex: 1) == 0) || (LuaAPI.lua_rawequal(L: L, index1: -2, index2: -1) == 0)) {
            LuaAPI.lua_pushnil(L: L) // not a file
        }
        else if (ud is FilePtr! && (ud as! FilePtr!).file == nil) {
            Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: "closed file"))
        }
        else {
            Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: "file"))
        }
        return 1
    }
    
    private static func tofile(L:lua_State!) -> StreamProxy! {
        let f:FilePtr! = tofilep(L: L)
        if (f.file == nil) {
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "attempt to use a closed file"))
        }
        return f.file
    }
    
    //
    //         ** When creating file files, always creates a `closed' file file
    //         ** before opening the actual file; so, if there is a memory error, the
    //         ** file is not left opened.
    //
    private static func newfile(L:lua_State!) -> FilePtr! {
        let pf:FilePtr! = LuaAPI.lua_newuserdata(L: L, t: ClassType(type: ClassType.TYPE_FILEPTR)) as! FilePtr! //FilePtr
        pf.file = nil // file file is currently `closed'
        LuaAuxLib.luaL_getmetatable(L: L, n: CharPtr.toCharPtr(str: LuaLib.LUA_FILEHANDLE))
        _ = LuaAPI.lua_setmetatable(L: L, objindex: -2)
        return pf
    }
    
    //
    //         ** function to (not) close the standard files stdin, stdout, and stderr
    //
    fileprivate static func io_noclose(L:lua_State!) -> Int {
        LuaAPI.lua_pushnil(L: L)
        Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: "cannot close standard file"))
        return 2
    }
    
    //
    //         ** function to close 'popen' files
    //
    fileprivate static func io_pclose(L:lua_State!) -> Int {
        let p:FilePtr! = tofilep(L: L)
        let ok:Int = (LuaConf.lua_pclose(L: L, file: p.file) == 0) ? 1 : 0;
        p.file = nil
        return pushresult(L: L, i: ok, filename: nil)
    }
    
    //
    //         ** function to close regular files
    //
    fileprivate static func io_fclose(L:lua_State!) -> Int {
        let p:FilePtr! = tofilep(L: L)
        let ok:Int = (CLib.fclose(stream: p.file) == 0) ? 1 : 0
        p.file = nil
        return pushresult(L: L, i: ok, filename: nil)
    }
    
    private static func aux_close(L:lua_State!) -> Int {
        LuaAPI.lua_getfenv(L: L, idx: 1)
        LuaAPI.lua_getfield(L: L, idx: -1, k: CharPtr.toCharPtr(str: "__close"))
        return (LuaAPI.lua_tocfunction(L: L, idx: -1)).exec(L: L)
    }
    
    fileprivate static func io_close(L:lua_State!) -> Int {
        if (Lua.lua_isnone(L: L, n: 1)) {
            LuaAPI.lua_rawgeti(L: L, idx: Lua.LUA_ENVIRONINDEX, n: IO_OUTPUT)
        }
        _ = tofile(L: L) // make sure argument is a file
        return aux_close(L: L)
    }
    
    fileprivate static func io_gc(L:lua_State!) -> Int {
        let f:StreamProxy! = tofilep(L: L).file
        // ignore closed files
        if (f != nil) {
            _ = aux_close(L: L)
        }
        return 0
    }
    
    fileprivate static func io_tostring(L:lua_State!) -> Int {
        let f:StreamProxy! = tofilep(L: L).file
        if (f == nil) {
            Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: "file (closed)"));
        }
        else {
            _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: "file (%p)"), p: f)
        }
        return 1
    }
    
    fileprivate static func io_open(L:lua_State!) -> Int {
        let filename:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 1);
        let mode:CharPtr! = LuaAuxLib.luaL_optstring(L: L, n: 2, d: CharPtr.toCharPtr(str: "r"));
        let pf:FilePtr! = newfile(L: L)
        pf.file = CLib.fopen(filename: filename, mode: mode);
        return (pf.file == nil) ? pushresult(L: L, i: 0, filename: filename) : 1
    }
    
    //
    //         ** this function has a separated environment, which defines the
    //         ** correct __close for 'popen' files
    //
    fileprivate static func io_popen(L:lua_State!) -> Int {
        let filename:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 1);
        let mode:CharPtr! = LuaAuxLib.luaL_optstring(L: L, n: 2, d: CharPtr.toCharPtr(str: "r"));
        let pf:FilePtr! = newfile(L: L)
        pf.file = LuaConf.lua_popen(L: L, c: filename, m: mode);
        return (pf.file == nil) ? pushresult(L: L, i: 0, filename: filename) : 1
    }
    
    fileprivate static func io_tmpfile(L:lua_State!) -> Int {
        let pf:FilePtr! = newfile(L: L)
        pf.file = CLib.tmpfile()
        return (pf.file == nil) ? pushresult(L: L, i: 0, filename: nil) : 1
    }
    
    private static func getiofile(L:lua_State!, findex:Int) -> StreamProxy! {
        var f:StreamProxy!
        LuaAPI.lua_rawgeti(L: L, idx: Lua.LUA_ENVIRONINDEX, n: findex);
        let tempVar:Any! = LuaAPI.lua_touserdata(L: L, idx: -1);
        f = (tempVar as! FilePtr!).file
        if (f == nil) {
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "standard %s file is closed"), p: fnames[findex - 1])
        }
        return f
    }
    
    private static func g_iofile(L:lua_State!, f:Int, mode:CharPtr!) -> Int {
        if (!Lua.lua_isnoneornil(L: L, n: 1)) {
            let filename:CharPtr! = Lua.lua_tostring(L: L, i: 1)
            if (CharPtr.isNotEqual(ptr1: filename, ptr2: nil)) {
                let pf:FilePtr! = newfile(L: L)
                pf.file = CLib.fopen(filename: filename, mode: mode);
                if (pf.file == nil) {
                    fileerror(L: L, arg: 1, filename: filename)
                }
            }
            else {
                _ = tofile(L: L) // check that it's a valid file file
                LuaAPI.lua_pushvalue(L: L, idx: 1);
            }
            LuaAPI.lua_rawseti(L: L, idx: Lua.LUA_ENVIRONINDEX, n: f);
        }
        // return current value
        LuaAPI.lua_rawgeti(L: L, idx: Lua.LUA_ENVIRONINDEX, n: f)
        return 1
    }
    
    fileprivate static func io_input(L:lua_State!) -> Int {
        return g_iofile(L: L, f: IO_INPUT, mode: CharPtr.toCharPtr(str: "r"))
    }
    
    fileprivate static func io_output(L:lua_State!) -> Int {
        return g_iofile(L: L, f: IO_OUTPUT, mode: CharPtr.toCharPtr(str: "w"))
    }
    
    private static func aux_lines(L:lua_State!, idx:Int, toclose:Int) {
        LuaAPI.lua_pushvalue(L: L, idx: idx)
        LuaAPI.lua_pushboolean(L: L, b: toclose) // close/not close file when finished
        LuaAPI.lua_pushcclosure(L: L, fn: LuaIOLib_delegate(name: "io_readline"), n: 2)
    }
    
    fileprivate static func f_lines(L:lua_State!) -> Int {
        _ = tofile(L: L) // check that it's a valid file file
        aux_lines(L: L, idx: 1, toclose: 0)
        return 1
    }
    
    fileprivate static func io_lines(L:lua_State!) -> Int {
        if (Lua.lua_isnoneornil(L: L, n: 1)) {
            // no arguments?
            // will iterate over default input
            LuaAPI.lua_rawgeti(L: L, idx: Lua.LUA_ENVIRONINDEX, n: IO_INPUT)
            return f_lines(L: L)
        }
        else {
            let filename:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 1)
            let pf:FilePtr! = newfile(L: L)
            pf.file = CLib.fopen(filename: filename, mode: CharPtr.toCharPtr(str: "r"))
            if (pf.file == nil) {
                fileerror(L: L, arg: 1, filename: filename)
            }
            aux_lines(L: L, idx: LuaAPI.lua_gettop(L: L), toclose: 1)
            return 1
        }
    }
    
    
    //
    //         ** {======================================================
    //         ** READ
    //         ** =======================================================
    //
    
    private static func read_number(L:lua_State!, f:StreamProxy!) -> Int {
        //lua_Number d;
        var parms:[Any?]! = [0.0]
        if (CLib.fscanf(f: f, format: CharPtr.toCharPtr(str: LuaConf.LUA_NUMBER_SCAN), argp: parms) == 1) {
            LuaAPI.lua_pushnumber(L: L, n: (parms[0] as! Double))
            return 1
        }
        else {
            return 0 // read fails
        }
    }
    
    private static func test_eof(L:lua_State!, f:StreamProxy!) -> Int {
        let c:Int = CLib.getc(f: f)
        CLib.ungetc(c: c, f: f)
        LuaAPI.lua_pushlstring(L: L, s: nil, len: 0)
        return (c != CLib.EOF) ? 1 : 0
    }
    
    private static func read_line(L:lua_State!, f:StreamProxy!) -> Int {
        let b:luaL_Buffer! = luaL_Buffer()
        LuaAuxLib.luaL_buffinit(L: L, B: b)
        while (true) {
            var l:Int; //uint
            let p:CharPtr! = LuaAuxLib.luaL_prepbuffer(B: b)
            if (CharPtr.isEqual(ptr1: CLib.fgets(str: p, stream: f), ptr2: nil)) {
                // eof?
                LuaAuxLib.luaL_pushresult(B: b) // close buffer
                return (LuaAPI.lua_objlen(L: L, idx: -1) > 0) ? 1 : 0; // check whether read something
            }
            l = Int(CLib.strlen(str: p)) //uint
            if (l == 0 || p.get(offset: l - 1) != "\n") {
                LuaAuxLib.luaL_addsize(B: b, n: Int(l))
            }
            else {
                LuaAuxLib.luaL_addsize(B: b, n: Int(l - 1)); // do not include `eol'
                LuaAuxLib.luaL_pushresult(B: b) // close buffer
                return 1 // read at least an `eol'
            }
        }
    }
    
    private static func read_chars(L:lua_State!, f:StreamProxy!, n:Int64) -> Int { //uint
        var n:Int64 = n;
        var rlen:Int64 // how much to read  - uint
        var nr:Int // number of chars actually read  - uint
        let b:luaL_Buffer! = luaL_Buffer()
        LuaAuxLib.luaL_buffinit(L: L, B: b)
        rlen = Int64(LuaConf.LUAL_BUFFERSIZE) // try to read that much each time
        repeat {
            let p:CharPtr! = LuaAuxLib.luaL_prepbuffer(B: b)
            if (rlen > n) {
                rlen = n; // cannot read more than asked
            }
            nr = Int(CLib.fread(ptr: p, size: CLib.GetUnmanagedSize(t: ClassType(type: ClassType.TYPE_CHAR)), num: Int(rlen), stream: f)) //typeof(char) - uint
            LuaAuxLib.luaL_addsize(B: b, n: Int(nr))
            n -= Int64(nr) // still have to read `n' chars
        } while (n > 0 && nr == rlen); // until end of count or eof
        LuaAuxLib.luaL_pushresult(B: b) // close buffer
        return (n == 0 || LuaAPI.lua_objlen(L: L, idx: -1) > 0) ? 1 : 0
    }
    
    private static func g_read(L:lua_State!, f:StreamProxy!, first:Int) -> Int {
        var nargs:Int = LuaAPI.lua_gettop(L: L) - 1
        var success:Int
        var n:Int
        _ = CLib.clearerr(f: f)
        if (nargs == 0) {
            // no arguments?
            success = read_line(L: L, f: f)
            n = first + 1; // to return 1 result
        }
        else {
            // ensure stack space for all results and for auxlib's buffer
            LuaAuxLib.luaL_checkstack(L: L, space: nargs + Lua.LUA_MINSTACK, mes: CharPtr.toCharPtr(str: "too many arguments"))
            success = 1;
            n = first
            while (true) {
                if (!((nargs != 0) && (success != 0))) {
                    nargs -= 1
                    break
                } else {
                    nargs -= 1
                }
                if (LuaAPI.lua_type(L: L, idx: n) == Lua.LUA_TNUMBER) {
                    let l:Int = Int(LuaAPI.lua_tointeger(L: L, idx: n)) //uint - uint
                    success = (l == 0) ? test_eof(L: L, f: f) : read_chars(L: L, f: f, n: Int64(l))
                }
                else {
                    let p:CharPtr! = Lua.lua_tostring(L: L, i: n)
                    LuaAuxLib.luaL_argcheck(L: L, cond: (CharPtr.isNotEqual(ptr1: p, ptr2: nil)) && (p.get(offset: 0) == "*"), numarg: n, extramsg: "invalid option");
                    switch (p.get(offset: 1)) {
                    case "n": // number
                        success = read_number(L: L, f: f)
                        break;
                        
                    case "l": // line
                        success = read_line(L: L, f: f)
                        break;
                        
                    case "a": // file
                        _ = read_chars(L: L, f: f, n: Int64((~Int64(0)) & 0xffffffff)) // read MAX_uint chars  - ~((uint)0
                        success = 1 // always success
                        break;
                        
                    default:
                        return LuaAuxLib.luaL_argerror(L: L, narg: n, extramsg: CharPtr.toCharPtr(str: "invalid format"))
                    }
                }
                n += 1
            }
        }
        if (CLib.ferror(stream: f) != 0) {
            return pushresult(L: L, i: 0, filename: nil)
        }
        if (success == 0) {
            Lua.lua_pop(L: L, n: 1) // remove last result
            LuaAPI.lua_pushnil(L: L) // push nil instead
        }
        return n - first
    }
    
    fileprivate static func io_read(L:lua_State!) -> Int {
        return g_read(L: L, f: getiofile(L: L, findex: IO_INPUT), first: 1)
    }
    
    fileprivate static func f_read(L:lua_State!) -> Int {
        return g_read(L: L, f: tofile(L: L), first: 2)
    }
    
    fileprivate static func io_readline(L:lua_State!) -> Int {
        let tempVar:Any = LuaAPI.lua_touserdata(L: L, idx: Lua.lua_upvalueindex(i: 1))
        let f:StreamProxy! = (tempVar is FilePtr) ? (tempVar as! FilePtr).file : nil
        var sucess:Int
        if (f == nil) { // file is already closed?
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "file is already closed"))
        }
        sucess = read_line(L: L, f: f)
        if (CLib.ferror(stream: f) != 0) {
            return LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "%s"), p: CLib.strerror(error: CLib.errno()));
        }
        if (sucess != 0) {
            return 1
        }
        else {
            // EOF
            if (LuaAPI.lua_toboolean(L: L, idx: Lua.lua_upvalueindex(i: 2)) != 0) {
                // generator created file?
                LuaAPI.lua_settop(L: L, idx: 0)
                LuaAPI.lua_pushvalue(L: L, idx: Lua.lua_upvalueindex(i: 1));
                _ = aux_close(L: L) // close it
            }
            return 0
        }
    }
    
    // }======================================================
    
    private static func g_write(L:lua_State!, f:StreamProxy!, arg:Int) -> Int {
        var arg:Int = arg
        var nargs:Int = LuaAPI.lua_gettop(L: L) - 1
        var status:Int = 1
        while (true) {
            if (!(nargs != 0)) {
                nargs -= 1
                break
            } else {
                nargs -= 1
            }
            if (LuaAPI.lua_type(L: L, idx: arg) == Lua.LUA_TNUMBER) {
                // optimization: could be done exactly as for strings
                status = ((status != 0) && (CLib.fprintf(stream: f, str: CharPtr.toCharPtr(str: LuaConf.LUA_NUMBER_FMT), argv: LuaAPI.lua_tonumber(L: L, idx: arg)) > 0)) ? 1 : 0;
            }
            else {
                var l:[Int] = [Int](repeating: 0, count: 1) //uint
                let s:CharPtr! = LuaAuxLib.luaL_checklstring(L: L, narg: arg, len: l); //out
                status = ((status != 0) && (CLib.fwrite(ptr: s, size: CLib.GetUnmanagedSize(t: ClassType(type: ClassType.TYPE_CHAR)), num: Int(l[0]), stream: f) == l[0])) ? 1 : 0; //typeof(char)
            }
            arg += 1
        }
        return pushresult(L: L, i: status, filename: nil)
    }
    
    fileprivate static func io_write(L:lua_State!) -> Int {
        return g_write(L: L, f: getiofile(L: L, findex: IO_OUTPUT), arg: 1)
    }
    
    fileprivate static func f_write(L:lua_State!) -> Int {
        return g_write(L: L, f: tofile(L: L), arg: 2)
    }
    
    fileprivate static func f_seek(L:lua_State!) -> Int {
        var mode:[Int] = [
            CLib.SEEK_SET,
            CLib.SEEK_CUR,
            CLib.SEEK_END
        ]
        let modenames:[CharPtr?]! = [
            CharPtr.toCharPtr(str: "set"),
            CharPtr.toCharPtr(str: "cur"),
            CharPtr.toCharPtr(str: "end"),
            nil
        ]
        let f:StreamProxy! = tofile(L: L)
        var op:Int = LuaAuxLib.luaL_checkoption(L: L, narg: 2, def: CharPtr.toCharPtr(str: "cur"), lst: modenames)
        let offset:Int64 = LuaAuxLib.luaL_optlong(L: L, n: 3, d: 0)
        op = CLib.fseek(f: f, offset: offset, origin: mode[op])
        if (op != 0) {
            return pushresult(L: L, i: 0, filename: nil) // error
        }
        else {
            LuaAPI.lua_pushinteger(L: L, n: CLib.ftell(f: f))
            return 1
        }
    }
    
    fileprivate static func f_setvbuf(L:lua_State!) -> Int {
        let modenames:[CharPtr?]! = [
            CharPtr.toCharPtr(str: "no"),
            CharPtr.toCharPtr(str: "full"),
            CharPtr.toCharPtr(str: "line"),
            nil
        ]
        var mode:[Int] = [ CLib._IONBF, CLib._IOFBF, CLib._IOLBF ]
        let f:StreamProxy! = tofile(L: L)
        let op:Int = LuaAuxLib.luaL_checkoption(L: L, narg: 2, def: nil, lst: modenames)
        let sz:Int = LuaAuxLib.luaL_optinteger(L: L, narg: 3, def: LuaConf.LUAL_BUFFERSIZE); //lua_Integer - Int32
        let res:Int = CLib.setvbuf(stream: f, buffer: nil, mode: mode[op], size: Int(sz)) //uint
        return pushresult(L: L, i: (res == 0) ? 1 : 0, filename: nil)
    }
    
    fileprivate static func io_flush(L:lua_State!) -> Int {
        let result:Int = 1
//        try {
        getiofile(L: L, findex: IO_OUTPUT).Flush()
//        }
//        catch (java.lang.Exception e) {
//        result = 0;
//        }
        return pushresult(L: L, i: result, filename: nil)
    }
    
    fileprivate static func f_flush(L:lua_State!) -> Int {
        let result:Int = 1
//        try {
        tofile(L: L).Flush()
//        }
//        catch (java.lang.Exception e) {
//        result = 0;
//        }
        return pushresult(L: L, i: result, filename: nil)
    }
    
    
    
    private static let iolib:[luaL_Reg] = [
        luaL_Reg(name: CharPtr.toCharPtr(str: "close"), func_: LuaIOLib_delegate(name: "io_close")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "flush"), func_: LuaIOLib_delegate(name: "io_flush")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "input"), func_: LuaIOLib_delegate(name: "io_input")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "lines"), func_: LuaIOLib_delegate(name: "io_lines")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "open"), func_: LuaIOLib_delegate(name: "io_open")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "output"), func_: LuaIOLib_delegate(name: "io_output")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "popen"), func_: LuaIOLib_delegate(name: "io_popen")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "read"), func_: LuaIOLib_delegate(name: "io_read")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "tmpfile"), func_: LuaIOLib_delegate(name: "io_tmpfile")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "type"), func_: LuaIOLib_delegate(name: "io_type")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "write"), func_: LuaIOLib_delegate(name: "io_write")),
        luaL_Reg(name: nil, func_: nil)
    ]
    
    private static let flib:[luaL_Reg] = [
        luaL_Reg(name: CharPtr.toCharPtr(str: "close"), func_: LuaIOLib_delegate(name: "io_close")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "flush"), func_: LuaIOLib_delegate(name: "f_flush")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "lines"), func_: LuaIOLib_delegate(name: "f_lines")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "read"), func_: LuaIOLib_delegate(name: "f_read")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "seek"), func_: LuaIOLib_delegate(name: "f_seek")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "setvbuf"), func_: LuaIOLib_delegate(name: "f_setvbuf")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "write"), func_: LuaIOLib_delegate(name: "f_write")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "__gc"), func_: LuaIOLib_delegate(name: "io_gc")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "__tostring"), func_: LuaIOLib_delegate(name: "io_tostring")),
        luaL_Reg(name: nil, func_: nil)
    ]
}

public class LuaIOLib_delegate: lua_CFunction {
    private var name:String!
    
    public init(name:String!) {
        self.name = name
    }
    
    public func exec(L:lua_State!) -> Int {
        if ("io_close" == name) {
            return LuaIOLib.io_close(L: L)
        }
        else if ("io_flush" == name) {
            return LuaIOLib.io_flush(L: L)
        }
        else if ("io_input" == name) {
            return LuaIOLib.io_input(L: L)
        }
        else if ("io_lines" == name) {
            return LuaIOLib.io_lines(L: L)
        }
        else if ("io_open" == name) {
            return LuaIOLib.io_open(L: L)
        }
        else if ("io_output" == name) {
            return LuaIOLib.io_output(L: L)
        }
        else if ("io_popen" == name) {
            return LuaIOLib.io_popen(L: L)
        }
        else if ("io_read" == name) {
            return LuaIOLib.io_read(L: L)
        }
        else if ("io_tmpfile" == name) {
            return LuaIOLib.io_tmpfile(L: L)
        }
        else if ("io_type" == name) {
            return LuaIOLib.io_type(L: L)
        }
        else if ("io_write" == name) {
            return LuaIOLib.io_write(L: L)
        }
        else if ("f_flush" == name) {
            return LuaIOLib.f_flush(L: L)
        }
        else if ("f_lines" == name) {
            return LuaIOLib.f_lines(L: L)
        }
        else if ("f_read" == name) {
            return LuaIOLib.f_read(L: L)
        }
        else if ("f_seek" == name) {
            return LuaIOLib.f_seek(L: L)
        }
        else if ("f_setvbuf" == name) {
            return LuaIOLib.f_setvbuf(L: L)
        }
        else if ("f_write" == name) {
            return LuaIOLib.f_write(L: L)
        }
        else if ("io_gc" == name) {
            return LuaIOLib.io_gc(L: L)
        }
        else if ("io_tostring" == name) {
            return LuaIOLib.io_tostring(L: L)
        }
        else if ("io_fclose" == name) {
            return LuaIOLib.io_fclose(L: L)
        }
        else if ("io_noclose" == name) {
            return LuaIOLib.io_noclose(L: L)
        }
        else if ("io_pclose" == name) {
            return LuaIOLib.io_pclose(L: L)
        }
        else if ("io_readline" == name) {
            return LuaIOLib.io_readline(L: L)
        }
        else {
            return 0
        }
    }
}

extension LuaIOLib {
    private static func createmeta(L:lua_State!) {
        _ = LuaAuxLib.luaL_newmetatable(L: L, tname: CharPtr.toCharPtr(str: LuaLib.LUA_FILEHANDLE)) // create metatable for file files
        LuaAPI.lua_pushvalue(L: L, idx: -1) // push metatable
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "__index")) // metatable.__index = metatable
        LuaAuxLib.luaL_register(L: L, libname: nil, l: flib) // file methods
    }
    
    private static func createstdfile(L:lua_State!, f:StreamProxy!, k:Int, fname:CharPtr!) {
        newfile(L: L).file = f
        if (k > 0) {
            LuaAPI.lua_pushvalue(L: L, idx: -1)
            LuaAPI.lua_rawseti(L: L, idx: Lua.LUA_ENVIRONINDEX, n: k)
        }
        LuaAPI.lua_pushvalue(L: L, idx: -2) // copy environment
        _ = LuaAPI.lua_setfenv(L: L, idx: -2) // set it
        LuaAPI.lua_setfield(L: L, idx: -3, k: fname)
    }
    
    private static func newfenv(L:lua_State!, cls:lua_CFunction!) {
        LuaAPI.lua_createtable(L: L, narray: 0, nrec: 1)
        Lua.lua_pushcfunction(L: L, f: cls)
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "__close"))
    }
    
    public static func luaopen_io(L:lua_State!) -> Int {
        createmeta(L: L)
        // create (private) environment (with fields IO_INPUT, IO_OUTPUT, __close)
        newfenv(L: L, cls: LuaIOLib_delegate(name: "io_fclose"))
        LuaAPI.lua_replace(L: L, idx: Lua.LUA_ENVIRONINDEX)
        // open library
        LuaAuxLib.luaL_register(L: L, libname: CharPtr.toCharPtr(str: LuaLib.LUA_IOLIBNAME), l: iolib)
        // create (and set) default files
        newfenv(L: L, cls: LuaIOLib_delegate(name: "io_noclose")) // close function for default files
        createstdfile(L: L, f: CLib.stdin, k: IO_INPUT, fname: CharPtr.toCharPtr(str: "stdin"))
        createstdfile(L: L, f: CLib.stdout, k: IO_OUTPUT, fname: CharPtr.toCharPtr(str: "stdout"))
        createstdfile(L: L, f: CLib.stderr, k: 0, fname: CharPtr.toCharPtr(str: "stderr"))
        Lua.lua_pop(L: L, n: 1) // pop environment for default files
        LuaAPI.lua_getfield(L: L, idx: -1, k: CharPtr.toCharPtr(str: "popen"))
        newfenv(L: L, cls: LuaIOLib_delegate(name: "io_pclose")) // create environment for 'popen'
        _ = LuaAPI.lua_setfenv(L: L, idx: -2) // set fenv for 'popen'
        Lua.lua_pop(L: L, n: 1) // pop 'popen'
        return 1
    }
}
