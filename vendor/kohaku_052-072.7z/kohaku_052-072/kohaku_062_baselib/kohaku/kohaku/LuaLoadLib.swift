//package kurumi;

//
// ** $Id: loadlib.c,v 1.52.1.3 2008/08/06 13:29:28 roberto Exp $
// ** Dynamic library loader for Lua
// ** See Copyright Notice in lua.h
// **
// ** This module contains an implementation of loadlib for Unix systems
// ** that have dlfcn, an implementation for Darwin (Mac OS X), an
// ** implementation for Windows, and a stub for other systems.
//

public class LuaLoadLib {
    // prefix for open functions in C libraries
    public static let LUA_POF:String = "luaopen_"
    
    // separator for open functions in C libraries
    public static let LUA_OFSEP:String = "_"
    
    public static let LIBPREFIX:String = "LOADLIB: "
    
    public static let POF:String = LUA_POF
    public static let LIB_FAIL:String = "open"
    
    // error codes for ll_loadfunc
    public static let ERRLIB:Int = 1
    public static let ERRFUNC:Int = 2
    
    //public static void setprogdir(lua_State L) { }
    
    public static func setprogdir(L:lua_State!) {
        let buff:CharPtr! = CharPtr.toCharPtr(str: StreamProxy.GetCurrentDirectory())
        _ = LuaAuxLib.luaL_gsub(L: L, s: Lua.lua_tostring(L: L, i: -1), p: CharPtr.toCharPtr(str: LuaConf.LUA_EXECDIR), r: buff)
        LuaAPI.lua_remove(L: L, idx: -2) // remove original string
    }
    
    
    ///#if LUA_DL_DLOPEN
    //        /*
    //         ** {========================================================================
    //         ** This is an implementation of loadlib based on the dlfcn interface.
    //         ** The dlfcn interface is available in Linux, SunOS, Solaris, IRIX, FreeBSD,
    //         ** NetBSD, AIX 4.2, HPUX 11, and  probably most other Unix flavors, at least
    //         ** as an emulation layer on top of native functions.
    //         ** =========================================================================
    //         */
    //
    //        //#include <dlfcn.h>
    //
    //        static void ll_unloadlib (void *lib)
    //        {
    //            dlclose(lib);
    //        }
    //
    //        static void *ll_load (lua_State L, readonly CharPtr path)
    //        {
    //            void *lib = dlopen(path, RTLD_NOW);
    //            if (lib == null)
    //            {
    //                lua_pushstring(L, dlerror());
    //            }
    //            return lib;
    //        }
    //
    //        static lua_CFunction ll_sym (lua_State L, void *lib, readonly CharPtr sym)
    //        {
    //            lua_CFunction f = (lua_CFunction)dlsym(lib, sym);
    //            if (f == null)
    //            {
    //                lua_pushstring(L, dlerror());
    //            }
    //            return f;
    //        }
    //
    //        /* }====================================================== */
    //
    //
    //
    //        //#elif defined(LUA_DL_DLL)
    //        /*
    //         ** {======================================================================
    //         ** This is an implementation of loadlib for Windows using native functions.
    //         ** =======================================================================
    //         */
    //
    //        //#include <windows.h>
    //
    //
    //        //#undef setprogdir
    //
    //        static void setprogdir (lua_State L)
    //        {
    //            char buff[MAX_PATH + 1];
    //            char *lb;
    //            DWORD nsize = sizeof(buff)/GetUnmanagedSize(typeof(char));
    //            DWORD n = GetModuleFileNameA(null, buff, nsize);
    //            if (n == 0 || n == nsize || (lb = strrchr(buff, '\\')) == null)
    //            {
    //                luaL_error(L, "unable to get ModuleFileName");
    //            }
    //            else
    //            {
    //                *lb = '\0';
    //                luaL_gsub(L, lua_tostring(L, -1), LUA_EXECDIR, buff);
    //                lua_remove(L, -2);  /* remove original string */
    //            }
    //        }
    //
    //        static void pusherror (lua_State L)
    //        {
    //            int error = GetLastError();
    //            char buffer[128];
    //            if (FormatMessageA(FORMAT_MESSAGE_IGNORE_INSERTS | FORMAT_MESSAGE_FROM_SYSTEM,
    //                               null, error, 0, buffer, sizeof(buffer), null))
    //            {
    //                lua_pushstring(L, buffer);
    //            }
    //            else
    //            {
    //                lua_pushfstring(L, "system error %d\n", error);
    //            }
    //        }
    //
    //        static void ll_unloadlib(void *lib)
    //        {
    //            FreeLibrary((HINSTANCE)lib);
    //        }
    //
    //        static void *ll_load (lua_State L, readonly CharPtr path)
    //        {
    //            HINSTANCE lib = LoadLibraryA(path);
    //            if (lib == null)
    //            {
    //                pusherror(L);
    //            }
    //            return lib;
    //        }
    //
    //        static lua_CFunction ll_sym (lua_State L, void *lib, readonly CharPtr sym)
    //        {
    //            lua_CFunction f = (lua_CFunction)GetProcAddress((HINSTANCE)lib, sym);
    //            if (f == null)
    //            {
    //                pusherror(L);
    //            }
    //            return f;
    //        }
    //
    //        /* }====================================================== */
    //
    //        #elif LUA_DL_DYLD
    //        /*
    //         ** {======================================================================
    //         ** Native Mac OS X / Darwin Implementation
    //         ** =======================================================================
    //         */
    //
    //        //#include <mach-o/dyld.h>
    //
    //
    //        /* Mac appends a `_' before C function names */
    //        //#undef POF
    //        //#define POF    "_" LUA_POF
    //
    //        static void pusherror (lua_State L)
    //        {
    //            CharPtr err_str;
    //            CharPtr err_file;
    //            NSLinkEditErrors err;
    //            int err_num;
    //            NSLinkEditError(err, err_num, err_file, err_str);
    //            lua_pushstring(L, err_str);
    //        }
    //
    //
    //        static CharPtr errorfromcode (NSObjectFileImageReturnCode ret)
    //        {
    //            switch (ret)
    //            {
    //                case NSObjectFileImageInappropriateFile:
    //                    {
    //                        return "file is not a bundle";
    //                    }
    //                case NSObjectFileImageArch:
    //                    {
    //                        return "library is for wrong CPU type";
    //                    }
    //                case NSObjectFileImageFormat:
    //                    {
    //                        return "bad format";
    //                    }
    //                case NSObjectFileImageAccess:
    //                    {
    //                        return "cannot access file";
    //                    }
    //                case NSObjectFileImageFailure:
    //                default:
    //                    {
    //                        return "unable to load library";
    //                    }
    //            }
    //        }
    //
    //        static void ll_unloadlib (void *lib)
    //        {
    //            NSUnLinkModule((NSModule)lib, NSUNLINKMODULE_OPTION_RESET_LAZY_REFERENCES);
    //        }
    //
    //        static void *ll_load (lua_State L, readonly CharPtr path)
    //        {
    //            NSObjectFileImage img;
    //            NSObjectFileImageReturnCode ret;
    //            /* this would be a rare case, but prevents crashing if it happens */
    //            if(!_dyld_present()) {
    //                lua_pushliteral(L, "dyld not present");
    //                return null;
    //            }
    //            ret = NSCreateObjectFileImageFromFile(path, img);
    //            if (ret == NSObjectFileImageSuccess) {
    //                NSModule mod = NSLinkModule(img, path, NSLINKMODULE_OPTION_PRIVATE |
    //                                            NSLINKMODULE_OPTION_RETURN_ON_ERROR);
    //                NSDestroyObjectFileImage(img);
    //                if (mod == null) pusherror(L);
    //                return mod;
    //            }
    //            lua_pushstring(L, errorfromcode(ret));
    //            return null;
    //        }
    //
    //        static lua_CFunction ll_sym (lua_State L, void *lib, readonly CharPtr sym)
    //        {
    //            NSSymbol nss = NSLookupSymbolInModule((NSModule)lib, sym);
    //            if (nss == null)
    //            {
    //                lua_pushfstring(L, "symbol " + LUA_QS + " not found", sym);
    //                return null;
    //            }
    //            return (lua_CFunction)NSAddressOfSymbol(nss);
    //        }
    //
    //        /* }====================================================== */
    
    ///#else
    //
    //         ** {======================================================
    //         ** Fallback for other systems
    //         ** =======================================================
    //
    
    ///#undef LIB_FAIL
    ///#define LIB_FAIL    "absent"
    
    public static let DLMSG:String = "dynamic libraries not enabled; check your Lua installation"
    
    public static func ll_unloadlib(lib:Any!) {
        //(void)lib;  /* to avoid warnings */
    }
    
    public static func ll_load(L:lua_State!, path:CharPtr!) -> Any! {
        //(void)path;  /* to avoid warnings */
        Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: DLMSG))
        return nil
    }
    
    public static func ll_sym(L:lua_State!, lib:Any!, sym:CharPtr!) -> lua_CFunction! {
        //(void)lib; (void)sym;  /* to avoid warnings */
        Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: DLMSG))
        return nil
    }
    
    // }======================================================
    ///#endif
    
    private static func ll_register(L:lua_State!, path:CharPtr!) -> Any! {
        // todo: the whole usage of plib here is wrong, fix it - mjf
        //void **plib;
        var plib:Any! = nil
        _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: "%s%s"), p: LIBPREFIX, path)
        LuaAPI.lua_gettable(L: L, idx: Lua.LUA_REGISTRYINDEX) // check library in registry?
        if (!Lua.lua_isnil(L: L, n: -1)) { // is there an entry?
            plib = LuaAPI.lua_touserdata(L: L, idx: -1)
        }
        else {
            // no entry yet; create one
            Lua.lua_pop(L: L, n: 1)
            //plib = lua_newuserdata(L, (uint)Marshal.SizeOf(plib));
            //plib[0] = null;
            LuaAuxLib.luaL_getmetatable(L: L, n: CharPtr.toCharPtr(str: "_LOADLIB"))
            _ = LuaAPI.lua_setmetatable(L: L, objindex: -2)
            _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: "%s%s"), p: LIBPREFIX, path)
            LuaAPI.lua_pushvalue(L: L, idx: -2)
            LuaAPI.lua_settable(L: L, idx: Lua.LUA_REGISTRYINDEX)
        }
        return plib
    }
    
    //
    //         ** __gc tag method: calls library's `ll_unloadlib' function with the lib
    //         ** handle
    //
    fileprivate static func gctm(L:lua_State!) -> Int {
        var lib:Any! = LuaAuxLib.luaL_checkudata(L: L, ud: 1, tname: CharPtr.toCharPtr(str: "_LOADLIB"))
        if (lib != nil) {
            ll_unloadlib(lib: lib)
        }
        lib = nil // mark library as closed
        return 0
    }
    
    private static func ll_loadfunc(L:lua_State!, path:CharPtr!, sym:CharPtr!) -> Int {
        var reg:Any! = ll_register(L: L, path: path)
        if (reg == nil) {
            reg = ll_load(L: L, path: path)
        }
        if (reg == nil) {
            return ERRLIB; // unable to load library
        }
        else {
            let f:lua_CFunction! = ll_sym(L: L, lib: reg, sym: sym)
            if (f == nil) {
                return ERRFUNC // unable to find function
            }
            Lua.lua_pushcfunction(L: L, f: f)
            return 0 // return function
        }
    }
    
    fileprivate static func ll_loadlib(L:lua_State!) -> Int {
        let path:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 1)
        let init_:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 2)
        let stat:Int = ll_loadfunc(L: L, path: path, sym: init_)
        if (stat == 0) { // no errors?
            return 1 // return the loaded function
        }
        else
        { // error; error message is on stack top
            LuaAPI.lua_pushnil(L: L)
            LuaAPI.lua_insert(L: L, idx: -2)
            LuaAPI.lua_pushstring(L: L, s: (stat == ERRLIB) ? CharPtr.toCharPtr(str: LIB_FAIL) : CharPtr.toCharPtr(str: "init"))
            return 3 // return nil, error message, and where
        }
    }
    
    
    //
    //         ** {======================================================
    //         ** 'require' function
    //         ** =======================================================
    //
    private static func readable(filename:CharPtr!) -> Int {
        let f:StreamProxy! = CLib.fopen(filename: filename, mode: CharPtr.toCharPtr(str: "r")) // try to open file
        if (f == nil) { // open failed
            return 0
        }
        _ = CLib.fclose(stream: f)
        return 1
    }
    
    private static func pushnexttemplate(L:lua_State!, path:CharPtr!) -> CharPtr! {
        var path:CharPtr! = path
        var l:CharPtr!
        while (path.get(offset: 0) == ClassType.charAt(str: LuaConf.LUA_PATHSEP, idx: 0)) {
            path = path.next() // skip separators
        }
        if (path.get(offset: 0) == "\0") {
            return nil // no more templates
        }
        l = CLib.strchr(str: path, c: ClassType.charAt(str: LuaConf.LUA_PATHSEP, idx: 0)) // find next separator
        if (CharPtr.isEqual(ptr1: l, ptr2: nil)) {
            l = CharPtr.plus(ptr: path, offset: CLib.strlen(str: path))
        }
        LuaAPI.lua_pushlstring(L: L, s: path, len: CharPtr.minus(ptr1: l, ptr2: path)) // template  - (uint)
        return l
    }
    
    private static func findfile(L:lua_State!, name:CharPtr!, pname:CharPtr!) -> CharPtr! {
        var name:CharPtr! = name
        var path:CharPtr!
        name = LuaAuxLib.luaL_gsub(L: L, s: name, p: CharPtr.toCharPtr(str: "."), r: CharPtr.toCharPtr(str: LuaConf.LUA_DIRSEP))
        LuaAPI.lua_getfield(L: L, idx: Lua.LUA_ENVIRONINDEX, k: pname)
        path = Lua.lua_tostring(L: L, i: -1)
        if (CharPtr.isEqual(ptr1: path, ptr2: nil)) {
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: LuaConf.LUA_QL(x: "package.%s").toString() + " must be a string"), p: pname);
        }
        Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: "")) // error accumulator
        while (true) {
            path = pushnexttemplate(L: L, path: path)
            if (!CharPtr.isNotEqual(ptr1: path, ptr2: nil)) {
                break
            }
            var filename:CharPtr!;
            filename = LuaAuxLib.luaL_gsub(L: L, s: Lua.lua_tostring(L: L, i: -1), p: CharPtr.toCharPtr(str: LuaConf.LUA_PATH_MARK), r: name)
            LuaAPI.lua_remove(L: L, idx: -2) // remove path template
            if (readable(filename: filename) != 0) { // does file exist and is readable?
                return filename // return that file name
            }
            _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: "\n\tno file " + LuaConf.getLUA_QS().toString()), p: filename)
            LuaAPI.lua_remove(L: L, idx: -2) // remove file name
            LuaAPI.lua_concat(L: L, n: 2) // add entry to possible error message
        }
        return nil // not found
    }
    
    private static func loaderror(L:lua_State!, filename:CharPtr!) {
        _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "error loading module " + LuaConf.getLUA_QS().toString() + " from file " + LuaConf.getLUA_QS().toString() + ":\n\t%s"), p: Lua.lua_tostring(L: L, i: 1), filename, Lua.lua_tostring(L: L, i: -1))
    }
    
    fileprivate static func loader_Lua(L:lua_State!) -> Int {
        var filename:CharPtr!
        let name:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 1)
        filename = findfile(L: L, name: name, pname: CharPtr.toCharPtr(str: "path"))
        if (CharPtr.isEqual(ptr1: filename, ptr2: nil)) {
            return 1 // library not found in this path
        }
        if (LuaAuxLib.luaL_loadfile(L: L, filename: filename) != 0) {
            loaderror(L: L, filename: filename)
        }
        return 1 // library loaded successfully
    }
    
    private static func mkfuncname(L:lua_State!, modname:CharPtr!) -> CharPtr! {
        var modname:CharPtr! = modname
        var funcname:CharPtr!
        let mark:CharPtr! = CLib.strchr(str: modname, c: ClassType.charAt(str: LuaConf.LUA_IGMARK, idx: 0))
        if (CharPtr.isNotEqual(ptr1: mark, ptr2: nil)) {
            modname = CharPtr.plus(ptr: mark, offset: 1)
        }
        funcname = LuaAuxLib.luaL_gsub(L: L, s: modname, p: CharPtr.toCharPtr(str: "."), r: CharPtr.toCharPtr(str: LUA_OFSEP))
        funcname = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: POF + "%s"), p: funcname)
        LuaAPI.lua_remove(L: L, idx: -2) // remove 'gsub' result
        return funcname
    }
    
    fileprivate static func loader_C(L:lua_State!) -> Int {
        var funcname:CharPtr!
        let name:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 1)
        let filename:CharPtr! = findfile(L: L, name: name, pname: CharPtr.toCharPtr(str: "cpath"));
        if (CharPtr.isEqual(ptr1: filename, ptr2: nil)) {
            return 1 // library not found in this path
        }
        funcname = mkfuncname(L: L, modname: name)
        if (ll_loadfunc(L: L, path: filename, sym: funcname) != 0) {
            loaderror(L: L, filename: filename)
        }
        return 1 // library loaded successfully
    }
    
    fileprivate static func loader_Croot(L:lua_State!) -> Int {
        var funcname:CharPtr!
        var filename:CharPtr!
        let name:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 1)
        let p:CharPtr! = CLib.strchr(str: name, c: ".")
        var stat:Int
        if (CharPtr.isEqual(ptr1: p, ptr2: nil)) {
            return 0 // is root
        }
        LuaAPI.lua_pushlstring(L: L, s: name, len: CharPtr.minus(ptr1: p, ptr2: name)) //(uint)
        filename = findfile(L: L, name: Lua.lua_tostring(L: L, i: -1), pname: CharPtr.toCharPtr(str: "cpath"));
        if (CharPtr.isEqual(ptr1: filename, ptr2: nil)) {
            return 1 // root not found
        }
        funcname = mkfuncname(L: L, modname: name)
        stat = ll_loadfunc(L: L, path: filename, sym: funcname)
        if (stat != 0) {
            if (stat != ERRFUNC) {
                loaderror(L: L, filename: filename); // real error
            }
            _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: "\n\tno module " + LuaConf.getLUA_QS().toString() + " in file " + LuaConf.getLUA_QS().toString()), p: name, filename)
            return 1 // function not found
        }
        return 1
    }
    
    fileprivate static func loader_preload(L:lua_State!) -> Int {
        let name:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 1)
        LuaAPI.lua_getfield(L: L, idx: Lua.LUA_ENVIRONINDEX, k: CharPtr.toCharPtr(str: "preload"))
        if (!Lua.lua_istable(L: L, n: -1)) {
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: LuaConf.LUA_QL(x: "package.preload").toString() + " must be a table"))
        }
        LuaAPI.lua_getfield(L: L, idx: -1, k: name)
        if (Lua.lua_isnil(L: L, n: -1)) { // not found?
            _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: "\n\tno field package.preload['%s']"), p: name)
        }
        return 1
    }
    
    public static var sentinel:AnyObject! = Object_() as AnyObject
    
    public static func ll_require(L:lua_State!) -> Int {
        let name:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 1)
        var i:Int
        LuaAPI.lua_settop(L: L, idx: 1) // _LOADED table will be at index 2
        LuaAPI.lua_getfield(L: L, idx: Lua.LUA_REGISTRYINDEX, k: CharPtr.toCharPtr(str: "_LOADED"))
        LuaAPI.lua_getfield(L: L, idx: 2, k: name)
        if (LuaAPI.lua_toboolean(L: L, idx: -1) != 0) {
            // is it there?
            if (LuaAPI.lua_touserdata(L: L, idx: -1) as AnyObject === sentinel) { // check loops
                _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "loop or previous error loading module " + LuaConf.getLUA_QS().toString()), p: name)
            }
            return 1; // package is already loaded
        }
        // else must load it; iterate over available loaders
        LuaAPI.lua_getfield(L: L, idx: Lua.LUA_ENVIRONINDEX, k: CharPtr.toCharPtr(str: "loaders"))
        if (!Lua.lua_istable(L: L, n: -1)) {
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: LuaConf.LUA_QL(x: "package.loaders").toString() + " must be a table"));
        }
        Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: "")); // error message accumulator
        i = 1
        while (true) {
            LuaAPI.lua_rawgeti(L: L, idx: -2, n: i) // get a loader
            if (Lua.lua_isnil(L: L, n: -1)) {
                _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "module " + LuaConf.getLUA_QS().toString() + " not found:%s"), p: name, Lua.lua_tostring(L: L, i: -2))
            }
            LuaAPI.lua_pushstring(L: L, s: name)
            LuaAPI.lua_call(L: L, nargs: 1, nresults: 1) // call it
            if (Lua.lua_isfunction(L: L, n: -1)) { // did it find module?
                break // module loaded successfully
            }
            else if (LuaAPI.lua_isstring(L: L, idx: -1) != 0) { // loader returned error message?
                LuaAPI.lua_concat(L: L, n: 2) // accumulate it
            }
            else {
                Lua.lua_pop(L: L, n: 1)
            }
            i += 1
        }
        LuaAPI.lua_pushlightuserdata(L: L, p: sentinel)
        LuaAPI.lua_setfield(L: L, idx: 2, k: name) // _LOADED[name] = sentinel
        LuaAPI.lua_pushstring(L: L, s: name) // pass name as argument to module
        LuaAPI.lua_call(L: L, nargs: 1, nresults: 1) // run loaded module
        if (!Lua.lua_isnil(L: L, n: -1)) { // non-nil return?
            LuaAPI.lua_setfield(L: L, idx: 2, k: name) // _LOADED[name] = returned value
        }
        LuaAPI.lua_getfield(L: L, idx: 2, k: name);
        if (LuaAPI.lua_touserdata(L: L, idx: -1) as AnyObject === sentinel) {
            // module did not set a value?
            LuaAPI.lua_pushboolean(L: L, b: 1) // use true as result
            LuaAPI.lua_pushvalue(L: L, idx: -1) // extra copy to be returned
            LuaAPI.lua_setfield(L: L, idx: 2, k: name) // _LOADED[name] = true
        }
        return 1
    }
    
    // }======================================================
    
    //
    //         ** {======================================================
    //         ** 'module' function
    //         ** =======================================================
    //
    
    
    private static func setfenv(L:lua_State!) {
        let ar:lua_Debug! = lua_Debug()
        if (LuaDebug.lua_getstack(L: L, level: 1, ar: ar) == 0 || LuaDebug.lua_getinfo(L: L, what: CharPtr.toCharPtr(str: "f"), ar: ar) == 0 || LuaAPI.lua_iscfunction(L: L, idx: -1)) { // get calling function
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: LuaConf.LUA_QL(x: "module").toString() + " not called from a Lua function"));
        }
        LuaAPI.lua_pushvalue(L: L, idx: -2)
        _ = LuaAPI.lua_setfenv(L: L, idx: -2)
        Lua.lua_pop(L: L, n: 1)
    }
    
    private static func dooptions(L:lua_State!, n:Int) {
        for i:Int in 2...n {
            LuaAPI.lua_pushvalue(L: L, idx: i) // get option (a function)
            LuaAPI.lua_pushvalue(L: L, idx: -2) // module
            LuaAPI.lua_call(L: L, nargs: 1, nresults: 0)
        }
    }
    
    private static func modinit(L:lua_State!, modname:CharPtr!) {
        var dot:CharPtr!
        LuaAPI.lua_pushvalue(L: L, idx: -1)
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "_M")) // module._M = module
        LuaAPI.lua_pushstring(L: L, s: modname)
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "_NAME"))
        dot = CLib.strrchr(str: modname, ch: ".") // look for last dot in module name
        if (CharPtr.isEqual(ptr1: dot, ptr2: nil)) {
            dot = modname
        }
        else {
            dot = dot.next()
        }
        // set _PACKAGE as package name (full module name minus last part)
        LuaAPI.lua_pushlstring(L: L, s: modname, len: CharPtr.minus(ptr1: dot, ptr2: modname)) //(uint)
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "_PACKAGE"))
    }
    
    fileprivate static func ll_module(L:lua_State!) -> Int {
        let modname:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 1)
        let loaded:Int = LuaAPI.lua_gettop(L: L) + 1 // index of _LOADED table
        LuaAPI.lua_getfield(L: L, idx: Lua.LUA_REGISTRYINDEX, k: CharPtr.toCharPtr(str: "_LOADED"))
        LuaAPI.lua_getfield(L: L, idx: loaded, k: modname) // get _LOADED[modname]
        if (!Lua.lua_istable(L: L, n: -1)) {
            // not found?
            Lua.lua_pop(L: L, n: 1) // remove previous result
            // try global variable (and create one if it does not exist)
            if (CharPtr.isNotEqual(ptr1: LuaAuxLib.luaL_findtable(L: L, idx: Lua.LUA_GLOBALSINDEX, fname: modname, szhint: 1), ptr2: nil)) {
                return LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "name conflict for module " + LuaConf.getLUA_QS().toString()), p: modname);
            }
            LuaAPI.lua_pushvalue(L: L, idx: -1)
            LuaAPI.lua_setfield(L: L, idx: loaded, k: modname) // _LOADED[modname] = new table
        }
        // check whether table already has a _NAME field
        LuaAPI.lua_getfield(L: L, idx: -1, k: CharPtr.toCharPtr(str: "_NAME"))
        if (!Lua.lua_isnil(L: L, n: -1)) { // is table an initialized module?
            Lua.lua_pop(L: L, n: 1)
        }
        else {
            // no; initialize it
            Lua.lua_pop(L: L, n: 1)
            modinit(L: L, modname: modname)
        }
        LuaAPI.lua_pushvalue(L: L, idx: -1)
        setfenv(L: L)
        dooptions(L: L, n: loaded - 1)
        return 0
    }
    
    fileprivate static func ll_seeall(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TTABLE)
        if (LuaAPI.lua_getmetatable(L: L, objindex: 1) == 0) {
            LuaAPI.lua_createtable(L: L, narray: 0, nrec: 1) // create new metatable
            LuaAPI.lua_pushvalue(L: L, idx: -1)
            _ = LuaAPI.lua_setmetatable(L: L, objindex: 1)
        }
        LuaAPI.lua_pushvalue(L: L, idx: Lua.LUA_GLOBALSINDEX)
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "__index")) // mt.__index = _G
        return 0
    }
    
    // }======================================================
    
    // auxiliary mark (for internal use)
    public static let AUXMARK:String = ClassType.format(fmt: "%1$s", p: ClassType.intToChar(ch: 1))
    
    private static func setpath(L:lua_State!, fieldname:CharPtr!, envname:CharPtr!, def:CharPtr!) {
        var path:CharPtr! = CLib.getenv(envname: envname)
        if (CharPtr.isEqual(ptr1: path, ptr2: nil)) { // no environment variable?
            LuaAPI.lua_pushstring(L: L, s: def) // use default
        }
        else {
            // replace ";;" by ";AUXMARK;" and then AUXMARK by default path
            path = LuaAuxLib.luaL_gsub(L: L, s: path, p: CharPtr.toCharPtr(str: LuaConf.LUA_PATHSEP + LuaConf.LUA_PATHSEP), r: CharPtr.toCharPtr(str: LuaConf.LUA_PATHSEP + AUXMARK + LuaConf.LUA_PATHSEP))
            _ = LuaAuxLib.luaL_gsub(L: L, s: path, p: CharPtr.toCharPtr(str: AUXMARK), r: def)
            LuaAPI.lua_remove(L: L, idx: -2)
        }
        setprogdir(L: L)
        LuaAPI.lua_setfield(L: L, idx: -2, k: fieldname)
    }
    
    private static let pk_funcs:[luaL_Reg]! = [
        luaL_Reg(name: CharPtr.toCharPtr(str: "loadlib"), func_: LuaLoadLib_delegate(name: "ll_loadlib")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "seeall"), func_: LuaLoadLib_delegate(name: "ll_seeall")),
        luaL_Reg(name: nil, func_: nil)
    ]
    
    private static let ll_funcs:[luaL_Reg]! = [
        luaL_Reg(name: CharPtr.toCharPtr(str: "module"), func_: LuaLoadLib_delegate(name: "ll_module")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "require"), func_: LuaLoadLib_delegate(name: "ll_require")),
        luaL_Reg(name: nil, func_: nil)
    ]
    
    public static let loaders:[lua_CFunction?]! = [
        LuaLoadLib_delegate(name: "loader_preload"),
        LuaLoadLib_delegate(name: "loader_Lua"),
        LuaLoadLib_delegate(name: "loader_C"),
        LuaLoadLib_delegate(name: "loader_Croot"),
        nil
    ]
}


public class LuaLoadLib_delegate: lua_CFunction {
    private var name:String!
    
    public init(name:String!) {
        self.name = name
    }
    
    public func exec(L:lua_State!) -> Int {
        if ("ll_loadlib" == name) {
            return LuaLoadLib.ll_loadlib(L: L)
        }
        else if ("ll_seeall" == name) {
            return LuaLoadLib.ll_seeall(L: L)
        }
        else if ("ll_module" == name) {
            return LuaLoadLib.ll_module(L: L)
        }
        else if ("ll_require" == name) {
            return LuaLoadLib.ll_require(L: L)
        }
        else if ("loader_preload" == name) {
            return LuaLoadLib.loader_preload(L: L)
        }
        else if ("loader_Lua" == name) {
            return LuaLoadLib.loader_Lua(L: L)
        }
        else if ("loader_C" == name) {
            return LuaLoadLib.loader_C(L: L)
        }
        else if ("loader_Croot" == name) {
            return LuaLoadLib.loader_Croot(L: L)
        }
        else if ("gctm" == name) {
            return LuaLoadLib.gctm(L: L)
        }
        else {
            return 0
        }
    }
}

extension LuaLoadLib {
    public static func luaopen_package(L:lua_State!) -> Int {
        var i:Int
        // create new type _LOADLIB
        _ = LuaAuxLib.luaL_newmetatable(L: L, tname: CharPtr.toCharPtr(str: "_LOADLIB"));
        Lua.lua_pushcfunction(L: L, f: LuaLoadLib_delegate(name: "gctm"))
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "__gc"))
        // create `package' table
        LuaAuxLib.luaL_register(L: L, libname: CharPtr.toCharPtr(str: LuaLib.LUA_LOADLIBNAME), l: pk_funcs)
        ///#if LUA_COMPAT_LOADLIB
        //            lua_getfield(L, -1, "loadlib");
        //            lua_setfield(L, LUA_GLOBALSINDEX, "loadlib");
        ///#endif
        LuaAPI.lua_pushvalue(L: L, idx: -1)
        LuaAPI.lua_replace(L: L, idx: Lua.LUA_ENVIRONINDEX)
        // create `loaders' table
        LuaAPI.lua_createtable(L: L, narray: 0, nrec: loaders.count - 1)
        // fill it with pre-defined loaders
        i = 0
        while (loaders[i] != nil) {
            Lua.lua_pushcfunction(L: L, f: loaders[i])
            LuaAPI.lua_rawseti(L: L, idx: -2, n: i + 1)
            i += 1
        }
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "loaders")); // put it in field `loaders'
        setpath(L: L, fieldname: CharPtr.toCharPtr(str: "path"), envname: CharPtr.toCharPtr(str: LuaConf.LUA_PATH), def: CharPtr.toCharPtr(str: LuaConf.LUA_PATH_DEFAULT)) // set field `path'
        setpath(L: L, fieldname: CharPtr.toCharPtr(str: "cpath"), envname: CharPtr.toCharPtr(str: LuaConf.LUA_CPATH), def: CharPtr.toCharPtr(str: LuaConf.LUA_CPATH_DEFAULT)) // set field `cpath'
        // store config information
        Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: LuaConf.LUA_DIRSEP + "\n" + LuaConf.LUA_PATHSEP + "\n" + LuaConf.LUA_PATH_MARK + "\n" + LuaConf.LUA_EXECDIR + "\n" + LuaConf.LUA_IGMARK))
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "config"))
        // set field `loaded'
        _ = LuaAuxLib.luaL_findtable(L: L, idx: Lua.LUA_REGISTRYINDEX, fname: CharPtr.toCharPtr(str: "_LOADED"), szhint: 2)
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "loaded"))
        // set field `preload'
        Lua.lua_newtable(L: L)
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "preload"))
        LuaAPI.lua_pushvalue(L: L, idx: Lua.LUA_GLOBALSINDEX)
        LuaAuxLib.luaL_register(L: L, libname: nil, l: ll_funcs) // open lib into global table
        Lua.lua_pop(L: L, n: 1)
        return 1 // return 'package' table
    }
}
