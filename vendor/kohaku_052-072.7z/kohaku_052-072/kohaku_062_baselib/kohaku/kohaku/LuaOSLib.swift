//package kurumi;

#if os(OSX) || os(iOS)
    import Darwin
#elseif os(Linux)
    import GLibc
#endif
import Foundation

//
// ** $Id: loslib.c,v 1.19.1.3 2008/01/18 16:38:18 roberto Exp $
// ** Standard Operating System library
// ** See Copyright Notice in lua.h
//

//using TValue = Lua.TValue;
//using StkId = TValue;
//using lua_Integer = System.Int32;
//using lua_Number = System.Double;

public class LuaOSLib {
    private static func os_pushresult(L:lua_State!, i:Int, filename:CharPtr!) -> Int {
        let en:Int = CLib.errno() // calls to Lua API may change this value
        if (i != 0) {
            LuaAPI.lua_pushboolean(L: L, b: 1)
            return 1
        }
        else {
            LuaAPI.lua_pushnil(L: L)
            _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: "%s: %s"), p: filename, CLib.strerror(error: en))
            LuaAPI.lua_pushinteger(L: L, n: en)
            return 3
        }
    }
    
    fileprivate static func os_execute(L:lua_State!) -> Int {
        let strCmdLine:CharPtr! = CharPtr.toCharPtr(str: "" + LuaAuxLib.luaL_optstring(L: L, n: 1, d: nil).toString())
        LuaAPI.lua_pushinteger(L: L, n: ClassType.processExec(strCmdLine: strCmdLine.toString()))
        return 1
    }
    
    //FIXME:
    fileprivate static func os_remove(L:lua_State!) -> Int {
        let filename:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 1);
        let result:Int = 1
//        do {
            StreamProxy.Delete(path: filename.toString())
//        }
//        catch {
//            result = 0;
//        }
        return os_pushresult(L: L, i: result, filename: filename)
    }
    
    fileprivate static func os_rename(L:lua_State!) -> Int {
        let fromname:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 1)
        let toname:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 2)
        var result:Int = 0
//        try {
        StreamProxy.Move(path1: fromname.toString(), path2: toname.toString())
            result = 0;
//        }
//        catch (java.lang.Exception e) {
//            result = 1; // todo: this should be a proper error code
//        }
        return os_pushresult(L: L, i: result, filename: fromname)
    }
    
    fileprivate static func os_tmpname(L:lua_State!) -> Int {
        LuaAPI.lua_pushstring(L: L, s: CharPtr.toCharPtr(str: StreamProxy.GetTempFileName()))
        return 1
    }
    
    
    fileprivate static func os_getenv(L:lua_State!) -> Int {
        LuaAPI.lua_pushstring(L: L, s: CLib.getenv(envname: LuaAuxLib.luaL_checkstring(L: L, n: 1))) // if null push nil
        return 1
    }
    
    fileprivate static func os_clock(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: DateTimeProxy.getClock())
        return 1
    }
    
    //
    //         ** {======================================================
    //         ** Time/Date operations
    //         ** { year=%Y, month=%m, day=%d, hour=%H, min=%M, sec=%S,
    //         **   wday=%w+1, yday=%j, isdst=? }
    //         ** =======================================================
    //
    private static func setfield(L:lua_State!, key:CharPtr!, value:Int) {
        LuaAPI.lua_pushinteger(L: L, n: value)
        LuaAPI.lua_setfield(L: L, idx: -2, k: key)
    }
    
    private static func setboolfield(L:lua_State!, key:CharPtr!, value:Int) {
        if (value < 0) { // undefined?
            return // does not set field
        }
        LuaAPI.lua_pushboolean(L: L, b: value)
        LuaAPI.lua_setfield(L: L, idx: -2, k: key)
    }
    
    private static func getboolfield(L:lua_State!, key:CharPtr!) -> Int {
        var res:Int
        LuaAPI.lua_getfield(L: L, idx: -1, k: key)
        res = Lua.lua_isnil(L: L, n: -1) ? -1 : LuaAPI.lua_toboolean(L: L, idx: -1)
        Lua.lua_pop(L: L, n: 1)
        return res
    }
    
    private static func getfield(L:lua_State!, key:CharPtr!, d:Int) -> Int {
        var res:Int
        LuaAPI.lua_getfield(L: L, idx: -1, k: key)
        if (LuaAPI.lua_isnumber(L: L, idx: -1) != 0) {
            res = Int(LuaAPI.lua_tointeger(L: L, idx: -1))
        }
        else {
            if (d < 0) {
                return LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "field " + LuaConf.getLUA_QS().toString() + " missing in date table"), p: key)
            }
            res = d
        }
        Lua.lua_pop(L: L, n: 1)
        return res
    }
    
    fileprivate static func os_date(L:lua_State!) -> Int {
        let s:CharPtr! = LuaAuxLib.luaL_optstring(L: L, n: 1, d: CharPtr.toCharPtr(str: "%c"))
        let stm:DateTimeProxy! = DateTimeProxy()
        if (s.get(offset: 0) == "!") {
            // UTC?
            stm.setUTCNow()
            s.inc() // skip `!'
        }
        else {
            stm.setNow()
        }
        if (CLib.strcmp(s1: s, s2: CharPtr.toCharPtr(str: "*t")) == 0) {
            LuaAPI.lua_createtable(L: L, narray: 0, nrec: 9) // 9 = number of fields
            setfield(L: L, key: CharPtr.toCharPtr(str: "sec"), value: stm.getSecond())
            setfield(L: L, key: CharPtr.toCharPtr(str: "min"), value: stm.getMinute())
            setfield(L: L, key: CharPtr.toCharPtr(str: "hour"), value: stm.getHour())
            setfield(L: L, key: CharPtr.toCharPtr(str: "day"), value: stm.getDay())
            setfield(L: L, key: CharPtr.toCharPtr(str: "month"), value: stm.getMonth())
            setfield(L: L, key: CharPtr.toCharPtr(str: "year"), value: stm.getYear())
            setfield(L: L, key: CharPtr.toCharPtr(str: "wday"), value: Int(stm.getDayOfWeek()))
            setfield(L: L, key: CharPtr.toCharPtr(str: "yday"), value: stm.getDayOfYear())
            setboolfield(L: L, key: CharPtr.toCharPtr(str: "isdst"), value: stm.IsDaylightSavingTime() ? 1 : 0)
        }
        else {
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "strftime not implemented yet")) // todo: implement this - mjf
            ///#if false
            //                CharPtr cc = new char[3];
            //                luaL_Buffer b;
            //                cc[0] = '%';
            //                cc[2] = '\0';
            //                luaL_buffinit(L, b);
            //                for (; s[0] != 0; s.inc())
            //                {
            //                    if (s[0] != '%' || s[1] == '\0')  /* no conversion specifier? */
            //                    {
            //                        luaL_addchar(b, s[0]);
            //                    }
            //                    else
            //                    {
            //                        uint reslen;
            //                        CharPtr buff = new char[200];  /* should be big enough for any conversion result */
            //                        s.inc();
            //                        cc[1] = s[0];
            //                        reslen = strftime(buff, buff.Length, cc, stm);
            //                        luaL_addlstring(b, buff, reslen);
            //                    }
            //                }
            //                luaL_pushresult(b);
            ///#endif // #if 0
        }
        return 1
    }
    
    fileprivate static func os_time(L:lua_State!) -> Int {
        var t:DateTimeProxy! = DateTimeProxy()
        if (Lua.lua_isnoneornil(L: L, n: 1)) { // called without args?
            t.setNow() // get current time
        }
        else {
            LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TTABLE)
            LuaAPI.lua_settop(L: L, idx: 1) // make sure table is at the top
            let sec:Int = getfield(L: L, key: CharPtr.toCharPtr(str: "sec"), d: 0)
            let min:Int = getfield(L: L, key: CharPtr.toCharPtr(str: "min"), d: 0)
            let hour:Int = getfield(L: L, key: CharPtr.toCharPtr(str: "hour"), d: 12)
            let day:Int = getfield(L: L, key: CharPtr.toCharPtr(str: "day"), d: -1)
            let month:Int = getfield(L: L, key: CharPtr.toCharPtr(str: "month"), d: -1) - 1
            let year:Int = getfield(L: L, key: CharPtr.toCharPtr(str: "year"), d: -1) - 1900
            _/*let isdst:Int*/ = getboolfield(L: L, key: CharPtr.toCharPtr(str: "isdst")) // todo: implement this - mjf
            t = DateTimeProxy(year: year, month: month, day: day, hour: hour, min: min, sec: sec)
        }
        LuaAPI.lua_pushnumber(L: L, n: t.getTicks())
        return 1
    }
    
    fileprivate static func os_difftime(L:lua_State!) -> Int {
        let ticks:Int64 = Int64(LuaAuxLib.luaL_checknumber(L: L, narg: 1)) - Int64(LuaAuxLib.luaL_optnumber(L: L, narg: 2, def: 0))
        LuaAPI.lua_pushnumber(L: L, n: Double(ticks / 10000000)) //FIXME: ticks / TimeSpan.TicksPerSecond
        return 1
    }
    
    // }======================================================
    
    // locale not supported yets
    fileprivate static func os_setlocale(L:lua_State!) -> Int {
        //
        //          static string[] cat = {LC_ALL, LC_COLLATE, LC_CTYPE, LC_MONETARY,
        //                              LC_NUMERIC, LC_TIME};
        //          static string[] catnames[] = {"all", "collate", "ctype", "monetary",
        //             "numeric", "time", null};
        //          CharPtr l = luaL_optstring(L, 1, null);
        //          int op = luaL_checkoption(L, 2, "all", catnames);
        //          lua_pushstring(L, setlocale(cat[op], l));
        //
        let l:CharPtr! = LuaAuxLib.luaL_optstring(L: L, n: 1, d: nil)
        LuaAPI.lua_pushstring(L: L, s: CharPtr.toCharPtr(str: "C"))
        return (l.toString() == "C") ? 1 : 0
    }
    
    fileprivate static func os_exit(L:lua_State!) -> Int {
        exit(Int32(CLib.EXIT_SUCCESS))
        //return 0
    }
    
    private static let syslib:[luaL_Reg]! = [
        luaL_Reg(name: CharPtr.toCharPtr(str: "clock"), func_: LuaOSLib_delegate(name: "os_clock")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "date"), func_: LuaOSLib_delegate(name: "os_date")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "difftime"), func_: LuaOSLib_delegate(name: "os_difftime")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "execute"), func_: LuaOSLib_delegate(name: "os_execute")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "exit"), func_: LuaOSLib_delegate(name: "os_exit")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "getenv"), func_: LuaOSLib_delegate(name: "os_getenv")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "remove"), func_: LuaOSLib_delegate(name: "os_remove")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "rename"), func_: LuaOSLib_delegate(name: "os_rename")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "setlocale"), func_: LuaOSLib_delegate(name: "os_setlocale")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "time"), func_: LuaOSLib_delegate(name: "os_time")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "tmpname"), func_: LuaOSLib_delegate(name: "os_tmpname")),
        luaL_Reg(name: nil, func_: nil)
    ]
}

public class LuaOSLib_delegate: lua_CFunction {
    private var name:String!
    
    public init(name:String!) {
        self.name = name
    }
    
    public func exec(L:lua_State!) -> Int {
        if ("os_clock" == name) {
            return LuaOSLib.os_clock(L: L)
        }
        else if ("os_date" == name) {
            return LuaOSLib.os_date(L: L)
        }
        else if ("os_difftime" == name) {
            return LuaOSLib.os_difftime(L: L)
        }
        else if ("os_execute" == name) {
            return LuaOSLib.os_execute(L: L)
        }
        else if ("os_exit" == name) {
            return LuaOSLib.os_exit(L: L)
        }
        else if ("os_getenv" == name) {
            return LuaOSLib.os_getenv(L: L)
        }
        else if ("os_remove" == name) {
            return LuaOSLib.os_remove(L: L)
        }
        else if ("os_rename" == name) {
            return LuaOSLib.os_rename(L: L)
        }
        else if ("os_setlocale" == name) {
            return LuaOSLib.os_setlocale(L: L)
        }
        else if ("os_time" == name) {
            return LuaOSLib.os_time(L: L)
        }
        else if ("os_tmpname" == name) {
            return LuaOSLib.os_tmpname(L: L)
        }
        else {
            return 0
        }
    }

    
    // }======================================================
}

extension LuaOSLib {
    public static func luaopen_os(L:lua_State!) -> Int {
        LuaAuxLib.luaL_register(L: L, libname: CharPtr.toCharPtr(str: LuaLib.LUA_OSLIBNAME), l: syslib)
        return 1
    }
}
