//package kurumi;

//
// ** $Id: lbaselib.c,v 1.191.1.6 2008/02/14 16:46:22 roberto Exp $
// ** Basic library
// ** See Copyright Notice in lua.h
//

//using lua_Number = System.Double;

public class LuaBaseLib {
    //
    //         ** If your system does not support `stdout', you can just remove this function.
    //         ** If you need, you can define your own `print' function, following this
    //         ** model but changing `fputs' to put the strings at a proper place
    //         ** (a console window or a log file, for instance).
    //
    fileprivate static func luaB_print(L:lua_State!) -> Int {
        let n:Int = LuaAPI.lua_gettop(L: L) // number of arguments
        Lua.lua_getglobal(L: L, s: CharPtr.toCharPtr(str: "tostring"))
        for i:Int in 1...n {
            var s:CharPtr!
            LuaAPI.lua_pushvalue(L: L, idx: -1) // function to be called
            LuaAPI.lua_pushvalue(L: L, idx: i) // value to print
            LuaAPI.lua_call(L: L, nargs: 1, nresults: 1)
            s = Lua.lua_tostring(L: L, i: -1) // get result
            if (CharPtr.isEqual(ptr1: s, ptr2: nil)) {
                return LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: LuaConf.LUA_QL(x: "tostring").toString() + " must return a string to " + LuaConf.LUA_QL(x: "print").toString())) //FIXME:
            }
            if (i > 1) {
                CLib.fputs(str: CharPtr.toCharPtr(str: "\t"), stream: CLib.stdout)
            }
            CLib.fputs(str: s, stream: CLib.stdout)
            Lua.lua_pop(L: L, n: 1) // pop result
        }
        //FIXME:
        //Console.Write("\n", CLib.stdout);
        StreamProxy.Write(str: "\n")
        return 0
    }
    
    
    fileprivate static func luaB_tonumber(L:lua_State!) -> Int {
        let base_:Int = LuaAuxLib.luaL_optint(L: L, n: 2, d: 10)
        if (base_ == 10) {
            // standard conversion
            LuaAuxLib.luaL_checkany(L: L, narg: 1)
            if (LuaAPI.lua_isnumber(L: L, idx: 1) != 0) {
                LuaAPI.lua_pushnumber(L: L, n: LuaAPI.lua_tonumber(L: L, idx: 1))
                return 1
            }
        }
        else {
            let s1:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 1)
            var s2:[CharPtr]! = [CharPtr](repeating: CharPtr(), count: 1)
            s2[0] = CharPtr()
            var n:Int64 //ulong
            LuaAuxLib.luaL_argcheck(L: L, cond: 2 <= base_ && base_ <= 36, numarg: 2, extramsg: "base out of range");
            n = CLib.strtoul(s: s1, end: s2, base_: base_); //out
            if (CharPtr.isNotEqual(ptr1: s1, ptr2: s2[0])) {
                // at least one valid digit?
                while (CLib.isspace(c: Int(ClassType.charToByte(ch: s2[0].get(offset: 0))))) {
                    s2[0] = s2[0].next() // skip trailing spaces
                }
                if (s2[0].get(offset: 0) == "\0") {
                    // no invalid trailing characters?
                    LuaAPI.lua_pushnumber(L: L, n: Double(n)) //lua_Number
                    return 1
                }
            }
        }
        LuaAPI.lua_pushnil(L: L) // else not a number
        return 1
    }
    
    fileprivate static func luaB_error(L:lua_State!) -> Int {
        let level:Int = LuaAuxLib.luaL_optint(L: L, n: 2, d: 1)
        LuaAPI.lua_settop(L: L, idx: 1);
        if ((LuaAPI.lua_isstring(L: L, idx: 1) != 0) && (level > 0)) {
            // add extra information?
            LuaAuxLib.luaL_where(L: L, level: level)
            LuaAPI.lua_pushvalue(L: L, idx: 1)
            LuaAPI.lua_concat(L: L, n: 2)
        }
        return LuaAPI.lua_error(L: L)
    }
    
    fileprivate static func luaB_getmetatable(L:lua_State) -> Int {
        LuaAuxLib.luaL_checkany(L: L, narg: 1)
        if (LuaAPI.lua_getmetatable(L: L, objindex: 1) == 0) {
            LuaAPI.lua_pushnil(L: L)
            return 1 // no metatable
        }
        _ = LuaAuxLib.luaL_getmetafield(L: L, obj: 1, event_: CharPtr.toCharPtr(str: "__metatable"))
        return 1 // returns either __metatable field (if present) or metatable
    }
    
    fileprivate static func luaB_setmetatable(L:lua_State!) -> Int {
        let t:Int = LuaAPI.lua_type(L: L, idx: 2)
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TTABLE)
        LuaAuxLib.luaL_argcheck(L: L, cond: t == Lua.LUA_TNIL || t == Lua.LUA_TTABLE, numarg: 2, extramsg: "nil or table expected")
        if (LuaAuxLib.luaL_getmetafield(L: L, obj: 1, event_: CharPtr.toCharPtr(str: "__metatable")) != 0) {
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "cannot change a protected metatable"))
        }
        LuaAPI.lua_settop(L: L, idx: 2)
        _ = LuaAPI.lua_setmetatable(L: L, objindex: 1)
        return 1
    }
    
    private static func getfunc(L:lua_State!, opt:Int) {
        if (Lua.lua_isfunction(L: L, n: 1)) {
            LuaAPI.lua_pushvalue(L: L, idx: 1)
        }
        else {
            let ar:lua_Debug! = lua_Debug()
            let level:Int = (opt != 0) ? LuaAuxLib.luaL_optint(L: L, n: 1, d: 1) : LuaAuxLib.luaL_checkint(L: L, n: 1)
            LuaAuxLib.luaL_argcheck(L: L, cond: level >= 0, numarg: 1, extramsg: "level must be non-negative")
            if (LuaDebug.lua_getstack(L: L, level: level, ar: ar) == 0) {
                _ = LuaAuxLib.luaL_argerror(L: L, narg: 1, extramsg: CharPtr.toCharPtr(str: "invalid level"))
            }
            _ = LuaDebug.lua_getinfo(L: L, what: CharPtr.toCharPtr(str: "f"), ar: ar)
            if (Lua.lua_isnil(L: L, n: -1)) {
                _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "no function environment for tail call at level %d"), p: level)
            }
        }
    }
    
    fileprivate static func luaB_getfenv(L:lua_State!) -> Int {
        getfunc(L: L, opt: 1)
        if (LuaAPI.lua_iscfunction(L: L, idx: -1)) { // is a C function?
            LuaAPI.lua_pushvalue(L: L, idx: Lua.LUA_GLOBALSINDEX) // return the thread's global env.
        }
        else {
            LuaAPI.lua_getfenv(L: L, idx: -1)
        }
        return 1
    }
    
    fileprivate static func luaB_setfenv(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checktype(L: L, narg: 2, t: Lua.LUA_TTABLE)
        getfunc(L: L, opt: 0)
        LuaAPI.lua_pushvalue(L: L, idx: 2)
        if ((LuaAPI.lua_isnumber(L: L, idx: 1) != 0) && (LuaAPI.lua_tonumber(L: L, idx: 1) == 0)) {
            // change environment of current thread
            _ = LuaAPI.lua_pushthread(L: L)
            LuaAPI.lua_insert(L: L, idx: -2)
            _ = LuaAPI.lua_setfenv(L: L, idx: -2)
            return 0;
        }
        else if (LuaAPI.lua_iscfunction(L: L, idx: -2) || LuaAPI.lua_setfenv(L: L, idx: -2) == 0) {
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: LuaConf.LUA_QL(x: "setfenv").toString() + " cannot change environment of given object"))
        }
        return 1
    }
    
    fileprivate static func luaB_rawequal(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checkany(L: L, narg: 1)
        LuaAuxLib.luaL_checkany(L: L, narg: 2)
        LuaAPI.lua_pushboolean(L: L, b: LuaAPI.lua_rawequal(L: L, index1: 1, index2: 2))
        return 1
    }
    
    fileprivate static func luaB_rawget(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TTABLE)
        LuaAuxLib.luaL_checkany(L: L, narg: 2)
        LuaAPI.lua_settop(L: L, idx: 2)
        LuaAPI.lua_rawget(L: L, idx: 1)
        return 1
    }
    
    fileprivate static func luaB_rawset(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TTABLE)
        LuaAuxLib.luaL_checkany(L: L, narg: 2)
        LuaAuxLib.luaL_checkany(L: L, narg: 3)
        LuaAPI.lua_settop(L: L, idx: 3)
        LuaAPI.lua_rawset(L: L, idx: 1)
        return 1
    }
    
    fileprivate static func luaB_gcinfo(L:lua_State!) -> Int {
        LuaAPI.lua_pushinteger(L: L, n: Lua.lua_getgccount(L: L))
        return 1
    }
    
    
    public static let opts:[CharPtr?] = [
        CharPtr.toCharPtr(str: "stop"),
        CharPtr.toCharPtr(str: "restart"),
        CharPtr.toCharPtr(str: "collect"),
        CharPtr.toCharPtr(str: "count"),
        CharPtr.toCharPtr(str: "step"),
        CharPtr.toCharPtr(str: "setpause"),
        CharPtr.toCharPtr(str: "setstepmul"),
        nil
    ]
    
    
    public static let optsnum:[Int] = [
        Lua.LUA_GCSTOP,
        Lua.LUA_GCRESTART,
        Lua.LUA_GCCOLLECT,
        Lua.LUA_GCCOUNT,
        Lua.LUA_GCSTEP,
        Lua.LUA_GCSETPAUSE,
        Lua.LUA_GCSETSTEPMUL
    ]
    
    
    fileprivate static func luaB_collectgarbage(L:lua_State!) -> Int {
        let o:Int = LuaAuxLib.luaL_checkoption(L: L, narg: 1, def: CharPtr.toCharPtr(str: "collect"), lst: opts)
        let ex:Int = LuaAuxLib.luaL_optint(L: L, n: 2, d: 0)
        let res:Int = LuaAPI.lua_gc(L: L, what: optsnum[o], data: ex)
        switch (optsnum[o]) {
        case Lua.LUA_GCCOUNT:
            let b:Int = LuaAPI.lua_gc(L: L, what: Lua.LUA_GCCOUNTB, data: 0);
            LuaAPI.lua_pushnumber(L: L, n: Double(res) + (Double(b) / 1024)) //lua_Number
            return 1;
        
        case Lua.LUA_GCSTEP:
            LuaAPI.lua_pushboolean(L: L, b: res)
            return 1;
        
        default:
            LuaAPI.lua_pushnumber(L: L, n: Double(res))
            return 1;
        }
    }
    
    fileprivate static func luaB_type(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checkany(L: L, narg: 1)
        LuaAPI.lua_pushstring(L: L, s: LuaAuxLib.luaL_typename(L: L, i: 1))
        return 1
    }
    
    fileprivate static func luaB_next(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TTABLE);
        LuaAPI.lua_settop(L: L, idx: 2); // create a 2nd argument if there isn't one
        if (LuaAPI.lua_next(L: L, idx: 1) != 0) {
            return 2
        }
        else {
            LuaAPI.lua_pushnil(L: L)
            return 1
        }
    }
    
    fileprivate static func luaB_pairs(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TTABLE)
        LuaAPI.lua_pushvalue(L: L, idx: Lua.lua_upvalueindex(i: 1)) // return generator,
        LuaAPI.lua_pushvalue(L: L, idx: 1) // state,
        LuaAPI.lua_pushnil(L: L) // and initial value
        return 3
    }
    
    fileprivate static func ipairsaux(L:lua_State!) -> Int {
        var i:Int = LuaAuxLib.luaL_checkint(L: L, n: 2)
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TTABLE)
        i += 1 // next value
        LuaAPI.lua_pushinteger(L: L, n: i)
        LuaAPI.lua_rawgeti(L: L, idx: 1, n: i)
        return (Lua.lua_isnil(L: L, n: -1)) ? 0 : 2
    }
    
    fileprivate static func luaB_ipairs(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TTABLE)
        LuaAPI.lua_pushvalue(L: L, idx: Lua.lua_upvalueindex(i: 1)) // return generator,
        LuaAPI.lua_pushvalue(L: L, idx: 1) // state,
        LuaAPI.lua_pushinteger(L: L, n: 0) // and initial value
        return 3
    }
    
    private static func load_aux(L:lua_State!, status:Int) -> Int {
        if (status == 0) { // OK?
            return 1
        }
        else {
            LuaAPI.lua_pushnil(L: L)
            LuaAPI.lua_insert(L: L, idx: -2) // put before error message
            return 2 // return nil plus error message
        }
    }
    
    fileprivate static func luaB_loadstring(L:lua_State!) -> Int {
        var l:[Int]! = [Int](repeating: 0, count: 1) //uint
        let s:CharPtr! = LuaAuxLib.luaL_checklstring(L: L, narg: 1, len: l) //out
        let chunkname:CharPtr! = LuaAuxLib.luaL_optstring(L: L, n: 2, d: s)
        return load_aux(L: L, status: LuaAuxLib.luaL_loadbuffer(L: L, buff: s, size: l[0], name: chunkname))
    }
    
    fileprivate static func luaB_loadfile(L:lua_State!) -> Int {
        let fname:CharPtr! = LuaAuxLib.luaL_optstring(L: L, n: 1, d: nil)
        return load_aux(L: L, status: LuaAuxLib.luaL_loadfile(L: L, filename: fname))
    }
    
    //
    //         ** Reader for generic `load' function: `lua_load' uses the
    //         ** stack for internal stuff, so the reader cannot change the
    //         ** stack top. Instead, it keeps its resulting string in a
    //         ** reserved slot inside the stack.
    //
    fileprivate static func generic_reader(L:lua_State!, ud:Any!, size:inout [Int]!) -> CharPtr! { //uint - out
        //(void)ud;  /* to avoid warnings */
        LuaAuxLib.luaL_checkstack(L: L, space: 2, mes: CharPtr.toCharPtr(str: "too many nested functions"))
        LuaAPI.lua_pushvalue(L: L, idx: 1) // get function
        LuaAPI.lua_call(L: L, nargs: 0, nresults: 1) // call it
        if (Lua.lua_isnil(L: L, n: -1)) {
            size[0] = 0
            return nil
        }
        else if (LuaAPI.lua_isstring(L: L, idx: -1) != 0) {
            LuaAPI.lua_replace(L: L, idx: 3) // save string in a reserved stack slot
            return LuaAPI.lua_tolstring(L: L, idx: 3, len: size) //out
        }
        else {
            size[0] = 0
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "reader function must return a string"))
        }
        return nil // to avoid warnings
    }
}

public class generic_reader_delegate: lua_Reader {
    public func exec(L:lua_State!, ud:Any!, sz:inout [Int]!) -> CharPtr! { //uint - out
        return LuaBaseLib.generic_reader(L: L, ud: ud, size: &sz) //out
    }
}

extension LuaBaseLib {
    fileprivate static func luaB_load(L:lua_State!) -> Int {
        var status:Int
        let cname:CharPtr! = LuaAuxLib.luaL_optstring(L: L, n: 2, d: CharPtr.toCharPtr(str: "=(load)"))
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TFUNCTION)
        LuaAPI.lua_settop(L: L, idx: 3) // function, eventual name, plus one reserved slot
        status = LuaAPI.lua_load(L: L, reader: generic_reader_delegate(), data: nil, chunkname: cname)
        return load_aux(L: L, status: status)
    }
    
    fileprivate static func luaB_dofile(L:lua_State!) -> Int {
        let fname:CharPtr! = LuaAuxLib.luaL_optstring(L: L, n: 1, d: nil)
        let n:Int = LuaAPI.lua_gettop(L: L)
        if (LuaAuxLib.luaL_loadfile(L: L, filename: fname) != 0) {
            _ = LuaAPI.lua_error(L: L)
        }
        LuaAPI.lua_call(L: L, nargs: 0, nresults: Lua.LUA_MULTRET)
        return LuaAPI.lua_gettop(L: L) - n
    }
    
    fileprivate static func luaB_assert(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checkany(L: L, narg: 1)
        if (LuaAPI.lua_toboolean(L: L, idx: 1) == 0) {
            return LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "%s"), p: LuaAuxLib.luaL_optstring(L: L, n: 2, d: CharPtr.toCharPtr(str: "assertion failed!")))
        }
        return LuaAPI.lua_gettop(L: L)
    }
    
    fileprivate static func luaB_unpack(L:lua_State!) -> Int {
        var i:Int, e:Int, n:Int
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TTABLE)
        i = LuaAuxLib.luaL_optint(L: L, n: 2, d: 1)
        e = LuaAuxLib.luaL_opt_integer(L: L, f: luaL_checkint_delegate(), n: 3, d: Double(LuaAuxLib.luaL_getn(L: L, i: 1)))
        if (i > e) {
            return 0 // empty range
        }
        n = e - i + 1; // number of elements
        if (n <= 0 || (LuaAPI.lua_checkstack(L: L, size: n) == 0)) { // n <= 0 means arith. overflow
            return LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "too many results to unpack"))
        }
        LuaAPI.lua_rawgeti(L: L, idx: 1, n: i) // push arg[i] (avoiding overflow problems)
        while (i < e) { // push arg[i + 1...e]
            i += 1
            LuaAPI.lua_rawgeti(L: L, idx: 1, n: i);
        }
        i += 1
        return n
    }
    
    
    fileprivate static func luaB_select(L:lua_State!) -> Int {
        let n:Int = LuaAPI.lua_gettop(L: L)
        if (LuaAPI.lua_type(L: L, idx: 1) == Lua.LUA_TSTRING && Lua.lua_tostring(L: L, i: 1).get(offset: 0) == "#") {
            LuaAPI.lua_pushinteger(L: L, n: n - 1)
            return 1
        }
        else {
            var i:Int = LuaAuxLib.luaL_checkint(L: L, n: 1)
            if (i < 0) {
                i = n + i
            }
            else if (i > n) {
                i = n
            }
            LuaAuxLib.luaL_argcheck(L: L, cond: 1 <= i, numarg: 1, extramsg: "index out of range")
            return n - i
        }
    }
    
    fileprivate static func luaB_pcall(L:lua_State!) -> Int {
        var status:Int
        LuaAuxLib.luaL_checkany(L: L, narg: 1)
        status = LuaAPI.lua_pcall(L: L, nargs: LuaAPI.lua_gettop(L: L) - 1, nresults: Lua.LUA_MULTRET, errfunc: 0)
        LuaAPI.lua_pushboolean(L: L, b: (status == 0) ? 1 : 0)
        LuaAPI.lua_insert(L: L, idx: 1)
        return LuaAPI.lua_gettop(L: L) // return status + all results
    }
    
    fileprivate static func luaB_xpcall(L:lua_State!) -> Int {
        var status:Int
        LuaAuxLib.luaL_checkany(L: L, narg: 2)
        LuaAPI.lua_settop(L: L, idx: 2)
        LuaAPI.lua_insert(L: L, idx: 1) // put error function under function to be called
        status = LuaAPI.lua_pcall(L: L, nargs: 0, nresults: Lua.LUA_MULTRET, errfunc: 1)
        LuaAPI.lua_pushboolean(L: L, b: (status == 0) ? 1 : 0)
        LuaAPI.lua_replace(L: L, idx: 1)
        return LuaAPI.lua_gettop(L: L) // return status + all results
    }
    
    fileprivate static func luaB_tostring(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checkany(L: L, narg: 1)
        if (LuaAuxLib.luaL_callmeta(L: L, obj: 1, event_: CharPtr.toCharPtr(str: "__tostring")) != 0) { // is there a metafield?
            return 1 // use its value
        }
        switch (LuaAPI.lua_type(L: L, idx: 1)) {
        case Lua.LUA_TNUMBER:
            LuaAPI.lua_pushstring(L: L, s: Lua.lua_tostring(L: L, i: 1))
            break
        
        case Lua.LUA_TSTRING:
            LuaAPI.lua_pushvalue(L: L, idx: 1)
            break
        
        case Lua.LUA_TBOOLEAN:
            LuaAPI.lua_pushstring(L: L, s: (LuaAPI.lua_toboolean(L: L, idx: 1) != 0 ? CharPtr.toCharPtr(str: "true") : CharPtr.toCharPtr(str: "false")))
            break
        
        case Lua.LUA_TNIL:
            Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: "nil"))
            break
        
        default:
            _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: "%s: %p"), p: LuaAuxLib.luaL_typename(L: L, i: 1), LuaAPI.lua_topointer(L: L, idx: 1))
            break
        }
        return 1
    }
    
    fileprivate static func luaB_newproxy(L:lua_State!) -> Int {
        LuaAPI.lua_settop(L: L, idx: 1)
        _ = LuaAPI.lua_newuserdata(L: L, size: 0) // create proxy
        if (LuaAPI.lua_toboolean(L: L, idx: 1) == 0) {
            return 1 // no metatable
        }
        else if (Lua.lua_isboolean(L: L, n: 1)) {
            Lua.lua_newtable(L: L) // create a new metatable `m'...
            LuaAPI.lua_pushvalue(L: L, idx: -1) //... and mark `m' as a valid metatable
            LuaAPI.lua_pushboolean(L: L, b: 1)
            LuaAPI.lua_rawset(L: L, idx: Lua.lua_upvalueindex(i: 1)) // weaktable[m] = true
        }
        else {
            var validproxy:Int = 0 // to check if weaktable[metatable(u)] == true
            if (LuaAPI.lua_getmetatable(L: L, objindex: 1) != 0) {
                LuaAPI.lua_rawget(L: L, idx: Lua.lua_upvalueindex(i: 1))
                validproxy = LuaAPI.lua_toboolean(L: L, idx: -1)
                Lua.lua_pop(L: L, n: 1) // remove value
            }
            LuaAuxLib.luaL_argcheck(L: L, cond: validproxy != 0, numarg: 1, extramsg: "boolean or proxy expected");
            _ = LuaAPI.lua_getmetatable(L: L, objindex: 1) // metatable is valid; get it
        }
        _ = LuaAPI.lua_setmetatable(L: L, objindex: 2)
        return 1
    }
    
    
    
    private static let base_funcs:[luaL_Reg] = [
        luaL_Reg(name: CharPtr.toCharPtr(str: "assert"), func_: LuaBaseLib_delegate(name: "luaB_assert")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "collectgarbage"), func_: LuaBaseLib_delegate(name: "luaB_collectgarbage")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "dofile"), func_: LuaBaseLib_delegate(name: "luaB_dofile")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "error"), func_: LuaBaseLib_delegate(name: "luaB_error")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "gcinfo"), func_: LuaBaseLib_delegate(name: "luaB_gcinfo")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "getfenv"), func_: LuaBaseLib_delegate(name: "luaB_getfenv")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "getmetatable"), func_: LuaBaseLib_delegate(name: "luaB_getmetatable")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "loadfile"), func_: LuaBaseLib_delegate(name: "luaB_loadfile")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "load"), func_: LuaBaseLib_delegate(name: "luaB_load")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "loadstring"), func_: LuaBaseLib_delegate(name: "luaB_loadstring")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "next"), func_: LuaBaseLib_delegate(name: "luaB_next")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "pcall"), func_: LuaBaseLib_delegate(name: "luaB_pcall")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "print"), func_: LuaBaseLib_delegate(name: "luaB_print")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "rawequal"), func_: LuaBaseLib_delegate(name: "luaB_rawequal")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "rawget"), func_: LuaBaseLib_delegate(name: "luaB_rawget")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "rawset"), func_: LuaBaseLib_delegate(name: "luaB_rawset")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "select"), func_: LuaBaseLib_delegate(name: "luaB_select")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "setfenv"), func_: LuaBaseLib_delegate(name: "luaB_setfenv")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "setmetatable"), func_: LuaBaseLib_delegate(name: "luaB_setmetatable")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "tonumber"), func_: LuaBaseLib_delegate(name: "luaB_tonumber")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "tostring"), func_: LuaBaseLib_delegate(name: "luaB_tostring")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "type"), func_: LuaBaseLib_delegate(name: "luaB_type")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "unpack"), func_: LuaBaseLib_delegate(name: "luaB_unpack")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "xpcall"), func_: LuaBaseLib_delegate(name: "luaB_xpcall")),
        luaL_Reg(name: nil, func_: nil)
    ]
}

public class LuaBaseLib_delegate: lua_CFunction {
    private var name:String!
    
    public init(name:String!) {
        self.name = name
    }
    
    public func exec(L:lua_State!) -> Int {
        if ("luaB_assert" == name) {
            return LuaBaseLib.luaB_assert(L: L)
        }
        else if ("luaB_collectgarbage" == name) {
            return LuaBaseLib.luaB_collectgarbage(L: L)
        }
        else if ("luaB_dofile" == name) {
            return LuaBaseLib.luaB_dofile(L: L)
        }
        else if ("luaB_error" == name) {
            return LuaBaseLib.luaB_error(L: L)
        }
        else if ("luaB_gcinfo" == name) {
            return LuaBaseLib.luaB_gcinfo(L: L)
        }
        else if ("luaB_getfenv" == name) {
            return LuaBaseLib.luaB_getfenv(L: L)
        }
        else if ("luaB_getmetatable" == name) {
            return LuaBaseLib.luaB_getmetatable(L: L)
        }
        else if ("luaB_loadfile" == name) {
            return LuaBaseLib.luaB_loadfile(L: L)
        }
        else if ("luaB_load" == name) {
            return LuaBaseLib.luaB_load(L: L)
        }
        else if ("luaB_loadstring" == name) {
            return LuaBaseLib.luaB_loadstring(L: L)
        }
        else if ("luaB_next" == name) {
            return LuaBaseLib.luaB_next(L: L)
        }
        else if ("luaB_pcall" == name) {
            return LuaBaseLib.luaB_pcall(L: L)
        }
        else if ("luaB_print" == name) {
            return LuaBaseLib.luaB_print(L: L)
        }
        else if ("luaB_rawequal" == name) {
            return LuaBaseLib.luaB_rawequal(L: L)
        }
        else if ("luaB_rawget" == name) {
            return LuaBaseLib.luaB_rawget(L: L)
        }
        else if ("luaB_rawset" == name) {
            return LuaBaseLib.luaB_rawset(L: L)
        }
        else if ("luaB_select" == name) {
            return LuaBaseLib.luaB_select(L: L)
        }
        else if ("luaB_setfenv" == name) {
            return LuaBaseLib.luaB_setfenv(L: L)
        }
        else if ("luaB_setmetatable" == name) {
            return LuaBaseLib.luaB_setmetatable(L: L)
        }
        else if ("luaB_tonumber" == name) {
            return LuaBaseLib.luaB_tonumber(L: L)
        }
        else if ("luaB_tostring" == name) {
            return LuaBaseLib.luaB_tostring(L: L)
        }
        else if ("luaB_type" == name) {
            return LuaBaseLib.luaB_type(L: L)
        }
        else if ("luaB_unpack" == name) {
            return LuaBaseLib.luaB_unpack(L: L)
        }
        else if ("luaB_xpcall" == name) {
            return LuaBaseLib.luaB_xpcall(L: L)
        }
        if ("luaB_cocreate" == name) {
            return LuaBaseLib.luaB_cocreate(L: L)
        }
        else if ("luaB_coresume" == name) {
            return LuaBaseLib.luaB_coresume(L: L)
        }
        else if ("luaB_corunning" == name) {
            return LuaBaseLib.luaB_corunning(L: L)
        }
        else if ("luaB_costatus" == name) {
            return LuaBaseLib.luaB_costatus(L: L)
        }
        else if ("luaB_cowrap" == name) {
            return LuaBaseLib.luaB_cowrap(L: L)
        }
        else if ("luaB_yield" == name) {
            return LuaBaseLib.luaB_yield(L: L)
        }
        else if ("luaB_ipairs" == name) {
            return LuaBaseLib.luaB_ipairs(L: L)
        }
        else if ("ipairsaux" == name) {
            return LuaBaseLib.ipairsaux(L: L)
        }
        else if ("luaB_pairs" == name) {
            return LuaBaseLib.luaB_pairs(L: L)
        }
        else if ("luaB_next" == name) {
            return LuaBaseLib.luaB_next(L: L)
        }
        else if ("luaB_newproxy" == name) {
            return LuaBaseLib.luaB_newproxy(L: L)
        }
        else if ("luaB_auxwrap" == name) {
            return LuaBaseLib.luaB_auxwrap(L: L)
        }
        else {
            return 0
        }
    }
}

extension LuaBaseLib {
    //
    //         ** {======================================================
    //         ** Coroutine library
    //         ** =======================================================
    //
    
    public static let CO_RUN:Int = 0 // running
    public static let CO_SUS:Int = 1 // suspended
    public static let CO_NOR:Int = 2 // 'normal' (it resumed another coroutine)
    public static let CO_DEAD:Int = 3
    
    private static let statnames:[String] = [ "running", "suspended", "normal", "dead" ]

    
    private static func costatus(L:lua_State!, co:lua_State!) -> Int {
        if (L === co) {
            return CO_RUN
        }
        switch (LuaAPI.lua_status(L: co)) {
        case Lua.LUA_YIELD:
            return CO_SUS
        
        case 0:
            let ar:lua_Debug! = lua_Debug()
            if (LuaDebug.lua_getstack(L: co, level: 0, ar: ar) > 0) { // does it have frames?
                return CO_NOR // it is running
            }
            else if (LuaAPI.lua_gettop(L: co) == 0) {
                return CO_DEAD
            }
            else {
                return CO_SUS // initial state
            }
        
        default: // some error occured
            return CO_DEAD
        }
    }
    
    fileprivate static func luaB_costatus(L:lua_State!) -> Int {
        let co:lua_State! = LuaAPI.lua_tothread(L: L, idx: 1)
        LuaAuxLib.luaL_argcheck(L: L, cond: co != nil, numarg: 1, extramsg: "coroutine expected")
        LuaAPI.lua_pushstring(L: L, s: CharPtr.toCharPtr(str: statnames[costatus(L: L, co: co)]))
        return 1
    }
    
    private static func auxresume(L:lua_State!, co:lua_State!, narg:Int) -> Int {
        var status:Int = costatus(L: L, co: co)
        if (LuaAPI.lua_checkstack(L: co, size: narg) == 0) {
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "too many arguments to resume"))
        }
        if (status != CO_SUS) {
            _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: "cannot resume %s coroutine"), p: statnames[status])
            return -1 // error flag
        }
        LuaAPI.lua_xmove(from: L, to: co, n: narg)
        LuaAPI.lua_setlevel(from: L, to: co)
        status = LuaDo.lua_resume(L: co, nargs: narg)
        if (status == 0 || status == Lua.LUA_YIELD) {
            let nres:Int = LuaAPI.lua_gettop(L: co)
            if (LuaAPI.lua_checkstack(L: L, size: nres + 1) == 0) {
                _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "too many results to resume"))
            }
            LuaAPI.lua_xmove(from: co, to: L, n: nres) // move yielded values
            return nres
        }
        else {
            LuaAPI.lua_xmove(from: co, to: L, n: 1) // move error message
            return -1 // error flag
        }
    }
    
    fileprivate static func luaB_coresume(L:lua_State!) -> Int {
        let co:lua_State! = LuaAPI.lua_tothread(L: L, idx: 1)
        var r:Int
        LuaAuxLib.luaL_argcheck(L: L, cond: co != nil, numarg: 1, extramsg: "coroutine expected")
        r = auxresume(L: L, co: co, narg: LuaAPI.lua_gettop(L: L) - 1)
        if (r < 0) {
            LuaAPI.lua_pushboolean(L: L, b: 0)
            LuaAPI.lua_insert(L: L, idx: -2)
            return 2 // return false + error message
        }
        else {
            LuaAPI.lua_pushboolean(L: L, b: 1)
            LuaAPI.lua_insert(L: L, idx: -(r + 1))
            return r + 1 // return true + `resume' returns
        }
    }
    
    fileprivate static func luaB_auxwrap(L:lua_State!) -> Int {
        let co:lua_State! = LuaAPI.lua_tothread(L: L, idx: Lua.lua_upvalueindex(i: 1))
        let r:Int = auxresume(L: L, co: co, narg: LuaAPI.lua_gettop(L: L))
        if (r < 0) {
            if (LuaAPI.lua_isstring(L: L, idx: -1) != 0) {
                // error object is a string?
                LuaAuxLib.luaL_where(L: L, level: 1) // add extra info
                LuaAPI.lua_insert(L: L, idx: -2)
                LuaAPI.lua_concat(L: L, n: 2)
            }
            _ = LuaAPI.lua_error(L: L) // propagate error
        }
        return r
    }
    
    fileprivate static func luaB_cocreate(L:lua_State!) -> Int {
        let NL:lua_State! = LuaAPI.lua_newthread(L: L)
        LuaAuxLib.luaL_argcheck(L: L, cond: Lua.lua_isfunction(L: L, n: 1) && !LuaAPI.lua_iscfunction(L: L, idx: 1), numarg: 1, extramsg: "Lua function expected")
        LuaAPI.lua_pushvalue(L: L, idx: 1) // move function to top
        LuaAPI.lua_xmove(from: L, to: NL, n: 1) // move function from L to NL
        return 1
    }
    
    
    fileprivate static func luaB_cowrap(L:lua_State!) -> Int {
        _ = luaB_cocreate(L: L)
        LuaAPI.lua_pushcclosure(L: L, fn: LuaBaseLib_delegate(name: "luaB_auxwrap"), n: 1);
        return 1
    }
    
    fileprivate static func luaB_yield(L:lua_State!) -> Int {
        return LuaDo.lua_yield(L: L, nresults: LuaAPI.lua_gettop(L: L))
    }
    
    fileprivate static func luaB_corunning(L:lua_State!) -> Int {
        if (LuaAPI.lua_pushthread(L: L) != 0) {
            LuaAPI.lua_pushnil(L: L) // main thread is not a coroutine
        }
        return 1
    }
    
    
    private static let co_funcs:[luaL_Reg] = [
        luaL_Reg(name: CharPtr.toCharPtr(str: "create"), func_: LuaBaseLib_delegate(name: "luaB_cocreate")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "resume"), func_: LuaBaseLib_delegate(name: "luaB_coresume")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "running"), func_: LuaBaseLib_delegate(name: "luaB_corunning")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "status"), func_: LuaBaseLib_delegate(name: "luaB_costatus")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "wrap"), func_: LuaBaseLib_delegate(name: "luaB_cowrap")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "yield"), func_: LuaBaseLib_delegate(name: "luaB_yield")),
        luaL_Reg(name: nil, func_: nil)
    ]
    
    
    
    // }======================================================
    
    private static func auxopen(L:lua_State!, name:CharPtr!, f:lua_CFunction!, u:lua_CFunction!) {
        Lua.lua_pushcfunction(L: L, f: u)
        LuaAPI.lua_pushcclosure(L: L, fn: f, n: 1)
        LuaAPI.lua_setfield(L: L, idx: -2, k: name)
    }
    
    
    private static func base_open(L:lua_State!) {
        // set global _G
        LuaAPI.lua_pushvalue(L: L, idx: Lua.LUA_GLOBALSINDEX)
        Lua.lua_setglobal(L: L, s: CharPtr.toCharPtr(str: "_G"))
        // open lib into global table
        LuaAuxLib.luaL_register(L: L, libname: CharPtr.toCharPtr(str: "_G"), l: base_funcs);
        Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: Lua.LUA_VERSION))
        Lua.lua_setglobal(L: L, s: CharPtr.toCharPtr(str: "_VERSION")) // set global _VERSION
        // `ipairs' and `pairs' need auxliliary functions as upvalues
        auxopen(L: L, name: CharPtr.toCharPtr(str: "ipairs"), f: LuaBaseLib_delegate(name: "luaB_ipairs"), u: LuaBaseLib_delegate(name: "ipairsaux"))
        auxopen(L: L, name: CharPtr.toCharPtr(str: "pairs"), f: LuaBaseLib_delegate(name: "luaB_pairs"), u: LuaBaseLib_delegate(name: "luaB_next"))
        // `newproxy' needs a weaktable as upvalue
        LuaAPI.lua_createtable(L: L, narray: 0, nrec: 1) // new table `w'
        LuaAPI.lua_pushvalue(L: L, idx: -1) // `w' will be its own metatable
        _ = LuaAPI.lua_setmetatable(L: L, objindex: -2)
        Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: "kv"))
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "__mode")); // metatable(w).__mode = "kv"
        LuaAPI.lua_pushcclosure(L: L, fn: LuaBaseLib_delegate(name: "luaB_newproxy"), n: 1)
        Lua.lua_setglobal(L: L, s: CharPtr.toCharPtr(str: "newproxy")) // set global `newproxy'
    }
    
    public static func luaopen_base(L:lua_State!) -> Int {
        base_open(L: L)
        LuaAuxLib.luaL_register(L: L, libname: CharPtr.toCharPtr(str: LuaLib.LUA_COLIBNAME), l: co_funcs)
        return 2
    }
}
