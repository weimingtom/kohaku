//package kurumi;

//
// ** $Id: lstrlib.c,v 1.132.1.4 2008/07/11 17:27:21 roberto Exp $
// ** Standard library for string operations and pattern-matching
// ** See Copyright Notice in lua.h
//
//using ptrdiff_t = System.Int32;
//using lua_Integer = System.Int32;
//using LUA_INTFRM_T = System.Int64;
//using UNSIGNED_LUA_INTFRM_T = System.UInt64;

public class LuaStrLib {
    public static func str_len(L:lua_State!) -> Int {
        var l:[Int] = [Int](repeating: 0, count: 1) //uint
        _ = LuaAuxLib.luaL_checklstring(L: L, narg: 1, len: l) //out
        LuaAPI.lua_pushinteger(L: L, n: l[0]) //(int)
        return 1
    }
    
    private static func posrelat(pos:Int, len:Int) -> Int { //uint - ptrdiff_t - Int32 - ptrdiff_t - Int32
        var pos:Int = pos
        // relative string position: negative means back from end
        if (pos < 0) {
            pos += Int(len) + 1 //ptrdiff_t - Int32
        }
        return (pos >= 0) ? pos : 0
    }
    
    public static func str_sub(L:lua_State!) -> Int {
        var l:[Int] = [Int](repeating: 0, count: 1) //uint
        let s:CharPtr! = LuaAuxLib.luaL_checklstring(L: L, narg: 1, len: l); //out
        var start:Int = posrelat(pos: LuaAuxLib.luaL_checkinteger(L: L, narg: 2), len: l[0]) //ptrdiff_t - Int32
        var end:Int = posrelat(pos: LuaAuxLib.luaL_optinteger(L: L, narg: 3, def: -1), len: l[0]) //ptrdiff_t - Int32
        if (start < 1) {
            start = 1
        }
        if (end > Int(l[0])) { //ptrdiff_t - Int32
            end = Int(l[0]) //ptrdiff_t - Int32
        }
        if (start <= end) {
            LuaAPI.lua_pushlstring(L: L, s: CharPtr.plus(ptr: s, offset: start - 1), len: (end - start + 1)) //(uint)
        }
        else {
            Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: ""))
        }
        return 1
    }
    
    public static func str_reverse(L:lua_State!) -> Int {
        var l:[Int] = [Int](repeating: 0, count: 1) //uint
        let b:luaL_Buffer! = luaL_Buffer()
        let s:CharPtr! = LuaAuxLib.luaL_checklstring(L: L, narg: 1, len: l) //out
        LuaAuxLib.luaL_buffinit(L: L, B: b)
        while (true) {
            let l_:Int = l[0]
            l[0] -= 1
            if (l_ == 0) {
                break
            }
            LuaAuxLib.luaL_addchar(B: b, c: s.get(offset: l[0]))
        }
        LuaAuxLib.luaL_pushresult(B: b)
        return 1
    }
    
    public static func str_lower(L:lua_State!) -> Int {
        var l:[Int] = [Int](repeating: 0, count: 1) //uint
        let b:luaL_Buffer! = luaL_Buffer();
        let s:CharPtr! = LuaAuxLib.luaL_checklstring(L: L, narg: 1, len: l) //out
        LuaAuxLib.luaL_buffinit(L: L, B: b)
        for i:Int in 0 ..< l[0] {
            LuaAuxLib.luaL_addchar(B: b, c: CLib.tolower(c: s.get(offset: i)))
        }
        LuaAuxLib.luaL_pushresult(B: b)
        return 1
    }
    
    public static func str_upper(L:lua_State!) -> Int {
        var l:[Int] = [Int](repeating: 0, count: 1) //uint
        let b:luaL_Buffer! = luaL_Buffer()
        let s:CharPtr! = LuaAuxLib.luaL_checklstring(L: L, narg: 1, len: l) //out
        LuaAuxLib.luaL_buffinit(L: L, B: b)
        for i:Int in 0 ..< l[0] {
            LuaAuxLib.luaL_addchar(B: b, c: CLib.toupper(c: s.get(offset: i)));
        }
        LuaAuxLib.luaL_pushresult(B: b)
        return 1
    }
    
    public static func str_rep(L:lua_State!) -> Int {
        var l:[Int] = [Int](repeating: 0, count: 1) //uint
        let b:luaL_Buffer! = luaL_Buffer()
        let s:CharPtr! = LuaAuxLib.luaL_checklstring(L: L, narg: 1, len: l) //out
        var n:Int = LuaAuxLib.luaL_checkint(L: L, n: 2)
        LuaAuxLib.luaL_buffinit(L: L, B: b)
        while (true) {
            let n_ = n;
            n -= 1
            if (n_ <= 0) {
                break
            }
            LuaAuxLib.luaL_addlstring(B: b, s: s, l: l[0])
        }
        LuaAuxLib.luaL_pushresult(B: b);
        return 1
    }
    
    public static func str_byte(L:lua_State) -> Int {
        var l:[Int] = [Int](repeating: 0, count: 1) //uint
        let s:CharPtr! = LuaAuxLib.luaL_checklstring(L: L, narg: 1, len: l) //out
        var posi:Int = posrelat(pos: LuaAuxLib.luaL_optinteger(L: L, narg: 2, def: 1), len: l[0]); //ptrdiff_t - Int32
        var pose:Int = posrelat(pos: LuaAuxLib.luaL_optinteger(L: L, narg: 3, def: posi), len: l[0]); //ptrdiff_t - Int32
        var n:Int
        if (posi <= 0) {
            posi = 1;
        }
        if (Int(pose) > l[0]) { //uint
            pose = Int(l[0])
        }
        if (posi > pose) {
            return 0 // empty interval; return no values
        }
        n = Int(pose - posi + 1)
        if (posi + n <= pose) { // overflow?
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "string slice too long"));
        }
        LuaAuxLib.luaL_checkstack(L: L, space: n, mes: CharPtr.toCharPtr(str: "string slice too long"));
        for i in 0 ..< n {
            LuaAPI.lua_pushinteger(L: L, n: Int(ClassType.charToByte(ch: s.get(offset: posi + i - 1))))
        }
        return n
    }
    
    public static func str_char(L:lua_State!) -> Int {
        let n:Int = LuaAPI.lua_gettop(L: L) // number of arguments
        let b:luaL_Buffer! = luaL_Buffer()
        LuaAuxLib.luaL_buffinit(L: L, B: b)
        for i:Int in 1...n {
            let c:Int = LuaAuxLib.luaL_checkint(L: L, n: i)
            LuaAuxLib.luaL_argcheck(L: L, cond: Int8(c) == c, numarg: i, extramsg: "invalid value")
            LuaAuxLib.luaL_addchar(B: b, c: ClassType.intToChar(ch: c))
        }
        LuaAuxLib.luaL_pushresult(B: b)
        return 1
    }
    
    fileprivate static func writer(L:lua_State!, b:Any!, size:Int, B:Any!, t:ClassType!) -> Int { //uint
        var b:Any! = b
        //FIXME:b always is CharPtr
        //if (b.GetType() != typeof(CharPtr))
        if (t.GetTypeID() == ClassType.TYPE_CHARPTR) {
            var bytes:[UInt8] = t.ObjToBytes2(b: b)
            var chars:[Character] = [Character](repeating: "\0", count: bytes.count)
            for i:Int in 0 ..< bytes.count {
                chars[i] = ClassType.byteToChar(byte: bytes[i])
            }
            b = CharPtr(chars: chars)
        }
        LuaAuxLib.luaL_addlstring(B: B as! luaL_Buffer!, s: b as! CharPtr!, l: size)
        return 0
    }
}

public class writer_delegate: lua_Writer {
    public func exec(L:lua_State!, p:CharPtr!, sz:Int, ud:Any!) -> Int { //uint
        return LuaStrLib.writer(L: L, b: p, size: sz, B: ud, t: ClassType(type: ClassType.TYPE_CHARPTR))
    }
}

extension LuaStrLib {
    public static func str_dump(L:lua_State!) -> Int {
        let b:luaL_Buffer! = luaL_Buffer()
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TFUNCTION)
        LuaAPI.lua_settop(L: L, idx: 1)
        LuaAuxLib.luaL_buffinit(L: L, B: b)
        if (LuaAPI.lua_dump(L: L, writer: writer_delegate(), data: b) != 0) {
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "unable to dump given function"))
        }
        LuaAuxLib.luaL_pushresult(B: b)
        return 1
    }
    
    //
    //         ** {======================================================
    //         ** PATTERN MATCHING
    //         ** =======================================================
    //
    
    public static let CAP_UNFINISHED:Int = (-1)
    public static let CAP_POSITION:Int = (-2)
}

public class capture_ {
    public var init_:CharPtr! //FIXME:
    public var /*Int32*//*ptrdiff_t*/ len:Int = 0
}

public class MatchState {
    public var src_init:CharPtr!  /* init of source string */
    public var src_end:CharPtr!  /* end (`\0') of source string */
    public var L:lua_State!
    public var level:Int = 0  /* total number of captures (finished or unfinished) */
    
    public var capture:[capture_?] = [capture_?](repeating: nil, count: LuaConf.LUA_MAXCAPTURES)
    
    public init() {
        for i:Int in 0 ..< LuaConf.LUA_MAXCAPTURES {
            capture[i] = capture_()
        }
    }
}

extension LuaStrLib {
    public static let L_ESC:Character = "%"
    public static let SPECIALS:String = "^$*+?.([%-";
    
    private static func check_capture(ms:MatchState!, l:Int) -> Int {
        var l:Int = l
        l -= Int([UInt8]("1".utf8)[0])
        if (l < 0 || l >= ms.level || ms.capture[l]?.len == CAP_UNFINISHED) {
            return LuaAuxLib.luaL_error(L: ms.L, fmt: CharPtr.toCharPtr(str: "invalid capture index"));
        }
        return l
    }
    
    private static func capture_to_close(ms:MatchState!) -> Int {
        var level:Int = ms.level
        level -= 1
        while (level >= 0) {
            if (ms.capture[level]?.len == CAP_UNFINISHED) {
                return level
            }
            level -= 1
        }
        return LuaAuxLib.luaL_error(L: ms.L, fmt: CharPtr.toCharPtr(str: "invalid pattern capture"))
    }
    
    private static func classend(ms:MatchState!, p:CharPtr!) -> CharPtr! {
        var p:CharPtr! = p
        p = CharPtr(ptr: p)
        var c:Character = p.get(offset: 0)
        p = p.next()
        switch (c) {
        case L_ESC:
            if (p.get(offset: 0) == "\0") {
                _ = LuaAuxLib.luaL_error(L: ms.L, fmt: CharPtr.toCharPtr(str: "malformed pattern (ends with " + LuaConf.LUA_QL(x: "%%").toString() + ")"));
            }
            return CharPtr.plus(ptr: p, offset: 1)
        
        case "[":
            if (p.get(offset: 0) == "^") {
                p = p.next()
            }
            repeat {
                // look for a `]'
                if (p.get(offset: 0) == "\0") {
                    _ = LuaAuxLib.luaL_error(L: ms.L, fmt: CharPtr.toCharPtr(str: "malformed pattern (missing " + LuaConf.LUA_QL(x: "]").toString() + ")"))
                }
                c = p.get(offset: 0);
                p = p.next();
                if (c == L_ESC && p.get(offset: 0) != "\0") {
                    p = p.next(); // skip escapes (e.g. `%]')
                }
            } while (p.get(offset: 0) != "]")
            return CharPtr.plus(ptr: p, offset: 1)
            
        default:
            return p;
        }
    }
    
    
    private static func match_class(c:Int, cl:Int) -> Int {
        var res:Bool
        switch (CLib.tolower(c: cl)) {
        case "a":
            res = CLib.isalpha(c: c)
            break;
        
        case "c":
            res = CLib.iscntrl(c: c)
            break;
        
        case "d":
            res = CLib.isdigit(c: c)
            break;
        
        case "l":
            res = CLib.islower(c: c)
            break;
        
        case "p":
            res = CLib.ispunct(c: c)
            break;
        
        case "s":
            res = CLib.isspace(c: c)
            break;
        
        case "u":
            res = CLib.isupper(c: c)
            break;
        
        case "w":
            res = CLib.isalnum(c: c)
            break;
        
        case "x":
            res = CLib.isxdigit(c: ClassType.intToChar(ch: c))
            break;
        
        case "z":
            res = (c == 0)
            break;
        
        default:
            return (cl == c) ? 1 : 0
        }
        return (CLib.islower(c: cl) ? (res ? 1 : 0) : ((!res) ? 1 : 0))
    }
    
    private static func matchbracketclass(c:Int, p:CharPtr!, ec:CharPtr!) -> Int {
        var p:CharPtr! = p
        var sig:Int = 1
        if (p.get(offset: 1) == "^") {
            sig = 0
            p = p.next() // skip the `^'
        }
        while true {
            p = p.next()
            if !(CharPtr.lessThan(ptr1: p, ptr2: ec)) {
                break
            }
            if (CharPtr.isEqualChar(ptr: p, ch: L_ESC)) {
                p = p.next();
                if (match_class(c: c, cl: Int(ClassType.charToByte(ch: p.get(offset: 0)))) != 0) {
                    return sig;
                }
            }
            else if ((p.get(offset: 1) == "-") && (CharPtr.lessThan(ptr1: CharPtr.plus(ptr: p, offset: 2), ptr2: ec))) {
                p = CharPtr.plus(ptr: p, offset: 2);
                if (ClassType.charToByte(ch: p.get(offset: -2)) <= c && (c <= ClassType.charToByte(ch: p.get(offset: 0)))) {
                    return sig
                }
            }
            else if (ClassType.charToByte(ch: p.get(offset: 0)) == c) {
                return sig;
            }
        }
        return (sig == 0) ? 1 : 0
    }
    
    private static func singlematch(c:Int, p:CharPtr!, ep:CharPtr!) -> Int {
        switch (p.get(offset: 0)) {
        case ".":
            return 1 // matches any char
        
        case L_ESC:
            return match_class(c: c, cl: Int(ClassType.charToByte(ch: p.get(offset: 1))))
        
        case "[":
            return matchbracketclass(c: c, p: p, ec: CharPtr.minus(ptr: ep, offset: 1))
        
        default:
            return (ClassType.charToByte(ch: p.get(offset: 0)) == c) ? 1 : 0
        }
    }
    
    private static func matchbalance(ms:MatchState!, s:CharPtr!, p:CharPtr!) -> CharPtr! {
        var s:CharPtr! = s
        if ((p.get(offset: 0) == "\0") || (p.get(offset: 1) == "\0")) {
            _ = LuaAuxLib.luaL_error(L: ms.L, fmt: CharPtr.toCharPtr(str: "unbalanced pattern"))
        }
        if (s.get(offset: 0) != p.get(offset: 0)) {
            return nil
        }
        else {
            let b:Int = Int(ClassType.charToByte(ch: p.get(offset: 0)))
            let e:Int = Int(ClassType.charToByte(ch: p.get(offset: 1)))
            var cont:Int = 1
            while (true) {
                s = s.next()
                if !CharPtr.lessThan(ptr1: s, ptr2: ms.src_end) {
                    break
                }
                if (Int(ClassType.charToByte(ch: s.get(offset: 0))) == e) {
                    cont -= 1
                    if (cont == 0) {
                        return CharPtr.plus(ptr: s, offset: 1)
                    }
                }
                else if (Int(ClassType.charToByte(ch: s.get(offset: 0))) == b) {
                    cont += 1
                }
            }
        }
        return nil // string ends out of balance
    }
    
    private static func max_expand(ms:MatchState!, s:CharPtr!, p:CharPtr!, ep:CharPtr!) -> CharPtr! {
        var i:Int = 0 // counts maximum expand for item  - ptrdiff_t - Int32
        while ((CharPtr.lessThan(ptr1: CharPtr.plus(ptr: s, offset: i), ptr2: ms.src_end)) && (singlematch(c: Int(ClassType.charToByte(ch: s.get(offset: i))), p: p, ep: ep) != 0)) {
            i += 1
        }
        // keeps trying to match with the maximum repetitions
        while (i >= 0) {
            let res:CharPtr! = match(ms: ms, s: CharPtr.plus(ptr: s, offset: i), p: CharPtr.plus(ptr: ep, offset: 1));
            if (CharPtr.isNotEqual(ptr1: res, ptr2: nil)) {
                return res
            }
            i -= 1 // else didn't match; reduce 1 repetition to try again
        }
        return nil
    }
    
    private static func min_expand(ms:MatchState!, s:CharPtr!, p:CharPtr!, ep:CharPtr!) -> CharPtr! {
        var s:CharPtr! = s
        while true {
            let res:CharPtr! = match(ms: ms, s: s, p: CharPtr.plus(ptr: ep, offset: 1))
            if (CharPtr.isNotEqual(ptr1: res, ptr2: nil)) {
                return res
            }
            else if ((CharPtr.lessThan(ptr1: s, ptr2: ms.src_end)) && (singlematch(c: Int(ClassType.charToByte(ch: s.get(offset: 0))), p: p, ep: ep) != 0)) {
                s = s.next() // try with one more repetition
            }
            else {
                return nil
            }
        }
    }
    
    private static func start_capture(ms:MatchState!, s:CharPtr!, p:CharPtr!, what:Int) -> CharPtr! {
        var res:CharPtr!
        let level:Int = ms.level;
        if (level >= LuaConf.LUA_MAXCAPTURES) {
            _ = LuaAuxLib.luaL_error(L: ms.L, fmt: CharPtr.toCharPtr(str: "too many captures"));
        }
        ms.capture[level]?.init_ = s;
        ms.capture[level]?.len = what;
        ms.level = level + 1
        res = match(ms: ms, s: s, p: p)
        if (CharPtr.isEqual(ptr1: res, ptr2: nil)) { // match failed?
            ms.level -= 1 // undo capture
        }
        return res
    }
    
    private static func end_capture(ms:MatchState!, s:CharPtr!, p:CharPtr!) -> CharPtr! {
        let l:Int = capture_to_close(ms: ms)
        var res:CharPtr!
        ms.capture[l]?.len = CharPtr.minus(ptr1: s, ptr2: ms.capture[l]?.init_); // close capture
        res = match(ms: ms, s: s, p: p)
        if (CharPtr.isEqual(ptr1: res, ptr2: nil)) { // match failed?
            ms.capture[l]?.len = CAP_UNFINISHED; // undo capture
        }
        return res
    }
    
    private static func match_capture(ms:MatchState!, s:CharPtr!, l:Int) -> CharPtr! {
        var l:Int = l
        var len:Int //uint
        l = check_capture(ms: ms, l: l)
        len = (ms.capture[l]?.len)! //(uint)
        if (Int(CharPtr.minus(ptr1: ms.src_end, ptr2: s)) >= len && CLib.memcmp(ptr1: ms.capture[l]?.init_, ptr2: s, size: len) == 0) { //uint
            return CharPtr.plus(ptr: s, offset: len)
        }
        else {
            return nil
        }
    }
    
    private static func match(ms:MatchState!, s:CharPtr!, p:CharPtr!) -> CharPtr! {
        var s:CharPtr! = CharPtr(ptr: s)
        var p:CharPtr! = CharPtr(ptr: p)
        //init: /* using goto's to optimize tail recursion */
        while (true) {
            var init_:Bool = false
            switch (p.get(offset: 0)) {
            case "(":
                // start capture
                if (p.get(offset: 1) == ")") { // position capture?
                    return start_capture(ms: ms, s: s, p: CharPtr.plus(ptr: p, offset: 2), what: CAP_POSITION);
                }
                else {
                    return start_capture(ms: ms, s: s, p: CharPtr.plus(ptr: p, offset: 1), what: CAP_UNFINISHED);
                }
        
            case ")":
                // end capture
                return end_capture(ms: ms, s: s, p: CharPtr.plus(ptr: p, offset: 1))
        
            case L_ESC:
                var init2:Bool = false
                switch (p.get(offset: 1)) {
                case "b":
                    // balanced string?
                    s = matchbalance(ms: ms, s: s, p: CharPtr.plus(ptr: p, offset: 2))
                    if (CharPtr.isEqual(ptr1: s, ptr2: nil)) {
                        return nil
                    }
                    p = CharPtr.plus(ptr: p, offset: 4)
                    //goto init;  /* else return match(ms, s, p+4); */
                    init2 = true
                    break
        
                case "f":
                    // frontier?
                    var ep:CharPtr!
                    var previous:Character
                    p = CharPtr.plus(ptr: p, offset: 2)
                    if (p.get(offset: 0) != "[") {
                        _ = LuaAuxLib.luaL_error(L: ms.L, fmt: CharPtr.toCharPtr(str: "missing " + LuaConf.LUA_QL(x: "[").toString() + " after " + LuaConf.LUA_QL(x: "%%f").toString() + " in pattern"))
                    }
                    ep = classend(ms: ms, p: p) // points to what is next
                    previous = (CharPtr.isEqual(ptr1: s, ptr2: ms.src_init)) ? "\0" : s.get(offset: -1)
                    if ((matchbracketclass(c: Int(ClassType.charToByte(ch: previous)), p: p, ec: CharPtr.minus(ptr: ep, offset: 1)) != 0) || (matchbracketclass(c: Int(ClassType.charToByte(ch: s.get(offset: 0))), p: p, ec: CharPtr.minus(ptr: ep, offset: 1)) == 0)) {
                        return nil
                    }
                    p = ep
                    //goto init;  /* else return match(ms, s, ep); */
                    init2 = true
                    break
        
                default:
                    if (CLib.isdigit(c: Int(ClassType.charToByte(ch: p.get(offset: 1))))) {
                        // capture results (%0-%9)?
                        s = match_capture(ms: ms, s: s, l: Int(ClassType.charToByte(ch: p.get(offset: 1))))
                        if (CharPtr.isEqual(ptr1: s, ptr2: nil)) {
                            return nil
                        }
                        p = CharPtr.plus(ptr: p, offset: 2)
                        //goto init;
                        // else return match(ms, s, p+2)
                        init2 = true;
                        break;
                    }
                    //goto dflt;
                    // case default
                    if (true) {
                        //------------------dflt start--------------
                        // it is a pattern item
                        let ep:CharPtr! = classend(ms: ms, p: p) // points to what is next
                        let m:Int = (CharPtr.lessThan(ptr1: s, ptr2: ms.src_end)) && (singlematch(c: Int(ClassType.charToByte(ch: s.get(offset: 0))), p: p, ep: ep) != 0) ? 1 : 0;
                        var init3:Bool = false
                        switch (ep.get(offset: 0)) {
                        case "?":
                            // optional
                            var res:CharPtr!
                            res = match(ms: ms, s: CharPtr.plus(ptr: s, offset: 1), p: CharPtr.plus(ptr: ep, offset: 1))
                            if ((m != 0) && CharPtr.isNotEqual(ptr1: res, ptr2: nil)) {
                                return res
                            }
                            p = CharPtr.plus(ptr: ep, offset: 1)
                            //goto init;  /* else return match(ms, s, ep+1); */
                            init3 = true
                            break
                            
                        case "*":
                            // 0 or more repetitions
                            return max_expand(ms: ms, s: s, p: p, ep: ep);
                        
                        case "+":
                            // 1 or more repetitions
                            return ((m != 0) ? max_expand(ms: ms, s: CharPtr.plus(ptr: s, offset: 1), p: p, ep: ep) : nil)
                        
                        case "-":
                            // 0 or more repetitions (minimum)
                            return min_expand(ms: ms, s: s, p: p, ep: ep)
                        
                        default:
                            if (m == 0) {
                                return nil
                            }
                            s = s.next()
                            p = ep
                            //goto init;  /* else return match(ms, s+1, ep); */
                            init3 = true
                            break
                        }
                        if (init3 == true) {
                            init2 = true
                            break
                        }
                        else {
                            break
                        }
                        //------------------dflt end--------------
                    }
                }
                if (init2 == true) {
                    init_ = true
                    break
                }
                else {
                    break
                }
        
            case "\0":
                // end of pattern
                return s // match succeeded
    
            case "$":
                if (p.get(offset: 1) == "\0") { // is the `$' the last char in pattern?
                    return (CharPtr.isEqual(ptr1: s, ptr2: ms.src_end)) ? s : nil; // check end of string
                }
                else {
                    //goto dflt;
                    //------------------dflt start--------------
                    // it is a pattern item
                    let ep:CharPtr! = classend(ms: ms, p: p) // points to what is next
                    let m:Int = (CharPtr.lessThan(ptr1: s, ptr2: ms.src_end)) && (singlematch(c: Int(ClassType.charToByte(ch: s.get(offset: 0))), p: p, ep: ep) != 0) ? 1 : 0;
                    var init2:Bool = false
                    switch (ep.get(offset: 0)) {
                    case "?":
                        // optional
                        var res:CharPtr!
                        res = match(ms: ms, s: CharPtr.plus(ptr: s, offset: 1), p: CharPtr.plus(ptr: ep, offset: 1))
                        if ((m != 0) && CharPtr.isNotEqual(ptr1: res, ptr2: nil)) {
                            return res
                        }
                        p = CharPtr.plus(ptr: ep, offset: 1)
                        //goto init;  /* else return match(ms, s, ep+1); */
                        init2 = true
                        break
                    
                    case "*":
                        // 0 or more repetitions
                        return max_expand(ms: ms, s: s, p: p, ep: ep)
                    
                    case "+":
                        // 1 or more repetitions
                        return ((m != 0) ? max_expand(ms: ms, s: CharPtr.plus(ptr: s, offset: 1), p: p, ep: ep) : nil)
                    
                    case "-":
                        // 0 or more repetitions (minimum)
                        return min_expand(ms: ms, s: s, p: p, ep: ep)
                    
                    default:
                        if (m == 0) {
                            return nil
                        }
                        s = s.next()
                        p = ep
                        //goto init;
                        // else return match(ms, s+1, ep);
                        init2 = true
                        break
                    }
                    if (init2 == true) {
                        init_ = true
                        break
                    }
                    else {
                        break
                    }
                    //------------------dflt end--------------
                }
            
            default:
                //dflt:
                // it is a pattern item
                let ep:CharPtr! = classend(ms: ms, p: p) // points to what is next
                let m:Int = (CharPtr.lessThan(ptr1: s, ptr2: ms.src_end)) && (singlematch(c: Int(ClassType.charToByte(ch: s.get(offset: 0))), p: p, ep: ep) != 0) ? 1 : 0;
                var init2:Bool = false
                switch (ep.get(offset: 0)) {
                case "?":
                    // optional
                    var res:CharPtr!
                    res = match(ms: ms, s: CharPtr.plus(ptr: s, offset: 1), p: CharPtr.plus(ptr: ep, offset: 1))
                    if ((m != 0) && CharPtr.isNotEqual(ptr1: res, ptr2: nil)) {
                        return res
                    }
                    p = CharPtr.plus(ptr: ep, offset: 1)
                    //goto init;  /* else return match(ms, s, ep+1); */
                    init2 = true
                    break
    
                case "*":
                    // 0 or more repetitions
                    return max_expand(ms: ms, s: s, p: p, ep: ep)

                case "+":
                    // 1 or more repetitions
                    return ((m != 0) ? max_expand(ms: ms, s: CharPtr.plus(ptr: s, offset: 1), p: p, ep: ep) : nil)

                case "-":
                    // 0 or more repetitions (minimum)
                    return min_expand(ms: ms, s: s, p: p, ep: ep)

                default:
                    if (m == 0) {
                        return nil
                    }
                    s = s.next()
                    p = ep
                    //goto init;  /* else return match(ms, s+1, ep); */
                    init2 = true
                    break
                }
                if (init2 == true) {
                    init_ = true
                    break
                }
                else {
                    break
                }
            }
            if (init_ == true) {
                continue
            }
            else {
                break
            }
        }
        return nil //FIXME:unreachable
    }
    
    private static func lmemfind(s1:CharPtr!, l1:Int, s2:CharPtr!, l2:Int) -> CharPtr! { //uint - uint
        var s1:CharPtr! = s1
        var l1:Int = l1
        var l2:Int = l2
        if (l2 == 0) {
            return s1 // empty strings are everywhere
        }
        else if (l2 > l1) {
            return nil // avoids a negative `l1'
        }
        else {
            var init_:CharPtr! // to search for a `*s2' inside `s1'
            l2 -= 1 // 1st char will be checked by `memchr'
            l1 = l1 - l2 // `s2' cannot be found after that
            while (true) {
                init_ = CLib.memchr(ptr: s1, c: s2.get(offset: 0), count: l1)
                if !(l1 > 0 && CharPtr.isNotEqual(ptr1: init_, ptr2: nil)) {
                    break
                }
                init_ = init_.next(); // 1st char is already checked
                if (CLib.memcmp(ptr1: init_, ptr2: CharPtr.plus(ptr: s2, offset: 1), size: l2) == 0) {
                    return CharPtr.minus(ptr: init_, offset: 1)
                }
                else {
                    // correct `l1' and `s1' to try again
                    l1 -= Int(CharPtr.minus(ptr1: init_, ptr2: s1)) //uint
                    s1 = init_
                }
            }
            return nil // not found
        }
    }
    
    private static func push_onecapture(ms:MatchState!, i:Int, s:CharPtr!, e:CharPtr!) {
        if (i >= ms.level) {
            if (i == 0) { // ms.level == 0, too
                LuaAPI.lua_pushlstring(L: ms.L, s: s, len: CharPtr.minus(ptr1: e, ptr2: s)) // add whole match  - (uint)
            }
            else {
                _ = LuaAuxLib.luaL_error(L: ms.L, fmt: CharPtr.toCharPtr(str: "invalid capture index"));
            }
        }
        else {
            let l:Int = ms.capture[i]!.len //ptrdiff_t - Int32
            if (l == CAP_UNFINISHED) {
                _ = LuaAuxLib.luaL_error(L: ms.L, fmt: CharPtr.toCharPtr(str: "unfinished capture"));
            }
            if (l == CAP_POSITION) {
                LuaAPI.lua_pushinteger(L: ms.L, n: CharPtr.minus(ptr1: ms.capture[i]?.init_, ptr2: ms.src_init) + 1)
            }
            else {
                LuaAPI.lua_pushlstring(L: ms.L, s: ms.capture[i]?.init_, len: l) //(uint)
            }
        }
    }
    
    private static func push_captures(ms:MatchState!, s:CharPtr!, e:CharPtr!) -> Int {
        let nlevels:Int = ((ms.level == 0) && (CharPtr.isNotEqual(ptr1: s, ptr2: nil))) ? 1 : ms.level
        LuaAuxLib.luaL_checkstack(L: ms.L, space: nlevels, mes: CharPtr.toCharPtr(str: "too many captures"))
        for i:Int in 0 ..< nlevels {
            push_onecapture(ms: ms, i: i, s: s, e: e)
        }
        return nlevels // number of strings pushed
    }
    
    private static func str_find_aux(L:lua_State!, find:Int) -> Int {
        var l1:[Int] = [Int](repeating: 0, count: 1) //uint
        var l2:[Int] = [Int](repeating: 0, count: 1) //uint
        let s:CharPtr! = LuaAuxLib.luaL_checklstring(L: L, narg: 1, len: l1) //out
        var p:CharPtr! = LuaAuxLib.luaL_checklstring(L: L, narg: 2, len: l2) //out
        var init_:Int = posrelat(pos: LuaAuxLib.luaL_optinteger(L: L, narg: 3, def: 1), len: l1[0]) - 1; //ptrdiff_t - Int32
        if (init_ < 0) {
            init_ = 0;
        }
        else if (Int(init_) > l1[0]) { //uint
            init_ = Int(l1[0]) //ptrdiff_t - Int32
        }
        if ((find != 0) && ((LuaAPI.lua_toboolean(L: L, idx: 4) != 0) || CharPtr.isEqual(ptr1: CLib.strpbrk(str: p, charset: CharPtr.toCharPtr(str: SPECIALS)), ptr2: nil))) { // explicit request?
            // or no special characters?
            // do a plain search
            let s2:CharPtr! = lmemfind(s1: CharPtr.plus(ptr: s, offset: init_), l1: Int(l1[0] - init_), s2: p, l2: Int(l2[0])); //uint - uint
            if (CharPtr.isNotEqual(ptr1: s2, ptr2: nil)) {
                LuaAPI.lua_pushinteger(L: L, n: CharPtr.minus(ptr1: s2, ptr2: s) + 1)
                LuaAPI.lua_pushinteger(L: L, n: Int(CharPtr.minus(ptr1: s2, ptr2: s) + l2[0]))
                return 2
            }
        }
        else {
            let ms:MatchState! = MatchState()
            var anchor:Int = 0
            if (p.get(offset: 0) == "^") {
                p = p.next();
                anchor = 1;
            }
            var s1:CharPtr! = CharPtr.plus(ptr: s, offset: init_);
            ms.L = L;
            ms.src_init = s;
            ms.src_end = CharPtr.plus(ptr: s, offset: l1[0])
            repeat {
                var res:CharPtr!
                ms.level = 0
                res = match(ms: ms, s: s1, p: p)
                if (CharPtr.isNotEqual(ptr1: res, ptr2: nil)) {
                    if (find != 0) {
                        LuaAPI.lua_pushinteger(L: L, n: CharPtr.minus(ptr1: s1, ptr2: s) + 1) // start
                        LuaAPI.lua_pushinteger(L: L, n: CharPtr.minus(ptr1: res, ptr2: s)) // end
                        return push_captures(ms: ms, s: nil, e: nil) + 2
                    }
                    else {
                        return push_captures(ms: ms, s: s1, e: res);
                    }
                }
                s1 = s1.next()
                if (!((CharPtr.lessEqual(ptr1: s1, ptr2: ms.src_end)) && (anchor == 0))) {
                    break
                }
            } while (true)
        }
        LuaAPI.lua_pushnil(L: L) // not found
        return 1
    }
    
    public static func str_find(L:lua_State!) -> Int {
        return str_find_aux(L: L, find: 1)
    }
    
    public static func str_match(L:lua_State!) -> Int {
        return str_find_aux(L: L, find: 0)
    }
    
    public static func gmatch_aux(L:lua_State!) -> Int {
        let ms:MatchState! = MatchState()
        var ls:[Int] = [Int](repeating: 0, count: 1) //uint
        let s:CharPtr! = LuaAPI.lua_tolstring(L: L, idx: Lua.lua_upvalueindex(i: 1), len: ls) //out
        let p:CharPtr! = Lua.lua_tostring(L: L, i: Lua.lua_upvalueindex(i: 2))
        var src:CharPtr!
        ms.L = L;
        ms.src_init = s;
        ms.src_end = CharPtr.plus(ptr: s, offset: ls[0])
        src = CharPtr.plus(ptr: s, offset: LuaAPI.lua_tointeger(L: L, idx: Lua.lua_upvalueindex(i: 3)))
        while (CharPtr.lessEqual(ptr1: src, ptr2: ms.src_end)) { //(uint)
            var e:CharPtr!
            ms.level = 0
            e = match(ms: ms, s: src, p: p)
            if (CharPtr.isNotEqual(ptr1: e, ptr2: nil)) {
                var newstart:Int = CharPtr.minus(ptr1: e, ptr2: s) //lua_Integer - Int32
                if (CharPtr.isEqual(ptr1: e, ptr2: src)) {
                    newstart += 1 // empty match? go at least one position
                }
                LuaAPI.lua_pushinteger(L: L, n: newstart)
                LuaAPI.lua_replace(L: L, idx: Lua.lua_upvalueindex(i: 3))
                return push_captures(ms: ms, s: src, e: e)
            }
            src = src.next()
        }
        return 0 // not found
    }
    
    public static func gmatch(L:lua_State!) -> Int {
        _ = LuaAuxLib.luaL_checkstring(L: L, n: 1)
        _ = LuaAuxLib.luaL_checkstring(L: L, n: 2)
        LuaAPI.lua_settop(L: L, idx: 2)
        LuaAPI.lua_pushinteger(L: L, n: 0)
        LuaAPI.lua_pushcclosure(L: L, fn: LuaStrLib_delegate(name: "gmatch_aux"), n: 3)
        return 1
    }
    
    public static func gfind_nodef(L:lua_State!) -> Int {
        return LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: LuaConf.LUA_QL(x: "string.gfind").toString() + " was renamed to " + LuaConf.LUA_QL(x: "string.gmatch").toString()))
    }
    
    private static func add_s(ms:MatchState!, b:luaL_Buffer!, s:CharPtr!, e:CharPtr!) {
        var l:[Int] = [Int](repeating: 0, count: 1) //uint
        var i:Int
        let news:CharPtr! = LuaAPI.lua_tolstring(L: ms.L, idx: 3, len: l) //out
        i = 0
        while i < l[0] {
            if (news.get(offset: i) != L_ESC) {
                LuaAuxLib.luaL_addchar(B: b, c: news.get(offset: i));
            }
            else {
                i += 1 // skip ESC
                if (!CLib.isdigit(c: Int(ClassType.charToByte(ch: news.get(offset: i))))) {
                    LuaAuxLib.luaL_addchar(B: b, c: news.get(offset: i))
                }
                else if (news.get(offset: i) == "0") {
                    LuaAuxLib.luaL_addlstring(B: b, s: s, l: CharPtr.minus(ptr1: e, ptr2: s)) //(uint)
                }
                else {
                    push_onecapture(ms: ms, i: Int(ClassType.charToByte(ch: news.get(offset: i))) - Int(ClassType.charToByte(ch: Character("1"))), s: s, e: e);
                    LuaAuxLib.luaL_addvalue(B: b) // add capture to accumulated result
                }
            }
            i += 1
        }
    }
    
    private static func add_value(ms:MatchState!, b:luaL_Buffer!, s:CharPtr!, e:CharPtr!) {
        let L:lua_State! = ms.L
        switch (LuaAPI.lua_type(L: L, idx: 3)) {
        case Lua.LUA_TNUMBER, Lua.LUA_TSTRING:
            add_s(ms: ms, b: b, s: s, e: e)
            return
        
        case Lua.LUA_TFUNCTION:
            var n:Int
            LuaAPI.lua_pushvalue(L: L, idx: 3)
            n = push_captures(ms: ms, s: s, e: e)
            LuaAPI.lua_call(L: L, nargs: n, nresults: 1)
            break
        
        case Lua.LUA_TTABLE:
            push_onecapture(ms: ms, i: 0, s: s, e: e)
            LuaAPI.lua_gettable(L: L, idx: 3)
            break
            
        default:
            break
        }
        if (LuaAPI.lua_toboolean(L: L, idx: -1) == 0) {
            // nil or false?
            Lua.lua_pop(L: L, n: 1)
            LuaAPI.lua_pushlstring(L: L, s: s, len: CharPtr.minus(ptr1: e, ptr2: s)) // keep original text  - (uint)
        }
        else if (LuaAPI.lua_isstring(L: L, idx: -1) == 0) {
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "invalid replacement value (a %s)"), p: LuaAuxLib.luaL_typename(L: L, i: -1))
        }
        LuaAuxLib.luaL_addvalue(B: b) // add result to accumulator
    }
    
    public static func str_gsub(L:lua_State!) -> Int {
        var srcl:[Int] = [Int](repeating: 0, count: 1) //uint
        var src:CharPtr! = LuaAuxLib.luaL_checklstring(L: L, narg: 1, len: srcl) //out
        var p:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: 2)
        let tr:Int = LuaAPI.lua_type(L: L, idx: 3)
        let max_s:Int = LuaAuxLib.luaL_optint(L: L, n: 4, d: Int(srcl[0] + 1));
        var anchor:Int = 0
        if (p.get(offset: 0) == "^") {
            p = p.next()
            anchor = 1
        }
        var n:Int = 0
        let ms:MatchState! = MatchState();
        let b:luaL_Buffer! = luaL_Buffer();
        LuaAuxLib.luaL_argcheck(L: L, cond: tr == Lua.LUA_TNUMBER || tr == Lua.LUA_TSTRING || tr == Lua.LUA_TFUNCTION || tr == Lua.LUA_TTABLE, numarg: 3, extramsg: "string/function/table expected");
        LuaAuxLib.luaL_buffinit(L: L, B: b)
        ms.L = L
        ms.src_init = src
        ms.src_end = CharPtr.plus(ptr: src, offset: srcl[0])
        while (n < max_s) {
            var e:CharPtr!
            ms.level = 0
            e = match(ms: ms, s: src, p: p)
            if (CharPtr.isNotEqual(ptr1: e, ptr2: nil)) {
                n += 1
                add_value(ms: ms, b: b, s: src, e: e)
            }
            if ((CharPtr.isNotEqual(ptr1: e, ptr2: nil)) && CharPtr.greaterThan(ptr1: e, ptr2: src)) { // non empty match?
                src = e // skip it
            }
            else if (CharPtr.lessThan(ptr1: src, ptr2: ms.src_end)) {
                let c:Character = src.get(offset: 0)
                src = src.next();
                LuaAuxLib.luaL_addchar(B: b, c: c)
            }
            else {
                break
            }
            if (anchor != 0) {
                break
            }
        }
        LuaAuxLib.luaL_addlstring(B: b, s: src, l: CharPtr.minus(ptr1: ms.src_end, ptr2: src)) //(uint)
        LuaAuxLib.luaL_pushresult(B: b)
        LuaAPI.lua_pushinteger(L: L, n: n) // number of substitutions
        return 2
    }
    
    // }======================================================
    
    // maximum size of each formatted item (> len(format('%99.99f', -1e308)))
    public static let MAX_ITEM:Int = 512
    // valid flags in a format specification
    public static let FLAGS:String = "-+ #0"
    //
    //         ** maximum size of each format specification (such as '%-099.99d')
    //         ** (+10 accounts for %99.99x plus margin of error)
    //
    public static let MAX_FORMAT:Int = (FLAGS.count + 1) + (LuaConf.LUA_INTFRMLEN.count + 1) + 10;
    
    private static func addquoted(L:lua_State!, b:luaL_Buffer!, arg:Int) {
        var l:[Int] = [Int](repeating: 0, count: 1) //uint
        var s:CharPtr! = LuaAuxLib.luaL_checklstring(L: L, narg: arg, len: l) //out
        LuaAuxLib.luaL_addchar(B: b, c: "\"")
        while (true) {
            let l_ = l[0]
            l[0] -= 1
            if !(l_ != 0) {
                break
            }
            
            switch (s.get(offset: 0)) {
            case "\"", "\\", "\n":
                LuaAuxLib.luaL_addchar(B: b, c: "\\");
                LuaAuxLib.luaL_addchar(B: b, c: s.get(offset: 0))
                break;
            
            case "\r":
                LuaAuxLib.luaL_addlstring(B: b, s: CharPtr.toCharPtr(str: "\\r"), l: 2);
                break;
            
            case "\0":
                LuaAuxLib.luaL_addlstring(B: b, s: CharPtr.toCharPtr(str: "\\000"), l: 4)
                break;
            
            default:
                LuaAuxLib.luaL_addchar(B: b, c: s.get(offset: 0))
                break;
            }
            s = s.next()
        }
        LuaAuxLib.luaL_addchar(B: b, c: "\"")
    }

    private static func scanformat(L:lua_State!, strfrmt:CharPtr!, form:CharPtr!) -> CharPtr! {
        var form:CharPtr! = form
        var p:CharPtr! = strfrmt
        while (p.get(offset: 0) != "\0" && CharPtr.isNotEqual(ptr1: CLib.strchr(str: CharPtr.toCharPtr(str: FLAGS), c: p.get(offset: 0)), ptr2: nil)) {
            p = p.next() // skip flags
        }
        if (Int(CharPtr.minus(ptr1: p, ptr2: strfrmt)) >= (FLAGS.count + 1)) { //uint
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "invalid format (repeated flags)"));
        }
        if (CLib.isdigit(c: Int(ClassType.charToByte(ch: p.get(offset: 0))))) {
            p = p.next() // skip width
        }
        if (CLib.isdigit(c: Int(ClassType.charToByte(ch: p.get(offset: 0))))) {
            p = p.next() // (2 digits at most)
        }
        if (p.get(offset: 0) == ".") {
            p = p.next()
            if (CLib.isdigit(c: Int(ClassType.charToByte(ch: p.get(offset: 0))))) {
                p = p.next() // skip precision
            }
            if (CLib.isdigit(c: Int(ClassType.charToByte(ch: p.get(offset: 0))))) {
                p = p.next() // (2 digits at most)
            }
        }
        if (CLib.isdigit(c: Int(ClassType.charToByte(ch: p.get(offset: 0))))) {
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "invalid format (width or precision too long)"));
        }
        form.set(offset: 0, val: "%")
        form = form.next()
        _ = CLib.strncpy(dst: form, src: strfrmt, length: CharPtr.minus(ptr1: p, ptr2: strfrmt) + 1);
        form = CharPtr.plus(ptr: form, offset: CharPtr.minus(ptr1: p, ptr2: strfrmt) + 1);
        form.set(offset: 0, val: "\0")
        return p
    }
    
    private static func addintlen(form:CharPtr!) {
        let l:Int = CLib.strlen(str: form) //(uint) - uint
        let spec:Character = form.get(offset: l - 1)
        _ = CLib.strcpy(dst: CharPtr.plus(ptr: form, offset: l - 1), src: CharPtr.toCharPtr(str: LuaConf.LUA_INTFRMLEN))
        form.set(offset: l + (LuaConf.LUA_INTFRMLEN.count + 1) - 2, val: spec)
        form.set(offset: l + (LuaConf.LUA_INTFRMLEN.count + 1) - 1, val: "\0")
    }
    
    public static func str_format(L:lua_State!) -> Int {
        var arg:Int = 1
        var sfl:[Int] = [Int](repeating: 0, count: 1) //uint
        var strfrmt:CharPtr! = LuaAuxLib.luaL_checklstring(L: L, narg: arg, len: sfl) //out
        let strfrmt_end:CharPtr! = CharPtr.plus(ptr: strfrmt, offset: sfl[0])
        let b:luaL_Buffer! = luaL_Buffer()
        LuaAuxLib.luaL_buffinit(L: L, B: b)
        while (CharPtr.lessThan(ptr1: strfrmt, ptr2: strfrmt_end)) {
            if (strfrmt.get(offset: 0) != L_ESC) {
                LuaAuxLib.luaL_addchar(B: b, c: strfrmt.get(offset: 0))
                strfrmt = strfrmt.next()
            }
            else if (strfrmt.get(offset: 1) == L_ESC) {
                LuaAuxLib.luaL_addchar(B: b, c: strfrmt.get(offset: 0)) // %%
                strfrmt = CharPtr.plus(ptr: strfrmt, offset: 2)
            }
            else {
                // format item
                strfrmt = strfrmt.next();
                let form:CharPtr! = CharPtr.toCharPtr(chars: [Character](repeating: "\0", count: MAX_FORMAT)) // to store the format (`%...')
                let buff:CharPtr! = CharPtr.toCharPtr(chars: [Character](repeating: "\0", count: MAX_ITEM)) // to store the formatted item
                arg += 1
                strfrmt = scanformat(L: L, strfrmt: strfrmt, form: form)
                let ch:Character = strfrmt.get(offset: 0)
                strfrmt = strfrmt.next()
                switch (ch) {
                case "c":
                    CLib.sprintf(buffer: buff, str: form, argv: Int(LuaAuxLib.luaL_checknumber(L: L, narg: arg)))
                    break
                
                case "d", "i":
                    addintlen(form: form)
                    CLib.sprintf(buffer: buff, str: form, argv: Int64(LuaAuxLib.luaL_checknumber(L: L, narg: arg))) //LUA_INTFRM_T - Int64
                    break
                
                case "o", "u", "x", "X":
                    addintlen(form: form)
                    CLib.sprintf(buffer: buff, str: form, argv: Int64(LuaAuxLib.luaL_checknumber(L: L, narg: arg))) //UNSIGNED_LUA_INTFRM_T - UInt64
                    break
                
                case "e", "E", "f", "g", "G":
                    CLib.sprintf(buffer: buff, str: form, argv: Double(LuaAuxLib.luaL_checknumber(L: L, narg: arg)))
                    break
                
                case "q":
                    addquoted(L: L, b: b, arg: arg)
                    continue // skip the 'addsize' at the end
                
                case "s":
                    var l:[Int] = [Int](repeating: 0, count: 1) //uint
                    let s:CharPtr! = LuaAuxLib.luaL_checklstring(L: L, narg: arg, len: l) //out
                    if (CharPtr.isEqual(ptr1: CLib.strchr(str: form, c: "."), ptr2: nil) && l[0] >= 100) {
                        //                                     no precision and string is too long to be formatted;
                        //                                     keep original string
                        LuaAPI.lua_pushvalue(L: L, idx: arg)
                        LuaAuxLib.luaL_addvalue(B: b)
                        continue // skip the `addsize' at the end
                    }
                    else {
                        CLib.sprintf(buffer: buff, str: form, argv: s)
                        break
                    }
                    
                default:
                    // also treat cases `pnLlh'
                    return LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "invalid option " + LuaConf.LUA_QL(x: "%%%c").toString() + " to " + LuaConf.LUA_QL(x: "format").toString()), p: strfrmt.get(offset: -1))
                }
                LuaAuxLib.luaL_addlstring(B: b, s: buff, l: CLib.strlen(str: buff)) //(uint)
            }
        }
        LuaAuxLib.luaL_pushresult(B: b)
        return 1
    }
    
    private static let strlib:[luaL_Reg] = [
        luaL_Reg(name: CharPtr.toCharPtr(str: "byte"), func_: LuaStrLib_delegate(name: "str_byte")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "char"), func_: LuaStrLib_delegate(name: "str_char")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "dump"), func_: LuaStrLib_delegate(name: "str_dump")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "find"), func_: LuaStrLib_delegate(name: "str_find")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "format"), func_: LuaStrLib_delegate(name: "str_format")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "gfind"), func_: LuaStrLib_delegate(name: "gfind_nodef")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "gmatch"), func_: LuaStrLib_delegate(name: "gmatch")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "gsub"), func_: LuaStrLib_delegate(name: "str_gsub")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "len"), func_: LuaStrLib_delegate(name: "str_len")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "lower"), func_: LuaStrLib_delegate(name: "str_lower")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "match"), func_: LuaStrLib_delegate(name: "str_match")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "rep"), func_: LuaStrLib_delegate(name: "str_rep")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "reverse"), func_: LuaStrLib_delegate(name: "str_reverse")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "sub"), func_: LuaStrLib_delegate(name: "str_sub")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "upper"), func_: LuaStrLib_delegate(name: "str_upper")),
        luaL_Reg(name: nil, func_: nil)
    ]
}

public class LuaStrLib_delegate: lua_CFunction {
    private var name:String!
    
    public init(name:String!) {
        self.name = name
    }
    
    public func exec(L:lua_State!) -> Int {
        if ("str_byte" == name)
        {
            return LuaStrLib.str_byte(L: L)
        }
        else if ("str_char" == name)
        {
            return LuaStrLib.str_char(L: L)
        }
        else if ("str_dump" == name)
        {
            return LuaStrLib.str_dump(L: L)
        }
        else if ("str_find" == name)
        {
            return LuaStrLib.str_find(L: L)
        }
        else if ("str_format" == name)
        {
            return LuaStrLib.str_format(L: L)
        }
        else if ("gfind_nodef" == name)
        {
            return LuaStrLib.gfind_nodef(L: L)
        }
        else if ("gmatch" == name)
        {
            return LuaStrLib.gmatch(L: L)
        }
        else if ("str_gsub" == name)
        {
            return LuaStrLib.str_gsub(L: L)
        }
        else if ("str_len" == name)
        {
            return LuaStrLib.str_len(L: L)
        }
        else if ("str_lower" == name)
        {
            return LuaStrLib.str_lower(L: L)
        }
        else if ("str_match" == name)
        {
            return LuaStrLib.str_match(L: L)
        }
        else if ("str_rep" == name)
        {
            return LuaStrLib.str_rep(L: L)
        }
        else if ("str_reverse" == name)
        {
            return LuaStrLib.str_reverse(L: L)
        }
        else if ("str_sub" == name)
        {
            return LuaStrLib.str_sub(L: L)
        }
        else if ("str_upper" == name)
        {
            return LuaStrLib.str_upper(L: L)
        }
        else if ("gmatch_aux" == name)
        {
            return LuaStrLib.gmatch_aux(L: L)
        }
        else
        {
            return 0
        }
    }
}

extension LuaStrLib {
    private static func createmetatable(L:lua_State!) {
        LuaAPI.lua_createtable(L: L, narray: 0, nrec: 1) // create metatable for strings
        Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: "")) // dummy string
        LuaAPI.lua_pushvalue(L: L, idx: -2)
        _ = LuaAPI.lua_setmetatable(L: L, objindex: -2) // set string metatable
        Lua.lua_pop(L: L, n: 1) // pop dummy string
        LuaAPI.lua_pushvalue(L: L, idx: -2) // string library...
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "__index")) //...is the __index metamethod
        Lua.lua_pop(L: L, n: 1) // pop metatable
    }
    
    //
    //         ** Open string library
    //
    public static func luaopen_string(L:lua_State!) -> Int {
        LuaAuxLib.luaL_register(L: L, libname: CharPtr.toCharPtr(str: LuaLib.LUA_STRLIBNAME), l: strlib)
        ///#if LUA_COMPAT_GFIND
        LuaAPI.lua_getfield(L: L, idx: -1, k: CharPtr.toCharPtr(str: "gmatch"))
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "gfind"))
        ///#endif
        createmetatable(L: L)
        return 1
    }
}
