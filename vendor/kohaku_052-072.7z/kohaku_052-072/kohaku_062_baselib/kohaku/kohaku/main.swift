//
//  main.swift
//  kohaku
//
//  Created by  on 2018/2/1.
//  Copyright © 2018年 weimingtom. All rights reserved.
//

import Foundation

print("Hello, World!")

print(Lua.LUA_MINSTACK)

//            var str:[UInt8] = [UInt8](String(s.get(offset: posi + i - 1)).utf8)
//LuaAPI.lua_pushinteger(L: L, n: Int(str[0]))

//Character(String(bytes: [UInt8(c)], encoding: .ascii)!)
//LuaAuxLib.luaL_addchar(B: b, c: Character(UnicodeScalar(UInt8(c))))

/*
 var bytes:[UInt8] = t.ObjToBytes2(b: b)
 var chars:[Character] = [Character](repeating: "\0", count: bytes.count)
 for i:Int in 0 ..< bytes.count {
 chars[i] = Character(UnicodeScalar(bytes[i]))
 }
*/
