//package kurumi;

//
// ** $Id: ltablib.c,v 1.38.1.3 2008/02/14 16:46:58 roberto Exp $
// ** Library for Table Manipulation
// ** See Copyright Notice in lua.h
//

//using lua_Number = System.Double;

public class LuaTableLib {
    private static func aux_getn(L:lua_State!, n:Int) -> Int {
        LuaAuxLib.luaL_checktype(L: L, narg: n, t: Lua.LUA_TTABLE)
        return LuaAuxLib.luaL_getn(L: L, i: n)
    }
    
    fileprivate static func foreachi(L:lua_State!) -> Int {
        let n:Int = aux_getn(L: L, n: 1)
        LuaAuxLib.luaL_checktype(L: L, narg: 2, t: Lua.LUA_TFUNCTION)
        for i:Int in 1...n {
            LuaAPI.lua_pushvalue(L: L, idx: 2) // function
            LuaAPI.lua_pushinteger(L: L, n: i) // 1st argument
            LuaAPI.lua_rawgeti(L: L, idx: 1, n: i) // 2nd argument
            LuaAPI.lua_call(L: L, nargs: 2, nresults: 1)
            if (!Lua.lua_isnil(L: L, n: -1)) {
                return 1
            }
            Lua.lua_pop(L: L, n: 1) // remove nil result
        }
        return 0
    }
    
    fileprivate static func _foreach(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TTABLE)
        LuaAuxLib.luaL_checktype(L: L, narg: 2, t: Lua.LUA_TFUNCTION)
        LuaAPI.lua_pushnil(L: L) // first key
        while (LuaAPI.lua_next(L: L, idx: 1) != 0) {
            LuaAPI.lua_pushvalue(L: L, idx: 2) // function
            LuaAPI.lua_pushvalue(L: L, idx: -3) // key
            LuaAPI.lua_pushvalue(L: L, idx: -3) // value
            LuaAPI.lua_call(L: L, nargs: 2, nresults: 1)
            if (!Lua.lua_isnil(L: L, n: -1)) {
                return 1
            }
            Lua.lua_pop(L: L, n: 2) // remove value and result
        }
        return 0
    }
    
    fileprivate static func maxn(L:lua_State!) -> Int {
        var max:Double = 0 //lua_Number
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TTABLE)
        LuaAPI.lua_pushnil(L: L) // first key
        while (LuaAPI.lua_next(L: L, idx: 1) != 0) {
            Lua.lua_pop(L: L, n: 1) // remove value
            if (LuaAPI.lua_type(L: L, idx: -1) == Lua.LUA_TNUMBER) {
                let v:Double = LuaAPI.lua_tonumber(L: L, idx: -1) //lua_Number
                if (v > max) {
                    max = v
                }
            }
        }
        LuaAPI.lua_pushnumber(L: L, n: max)
        return 1
    }
    
    fileprivate static func getn(L:lua_State!) -> Int {
        LuaAPI.lua_pushinteger(L: L, n: aux_getn(L: L, n: 1))
        return 1
    }
    
    fileprivate static func setn(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TTABLE)
        ///#ifndef luaL_setn
        //luaL_setn(L, 1, luaL_checkint(L, 2));
        ///#else
        _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: LuaConf.LUA_QL(x: "setn").toString() + " is obsolete"))
        ///#endif
        LuaAPI.lua_pushvalue(L: L, idx: 1)
        return 1
    }
    
    fileprivate static func tinsert(L:lua_State!) -> Int {
        var e:Int = aux_getn(L: L, n: 1) + 1 // first empty element
        var pos:Int // where to insert new element
        switch (LuaAPI.lua_gettop(L: L)) {
        case 2:
            // called with only 2 arguments
            pos = e // insert new element at the end
            break
            
        case 3:
            pos = LuaAuxLib.luaL_checkint(L: L, n: 2) // 2nd argument is the position
            if (pos > e) {
                e = pos // `grow' array if necessary
            }
            for i:Int in stride(from: e, to: pos, by: -1) {
                // move up elements
                LuaAPI.lua_rawgeti(L: L, idx: 1, n: i - 1)
                LuaAPI.lua_rawseti(L: L, idx: 1, n: i) // t[i] = t[i-1]
            }
            break
            
        default:
            return LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "wrong number of arguments to " + LuaConf.LUA_QL(x: "insert").toString()))
        }
        LuaAuxLib.luaL_setn(L: L, i: 1, j: e) // new size
        LuaAPI.lua_rawseti(L: L, idx: 1, n: pos) // t[pos] = v
        return 0
    }
    
    fileprivate static func tremove(L:lua_State!) -> Int {
        let e:Int = aux_getn(L: L, n: 1)
        var pos:Int = LuaAuxLib.luaL_optint(L: L, n: 2, d: e)
        if (!(1 <= pos && pos <= e)) { // position is outside bounds?
            return 0 // nothing to remove
        }
        LuaAuxLib.luaL_setn(L: L, i: 1, j: e - 1) // t.n = n-1
        LuaAPI.lua_rawgeti(L: L, idx: 1, n: pos) // result = t[pos]
        while (pos < e) {
            LuaAPI.lua_rawgeti(L: L, idx: 1, n: pos + 1)
            LuaAPI.lua_rawseti(L: L, idx: 1, n: pos) // t[pos] = t[pos+1]
            pos += 1
        }
        LuaAPI.lua_pushnil(L: L)
        LuaAPI.lua_rawseti(L: L, idx: 1, n: e) // t[e] = nil
        return 1
    }
    
    private static func addfield(L:lua_State!, b:luaL_Buffer!, i:Int) {
        LuaAPI.lua_rawgeti(L: L, idx: 1, n: i)
        if (LuaAPI.lua_isstring(L: L, idx: -1) == 0) {
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "invalid value (%s) at index %d in table for " + LuaConf.LUA_QL(x: "concat").toString()), p: LuaAuxLib.luaL_typename(L: L, i: -1), i)
        }
        LuaAuxLib.luaL_addvalue(B: b)
    }
    
    
    fileprivate static func tconcat(L:lua_State!) -> Int {
        let b:luaL_Buffer! = luaL_Buffer()
        var lsep:[Int] = [Int](repeating:0, count:1) //uint
        var i:Int, last:Int
        let sep:CharPtr! = LuaAuxLib.luaL_optlstring(L: L, narg: 2, def: CharPtr.toCharPtr(str: ""), len: lsep) //out
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TTABLE)
        i = LuaAuxLib.luaL_optint(L: L, n: 3, d: 1)
        last = LuaAuxLib.luaL_opt_integer(L: L, f: luaL_checkint_delegate(), n: 4, d: Double(LuaAuxLib.luaL_getn(L: L, i: 1)))
        LuaAuxLib.luaL_buffinit(L: L, B: b)
        while (i < last) {
            addfield(L: L, b: b, i: i)
            LuaAuxLib.luaL_addlstring(B: b, s: sep, l: lsep[0])
            i += 1
        }
        if (i == last) { // add last value (if interval was not empty)
            addfield(L: L, b: b, i: i)
        }
        LuaAuxLib.luaL_pushresult(B: b)
        return 1
    }
    
    //
    //         ** {======================================================
    //         ** Quicksort
    //         ** (based on `Algorithms in MODULA-3', Robert Sedgewick;
    //         **  Addison-Wesley, 1993.)
    //
    
    private static func set2(L:lua_State!, i:Int, j:Int) {
        LuaAPI.lua_rawseti(L: L, idx: 1, n: i)
        LuaAPI.lua_rawseti(L: L, idx: 1, n: j)
    }
    
    private static func sort_comp(L:lua_State!, a:Int, b:Int) -> Int {
        if (!Lua.lua_isnil(L: L, n: 2)) {
            // function?
            var res:Int
            LuaAPI.lua_pushvalue(L: L, idx: 2)
            LuaAPI.lua_pushvalue(L: L, idx: a - 1) // -1 to compensate function
            LuaAPI.lua_pushvalue(L: L, idx: b - 2) // -2 to compensate function and `a'
            LuaAPI.lua_call(L: L, nargs: 2, nresults: 1)
            res = LuaAPI.lua_toboolean(L: L, idx: -1)
            Lua.lua_pop(L: L, n: 1)
            return res
        }
        else { // a < b?
            return LuaAPI.lua_lessthan(L: L, index1: a, index2: b)
        }
    }
    
    private static func auxsort_loop1(L:lua_State!, i:inout [Int]!) -> Int { //ref
        i[0] += 1
        LuaAPI.lua_rawgeti(L: L, idx: 1, n: i[0])
        return sort_comp(L: L, a: -1, b: -2)
    }
    
    private static func auxsort_loop2(L:lua_State!, j:inout [Int]!) -> Int { //ref
        j[0] -= 1
        LuaAPI.lua_rawgeti(L: L, idx: 1, n: j[0])
        return sort_comp(L: L, a: -3, b: -1)
    }
    
    private static func auxsort(L:lua_State!, l:Int, u:Int) {
        var l:Int = l
        var u:Int = u
        while (l < u) {
            // for tail recursion
            var i:Int, j:Int
            // sort elements a[l], a[(l+u)/2] and a[u]
            LuaAPI.lua_rawgeti(L: L, idx: 1, n: l)
            LuaAPI.lua_rawgeti(L: L, idx: 1, n: u)
            if (sort_comp(L: L, a: -1, b: -2) != 0) { // a[u] < a[l]?
                set2(L: L, i: l, j: u) // swap a[l] - a[u]
            }
            else {
                Lua.lua_pop(L: L, n: 2)
            }
            if (u - l == 1) {
                break // only 2 elements
            }
            i = (l + u) / 2
            LuaAPI.lua_rawgeti(L: L, idx: 1, n: i)
            LuaAPI.lua_rawgeti(L: L, idx: 1, n: l)
            if (sort_comp(L: L, a: -2, b: -1) != 0) { // a[i]<a[l]?
                set2(L: L, i: i, j: l)
            }
            else {
                Lua.lua_pop(L: L, n: 1) // remove a[l]
                LuaAPI.lua_rawgeti(L: L, idx: 1, n: u)
                if (sort_comp(L: L, a: -1, b: -2) != 0) { // a[u]<a[i]?
                    set2(L: L, i: i, j: u)
                }
                else {
                    Lua.lua_pop(L: L, n: 2)
                }
            }
            if (u - l == 2) {
                break // only 3 elements
            }
            LuaAPI.lua_rawgeti(L: L, idx: 1, n: i) // Pivot
            LuaAPI.lua_pushvalue(L: L, idx: -1)
            LuaAPI.lua_rawgeti(L: L, idx: 1, n: u - 1)
            set2(L: L, i: i, j: u - 1)
            // a[l] <= P == a[u-1] <= a[u], only need to sort from l+1 to u-2
            i = l
            j = u - 1
            while (true) {
                // invariant: a[l..i] <= P <= a[j..u]
                // repeat ++i until a[i] >= P
                while (true) {
                    var i_ref:[Int]! = [Int](repeating: 0, count: 1)
                    i_ref[0] = i
                    let ret_1:Int = auxsort_loop1(L: L, i: &i_ref) //ref
                    i = i_ref[0]
                    if (!(ret_1 != 0)) {
                        break
                    }
                    if (i > u) {
                        _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "invalid order function for sorting"))
                    }
                    Lua.lua_pop(L: L, n: 1) // remove a[i]
                }
                // repeat --j until a[j] <= P
                while (true) {
                    var j_ref:[Int]! = [Int](repeating: 0, count: 1)
                    j_ref[0] = i
                    let ret_2:Int = auxsort_loop2(L: L, j: &j_ref) //ref
                    j = j_ref[0]
                    if (!(ret_2 != 0)) {
                        break
                    }
                    if (j < l) {
                        _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "invalid order function for sorting"));
                    }
                    Lua.lua_pop(L: L, n: 1) // remove a[j]
                }
                if (j < i) {
                    Lua.lua_pop(L: L, n: 3) // pop pivot, a[i], a[j]
                    break;
                }
                set2(L: L, i: i, j: j)
            }
            LuaAPI.lua_rawgeti(L: L, idx: 1, n: u - 1)
            LuaAPI.lua_rawgeti(L: L, idx: 1, n: i)
            set2(L: L, i: u-1, j: i) // swap pivot (a[u-1]) with a[i]
            // a[l..i-1] <= a[i] == P <= a[i+1..u]
            // adjust so that smaller half is in [j..i] and larger one in [l..u]
            if (i - l < u - i) {
                j = l
                i = i - 1
                l = i + 2
            }
            else {
                j = i + 1
                i = u
                u = j - 2
            }
            auxsort(L: L, l: j, u: i) // call recursively the smaller one
        } // repeat the routine for the larger one
    }
    
    fileprivate static func sort(L:lua_State!) -> Int {
        let n:Int = aux_getn(L: L, n: 1)
        LuaAuxLib.luaL_checkstack(L: L, space: 40, mes: CharPtr.toCharPtr(str: "")) // assume array is smaller than 2^40
        if (!Lua.lua_isnoneornil(L: L, n: 2)) { // is there a 2nd argument?
            LuaAuxLib.luaL_checktype(L: L, narg: 2, t: Lua.LUA_TFUNCTION)
        }
        LuaAPI.lua_settop(L: L, idx: 2) // make sure there is two arguments
        auxsort(L: L, l: 1, u: n)
        return 0
    }
    
    // }======================================================
    
    private static let tab_funcs:[luaL_Reg] = [
        luaL_Reg(name: CharPtr.toCharPtr(str: "concat"), func_: LuaTableLib_delegate(name: "tconcat")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "foreach"), func_: LuaTableLib_delegate(name: "_foreach")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "foreachi"), func_: LuaTableLib_delegate(name: "foreachi")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "getn"), func_: LuaTableLib_delegate(name: "getn")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "maxn"), func_: LuaTableLib_delegate(name: "maxn")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "insert"), func_: LuaTableLib_delegate(name: "tinsert")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "remove"), func_: LuaTableLib_delegate(name: "tremove")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "setn"), func_: LuaTableLib_delegate(name: "setn")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "sort"), func_: LuaTableLib_delegate(name: "sort")),
        luaL_Reg(name: nil, func_: nil)
    ]
    
    public static func luaopen_table(L:lua_State!) -> Int {
        LuaAuxLib.luaL_register(L: L, libname: CharPtr.toCharPtr(str: LuaLib.LUA_TABLIBNAME), l: tab_funcs)
        return 1
    }
}


public class LuaTableLib_delegate : lua_CFunction {
    private var name:String!
    
    public init(name:String!) {
        self.name = name;
    }
    
    public func exec(L:lua_State!) -> Int {
        if ("tconcat" == name) {
            return LuaTableLib.tconcat(L: L)
        }
        else if ("_foreach" == name) {
            return LuaTableLib._foreach(L: L)
        }
        else if ("foreachi" == name) {
            return LuaTableLib.foreachi(L: L)
        }
        else if ("getn" == name) {
            return LuaTableLib.getn(L: L)
        }
        else if ("maxn" == name) {
            return LuaTableLib.maxn(L: L)
        }
        else if ("tinsert" == name) {
            return LuaTableLib.tinsert(L: L)
        }
        else if ("tremove" == name) {
            return LuaTableLib.tremove(L: L)
        }
        else if ("setn" == name) {
            return LuaTableLib.setn(L: L)
        }
        else if ("sort" == name) {
            return LuaTableLib.sort(L: L)
        }
        else {
            return 0
        }
    }
}
