//package kurumi;

//
// ** $Id: lcode.c,v 2.25.1.3 2007/12/28 15:32:23 roberto Exp $
// ** Code generator for Lua
// ** See Copyright Notice in lua.h
//

//using TValue = Lua.TValue;
//using lua_Number = System.Double;
//using Instruction = System.UInt32;

public class LuaCode {

}

public class InstructionPtr {
    public var/*UInt32[]*//*Instruction[]*/ codes:[Int64]!
    public var pc:Int = 0
    
    public init() {
//        this.codes = null;
//        this.pc = -1;
    }
    
    public init(/*UInt32[]*//*Instruction[]*/ codes:[Int64]!, pc:Int) {
//        this.codes = codes;
//        this.pc = pc;
    }
    
    public static func Assign(ptr:InstructionPtr!) -> InstructionPtr! {
//        if (ptr == null)
//        {
//        return null;
//        }
//        return new InstructionPtr(ptr.codes, ptr.pc);
        return nil
    }
    
    //UInt32/*Instruction*/ this[int index]
    public func/*UInt32*//*Instruction*/ get(index:Int) -> Int64 {
//        return this.codes[pc + index];
        return 0
    }
    public func set(index:Int, /*UInt32*//*Instruction*/ val:Int64) {
//        this.codes[pc + index] = val;
    }
    
    public static func inc(/*ref*/ ptr:[InstructionPtr]!) -> InstructionPtr! {
//        InstructionPtr result = new InstructionPtr(ptr[0].codes, ptr[0].pc);
//        ptr[0].pc++;
//        return result;
        return nil
    }
    
    public static func dec(/*ref*/ ptr:[InstructionPtr]!) -> InstructionPtr! {
//        InstructionPtr result = new InstructionPtr(ptr[0].codes, ptr[0].pc);
//        ptr[0].pc--;
//        return result;
        return nil
    }
    
    //operator <
    public static func lessThan(p1:InstructionPtr!, p2:InstructionPtr!) -> Bool {
//        ClassType.Assert(p1.codes == p2.codes);
//        return p1.pc < p2.pc;
        return false
    }
    
    //operator >
    public static func greaterThan(p1:InstructionPtr!, p2:InstructionPtr!) -> Bool {
//        ClassType.Assert(p1.codes == p2.codes);
//        return p1.pc > p2.pc;
        return false
    }
    
    //operator <=
    public static func lessEqual(p1:InstructionPtr!, p2:InstructionPtr!) -> Bool {
//        ClassType.Assert(p1.codes == p2.codes);
//        return p1.pc < p2.pc;
        return false
    }
    
    //operator >=
    public static func greaterEqual(p1:InstructionPtr!, p2:InstructionPtr!) -> Bool {
//        ClassType.Assert(p1.codes == p2.codes);
//        return p1.pc > p2.pc;
        return false
    }
}

extension LuaCode {
    //
    //         ** Marks the end of a patch list. It is an invalid value both as an absolute
    //         ** address, and as a list link (would link an element to itself).
    //
    public static let NO_JUMP:Int = (-1)
}

/*
 ** grep "ORDER OPR" if you change these enums
 */
public enum BinOpr : Int {
    case OPR_ADD
    case OPR_SUB
    case OPR_MUL
    case OPR_DIV
    case OPR_MOD
    case OPR_POW
    case OPR_CONCAT
    case OPR_NE
    case OPR_EQ
    case OPR_LT
    case OPR_LE
    case OPR_GT
    case OPR_GE
    case OPR_AND
    case OPR_OR
    case OPR_NOBINOPR
    
    public func getValue() -> Int {
        return self.rawValue
    }
    
    public static func forValue(value:Int) -> BinOpr {
        return BinOpr(rawValue: value)!
    }
}

public enum UnOpr : Int {
    case OPR_MINUS
    case OPR_NOT
    case OPR_LEN
    case OPR_NOUNOPR
    
    public func getValue() -> Int {
        return self.rawValue
    }
    
    public static func forValue(value:Int) -> UnOpr {
        return UnOpr(rawValue: value)!
    }
}

extension LuaCode {
    public static func getcode(fs:FuncState!, e:expdesc!) -> InstructionPtr! {
//        return new InstructionPtr(fs.f.code, e.u.s.info);
        return nil
    }
    
    public static func luaK_codeAsBx(fs:FuncState!, o:OpCode, A:Int, sBx:Int) -> Int {
//        return LuaCode.luaK_codeABx(fs, o, A, sBx + LuaOpCodes.MAXARG_sBx);
        return 0
    }
    
    public static func luaK_setmultret(fs:FuncState!, e:expdesc!) {
//        LuaCode.luaK_setreturns(fs, e, Lua.LUA_MULTRET);
    }
    
    public static func hasjumps(e:expdesc!) -> Bool {
//        return e.t != e.f;
        return false
    }
    
    private static func isnumeral(e:expdesc!) -> Int {
//        return (e.k == LuaParser.expkind.VKNUM && e.t == NO_JUMP && e.f == NO_JUMP) ? 1 : 0;
        return 0
    }
    
    public static func luaK_nil(fs:FuncState!, from:Int, n:Int) {
//        InstructionPtr previous;
//        if (fs.pc > fs.lasttarget) {
//        // no jumps to current position?
//        if (fs.pc == 0) {
//        // function start?
//        if (from >= fs.nactvar) {
//        return; // positions are already clean
//        }
//        }
//        else {
//        previous = new InstructionPtr(fs.f.code, fs.pc-1);
//        if (LuaOpCodes.GET_OPCODE(previous) == LuaOpCodes.OpCode.OP_LOADNIL) {
//        int pfrom = LuaOpCodes.GETARG_A(previous);
//        int pto = LuaOpCodes.GETARG_B(previous);
//        if (pfrom <= from && from <= pto+1) {
//        // can connect both?
//        if (from+n-1 > pto) {
//        LuaOpCodes.SETARG_B(previous, from + n - 1);
//        }
//        return;
//        }
//        }
//        }
//        }
//        luaK_codeABC(fs, LuaOpCodes.OpCode.OP_LOADNIL, from, from + n - 1, 0); // else no optimization
    }
    
    public static func luaK_jump(fs:FuncState!) -> Int {
//        int jpc = fs.jpc; // save list of jumps to here
//        int[] j = new int[1];
//        j[0] = 0;
//        fs.jpc = NO_JUMP;
//        j[0] = luaK_codeAsBx(fs, LuaOpCodes.OpCode.OP_JMP, 0, NO_JUMP);
//        luaK_concat(fs, j, jpc); // keep them on hold  - ref
//        return j[0];
        return 0
    }
    
    public static func luaK_ret(fs:FuncState!, first:Int, nret:Int) {
//        luaK_codeABC(fs, LuaOpCodes.OpCode.OP_RETURN, first, nret + 1, 0);
    }
    
    private static func condjump(fs:FuncState!, op:OpCode, A:Int, B:Int, C:Int) -> Int {
//        luaK_codeABC(fs, op, A, B, C);
//        return luaK_jump(fs);
        return 0
    }
    
    private static func fixjump(fs:FuncState!, pc:Int, dest:Int) {
//        InstructionPtr jmp = new InstructionPtr(fs.f.code, pc);
//        int offset = dest-(pc+1);
//        LuaLimits.lua_assert(dest != NO_JUMP);
//        if (Math.abs(offset) > LuaOpCodes.MAXARG_sBx) {
//        LuaLex.luaX_syntaxerror(fs.ls, CLib.CharPtr.toCharPtr("control structure too long"));
//        }
//        LuaOpCodes.SETARG_sBx(jmp, offset);
    }
    
    //
    //         ** returns current `pc' and marks it as a jump target (to avoid wrong
    //         ** optimizations with consecutive instructions not in the same basic block).
    //
    public static func luaK_getlabel(fs:FuncState!) -> Int {
//        fs.lasttarget = fs.pc;
//        return fs.pc;
        return 0
    }
    
    private static func getjump(fs:FuncState!, pc:Int) -> Int {
//        int offset = LuaOpCodes.GETARG_sBx(fs.f.code[pc]);
//        if (offset == NO_JUMP) { // point to itself represents end of list
//        return NO_JUMP; // end of list
//        }
//        else {
//        return (pc+1)+offset; // turn offset into absolute position
//        }
        return 0
    }
    
    private static func getjumpcontrol(fs:FuncState!, pc:Int) -> InstructionPtr! {
//        InstructionPtr pi = new InstructionPtr(fs.f.code, pc);
//        if (pc >= 1 && (LuaOpCodes.testTMode(LuaOpCodes.GET_OPCODE(pi.get(-1))) != 0)) {
//        return new InstructionPtr(pi.codes, pi.pc-1);
//        }
//        else {
//        return new InstructionPtr(pi.codes, pi.pc);
//        }
        return nil
    }
    
    //
    //         ** check whether list has any jump that do not produce a value
    //         ** (or produce an inverted value)
    //
    private static func need_value(fs:FuncState!, list:Int) -> Int {
//        for (; list != NO_JUMP; list = getjump(fs, list)) {
//        InstructionPtr i = getjumpcontrol(fs, list);
//        if (LuaOpCodes.GET_OPCODE(i.get(0)) != LuaOpCodes.OpCode.OP_TESTSET) {
//        return 1;
//        }
//        }
//        return 0; // not found
        return 0
    }
    
    private static func patchtestreg(fs:FuncState!, node:Int, reg:Int) -> Int {
//        InstructionPtr i = getjumpcontrol(fs, node);
//        if (LuaOpCodes.GET_OPCODE(i.get(0)) != LuaOpCodes.OpCode.OP_TESTSET) {
//        return 0; // cannot patch other instructions
//        }
//        if (reg != LuaOpCodes.NO_REG && reg != LuaOpCodes.GETARG_B(i.get(0))) {
//        LuaOpCodes.SETARG_A(i, reg);
//        }
//        else { // no register to put value or register already has the value
//        i.set(0, (long)(LuaOpCodes.CREATE_ABC(LuaOpCodes.OpCode.OP_TEST, LuaOpCodes.GETARG_B(i.get(0)), 0, LuaOpCodes.GETARG_C(i.get(0))) &0xffffffff)); //uint
//        }
//        
//        return 1;
        return 0
    }
    
    private static func removevalues(fs:FuncState!, list:Int) {
//        for (; list != NO_JUMP; list = getjump(fs, list)) {
//        patchtestreg(fs, list, LuaOpCodes.NO_REG);
//        }
    }
    
    private static func patchlistaux(fs:FuncState!, list:Int, vtarget:Int, reg:Int, dtarget:Int) {
//        while (list != NO_JUMP) {
//        int next = getjump(fs, list);
//        if (patchtestreg(fs, list, reg) != 0) {
//        fixjump(fs, list, vtarget);
//        }
//        else {
//        fixjump(fs, list, dtarget); // jump to default target
//        }
//        list = next;
//        }
    }
    
    public static func luaK_patchlist(fs:FuncState!, list:Int, target:Int) {
//        if (target == fs.pc) {
//        luaK_patchtohere(fs, list);
//        }
//        else {
//        LuaLimits.lua_assert(target < fs.pc);
//        patchlistaux(fs, list, target, LuaOpCodes.NO_REG, target);
//        }
    }
    
    public static func luaK_patchtohere(fs:FuncState!, list:Int) {
//        luaK_getlabel(fs);
//        int[] jpc_ref = new int[1];
//        jpc_ref[0] = fs.jpc;
//        luaK_concat(fs, jpc_ref, list); //ref
//        fs.jpc = jpc_ref[0];
    }
    
    public static func luaK_concat(fs:FuncState!, l1:[Int]!, l2:Int) { //ref
//        if (l2 == NO_JUMP) {
//        return;
//        }
//        else if (l1[0] == NO_JUMP) {
//        l1[0] = l2;
//        }
//        else {
//        int list = l1[0];
//        int next;
//        while ((next = getjump(fs, list)) != NO_JUMP) { // find last element
//        list = next;
//        }
//        fixjump(fs, list, l2);
//        }
    }
    
    public static func luaK_checkstack(fs:FuncState!, n:Int) {
//        int newstack = fs.freereg + n;
//        if (newstack > fs.f.maxstacksize) {
//        if (newstack >= LuaLimits.MAXSTACK) {
//        LuaLex.luaX_syntaxerror(fs.ls, CLib.CharPtr.toCharPtr("function or expression too complex"));
//        }
//        fs.f.maxstacksize = LuaLimits.cast_byte(newstack);
//        }
    }
    
    public static func luaK_reserveregs(fs:FuncState!, n:Int) {
//        luaK_checkstack(fs, n);
//        fs.freereg += n;
    }
    
    private static func freereg(fs:FuncState!, reg:Int) {
//        if ((LuaOpCodes.ISK(reg) == 0) && reg >= fs.nactvar) {
//        fs.freereg--;
//        LuaLimits.lua_assert(reg == fs.freereg);
//        }
    }
    
    private static func freeexp(fs:FuncState!, e:expdesc!) {
//        if (e.k == LuaParser.expkind.VNONRELOC) {
//        freereg(fs, e.u.s.info);
//        }
    }
    
    private static func addk(fs:FuncState!, k:TValue!, v:TValue!) -> Int {
//        LuaState.lua_State L = fs.L;
//        LuaObject.TValue idx = LuaTable.luaH_set(L, fs.h, k);
//        LuaObject.Proto f = fs.f;
//        int oldsize = f.sizek;
//        if (LuaObject.ttisnumber(idx)) {
//        LuaLimits.lua_assert(LuaObject.luaO_rawequalObj(fs.f.k[LuaLimits.cast_int(LuaObject.nvalue(idx))], v));
//        return LuaLimits.cast_int(LuaObject.nvalue(idx));
//        }
//        else {
//        // constant not found; create a new entry
//        LuaObject.setnvalue(idx, LuaLimits.cast_num(fs.nk));
//        LuaObject.TValue[][] k_ref = new LuaObject.TValue[1][];
//        k_ref[0] = f.k;
//        int[] sizek_ref = new int[1];
//        sizek_ref[0] = f.sizek;
//        LuaMem.luaM_growvector_TValue(L, k_ref, fs.nk, sizek_ref, LuaOpCodes.MAXARG_Bx, CLib.CharPtr.toCharPtr("constant table overflow"), new ClassType(ClassType.TYPE_TVALUE)); //ref - ref
//        f.sizek = sizek_ref[0];
//        f.k = k_ref[0];
//        while (oldsize < f.sizek) {
//        LuaObject.setnilvalue(f.k[oldsize++]);
//        }
//        LuaObject.setobj(L, f.k[fs.nk], v);
//        LuaGC.luaC_barrier(L, f, v);
//        return fs.nk++;
//        }
        return 0
    }
    
    public static func luaK_stringK(fs:FuncState!, s:TString!) -> Int {
//        LuaObject.TValue o = new LuaObject.TValue();
//        LuaObject.setsvalue(fs.L, o, s);
//        return addk(fs, o, o);
        return 0
    }
    
    public static func luaK_numberK(fs:FuncState!, r:Double) -> Int { //lua_Number
//        LuaObject.TValue o = new LuaObject.TValue();
//        LuaObject.setnvalue(o, r);
//        return addk(fs, o, o);
        return 0
    }
    
    private static func boolK(fs:FuncState!, b:Int) -> Int {
//        LuaObject.TValue o = new LuaObject.TValue();
//        LuaObject.setbvalue(o, b);
//        return addk(fs, o, o);
        return 0
    }
    
    private static func nilK(fs:FuncState!) -> Int {
//        LuaObject.TValue k = new LuaObject.TValue(), v = new LuaObject.TValue();
//        LuaObject.setnilvalue(v);
//        // cannot use nil as key; instead use table itself to represent nil
//        LuaObject.sethvalue(fs.L, k, fs.h);
//        return addk(fs, k, v);
        return 0
    }

    public static func luaK_setreturns(fs:FuncState!, e:expdesc!, nresults:Int) {
//        if (e.k == LuaParser.expkind.VCALL) {
//        // expression is an open function call?
//        LuaOpCodes.SETARG_C(getcode(fs, e), nresults + 1);
//        }
//        else if (e.k == LuaParser.expkind.VVARARG) {
//        LuaOpCodes.SETARG_B(getcode(fs, e), nresults + 1);
//        LuaOpCodes.SETARG_A(getcode(fs, e), fs.freereg);
//        luaK_reserveregs(fs, 1);
//        }
    }
    
    public static func luaK_setoneret(fs:FuncState!, e:expdesc!) {
//        if (e.k == LuaParser.expkind.VCALL) {
//        // expression is an open function call?
//        e.k = LuaParser.expkind.VNONRELOC;
//        e.u.s.info = LuaOpCodes.GETARG_A(getcode(fs, e));
//        }
//        else if (e.k == LuaParser.expkind.VVARARG) {
//        LuaOpCodes.SETARG_B(getcode(fs, e), 2);
//        e.k = LuaParser.expkind.VRELOCABLE; // can relocate its simple result
//        }
    }
    
    public static func luaK_dischargevars(fs:FuncState!, e:expdesc!) {
//        switch (e.k) {
//        case VLOCAL: {
//        e.k = LuaParser.expkind.VNONRELOC;
//        break;
//        }
//        case VUPVAL: {
//        e.u.s.info = luaK_codeABC(fs, LuaOpCodes.OpCode.OP_GETUPVAL, 0, e.u.s.info, 0);
//        e.k = LuaParser.expkind.VRELOCABLE;
//        break;
//        }
//        case VGLOBAL: {
//        e.u.s.info = luaK_codeABx(fs, LuaOpCodes.OpCode.OP_GETGLOBAL, 0, e.u.s.info);
//        e.k = LuaParser.expkind.VRELOCABLE;
//        break;
//        }
//        case VINDEXED: {
//        freereg(fs, e.u.s.aux);
//        freereg(fs, e.u.s.info);
//        e.u.s.info = luaK_codeABC(fs, LuaOpCodes.OpCode.OP_GETTABLE, 0, e.u.s.info, e.u.s.aux);
//        e.k = LuaParser.expkind.VRELOCABLE;
//        break;
//        }
//        case VVARARG:
//        case VCALL: {
//        luaK_setoneret(fs, e);
//        break;
//        }
//        default: {
//        break; // there is one value available (somewhere)
//        }
//        }
    }
    
    private static func code_label(fs:FuncState!, A:Int, b:Int, jump:Int) -> Int {
//        luaK_getlabel(fs); // those instructions may be jump targets
//        return luaK_codeABC(fs, LuaOpCodes.OpCode.OP_LOADBOOL, A, b, jump);
        return 0
    }
    
    private static func discharge2reg(fs:FuncState!, e:expdesc!, reg:Int) {
//        luaK_dischargevars(fs, e);
//        switch (e.k) {
//        case VNIL: {
//        luaK_nil(fs, reg, 1);
//        break;
//        }
//        case VFALSE:
//        case VTRUE: {
//        luaK_codeABC(fs, LuaOpCodes.OpCode.OP_LOADBOOL, reg, (e.k == LuaParser.expkind.VTRUE) ? 1 : 0, 0);
//        break;
//        }
//        case VK: {
//        luaK_codeABx(fs, LuaOpCodes.OpCode.OP_LOADK, reg, e.u.s.info);
//        break;
//        }
//        case VKNUM: {
//        luaK_codeABx(fs, LuaOpCodes.OpCode.OP_LOADK, reg, luaK_numberK(fs, e.u.nval));
//        break;
//        }
//        case VRELOCABLE: {
//        InstructionPtr pc = getcode(fs, e);
//        LuaOpCodes.SETARG_A(pc, reg);
//        break;
//        }
//        case VNONRELOC: {
//        if (reg != e.u.s.info) {
//        luaK_codeABC(fs, LuaOpCodes.OpCode.OP_MOVE, reg, e.u.s.info, 0);
//        }
//        break;
//        }
//        default: {
//        LuaLimits.lua_assert(e.k == LuaParser.expkind.VVOID || e.k == LuaParser.expkind.VJMP);
//        return; // nothing to do...
//        }
//        }
//        e.u.s.info = reg;
//        e.k = LuaParser.expkind.VNONRELOC;
    }
    
    private static func discharge2anyreg(fs:FuncState!, e:expdesc!) {
//        if (e.k != LuaParser.expkind.VNONRELOC) {
//        luaK_reserveregs(fs, 1);
//        discharge2reg(fs, e, fs.freereg-1);
//        }
    }
    
    private static func exp2reg(fs:FuncState!, e:expdesc!, reg:Int) {
//        discharge2reg(fs, e, reg);
//        if (e.k == LuaParser.expkind.VJMP) {
//        int[] t_ref = new int[1];
//        t_ref[0] = e.t;
//        luaK_concat(fs, t_ref, e.u.s.info); // put this jump in `t' list  - ref
//        e.t = t_ref[0];
//        }
//        if (hasjumps(e)) {
//        int final_; // position after whole expression
//        int p_f = NO_JUMP; // position of an eventual LOAD false
//        int p_t = NO_JUMP; // position of an eventual LOAD true
//        if (need_value(fs, e.t) != 0 || need_value(fs, e.f) != 0) {
//        int fj = (e.k == LuaParser.expkind.VJMP) ? NO_JUMP : luaK_jump(fs);
//        p_f = code_label(fs, reg, 0, 1);
//        p_t = code_label(fs, reg, 1, 0);
//        luaK_patchtohere(fs, fj);
//        }
//        final_ = luaK_getlabel(fs);
//        patchlistaux(fs, e.f, final_, reg, p_f);
//        patchlistaux(fs, e.t, final_, reg, p_t);
//        }
//        e.f = e.t = NO_JUMP;
//        e.u.s.info = reg;
//        e.k = LuaParser.expkind.VNONRELOC;
    }
    
    public static func luaK_exp2nextreg(fs:FuncState!, e:expdesc!) {
//        luaK_dischargevars(fs, e);
//        freeexp(fs, e);
//        luaK_reserveregs(fs, 1);
//        exp2reg(fs, e, fs.freereg - 1);
    }
    
    public static func luaK_exp2anyreg(fs:FuncState!, e:expdesc!) -> Int {
//        luaK_dischargevars(fs, e);
//        if (e.k == LuaParser.expkind.VNONRELOC) {
//        if (!hasjumps(e)) {
//        return e.u.s.info; // exp is already in a register
//        }
//        if (e.u.s.info >= fs.nactvar) {
//        // reg. is not a local?
//        exp2reg(fs, e, e.u.s.info); // put value on it
//        return e.u.s.info;
//        }
//        }
//        luaK_exp2nextreg(fs, e); // default
//        return e.u.s.info;
        return 0
    }
    
    public static func luaK_exp2val(fs:FuncState!, e:expdesc!) {
//        if (hasjumps(e)) {
//        luaK_exp2anyreg(fs, e);
//        }
//        else {
//        luaK_dischargevars(fs, e);
//        }
    }
    
    public static func luaK_exp2RK(fs:FuncState!, e:expdesc!) -> Int {
//        luaK_exp2val(fs, e);
//        switch (e.k) {
//        case VKNUM:
//        case VTRUE:
//        case VFALSE:
//        case VNIL: {
//        if (fs.nk <= LuaOpCodes.MAXINDEXRK) {
//        // constant fit in RK operand?
//        e.u.s.info = (e.k == LuaParser.expkind.VNIL) ? nilK(fs) : (e.k == LuaParser.expkind.VKNUM) ? luaK_numberK(fs, e.u.nval) : boolK(fs, (e.k == LuaParser.expkind.VTRUE) ? 1 : 0);
//        e.k = LuaParser.expkind.VK;
//        return LuaOpCodes.RKASK(e.u.s.info);
//        }
//        else {
//        break;
//        }
//        }
//        case VK: {
//        if (e.u.s.info <= LuaOpCodes.MAXINDEXRK) { // constant fit in argC?
//        return LuaOpCodes.RKASK(e.u.s.info);
//        }
//        else {
//        break;
//        }
//        }
//        default: {
//        break;
//        }
//        }
//        // not a constant in the right range: put it in a register
//        return luaK_exp2anyreg(fs, e);
        return 0
    }
    
    
    public static func luaK_self(fs:FuncState!, e:expdesc!, key:expdesc!) {
//        int func;
//        luaK_exp2anyreg(fs, e);
//        freeexp(fs, e);
//        func = fs.freereg;
//        luaK_reserveregs(fs, 2);
//        luaK_codeABC(fs, LuaOpCodes.OpCode.OP_SELF, func, e.u.s.info, luaK_exp2RK(fs, key));
//        freeexp(fs, key);
//        e.u.s.info = func;
//        e.k = LuaParser.expkind.VNONRELOC;
    }
    
    private static func invertjump(fs:FuncState!, e:expdesc!) {
//        InstructionPtr pc = getjumpcontrol(fs, e.u.s.info);
//        LuaLimits.lua_assert(LuaOpCodes.testTMode(LuaOpCodes.GET_OPCODE(pc.get(0))) != 0 && LuaOpCodes.GET_OPCODE(pc.get(0)) != LuaOpCodes.OpCode.OP_TESTSET && LuaOpCodes.GET_OPCODE(pc.get(0)) != LuaOpCodes.OpCode.OP_TEST);
//        LuaOpCodes.SETARG_A(pc, (LuaOpCodes.GETARG_A(pc.get(0)) == 0) ? 1 : 0);
    }
    
    
    private static func jumponcond(fs:FuncState!, e:expdesc!, cond:Int) -> Int {
//        if (e.k == LuaParser.expkind.VRELOCABLE) {
//        InstructionPtr ie = getcode(fs, e);
//        if (LuaOpCodes.GET_OPCODE(ie) == LuaOpCodes.OpCode.OP_NOT) {
//        fs.pc--; // remove previous OpCode.OP_NOT
//        return condjump(fs, LuaOpCodes.OpCode.OP_TEST, LuaOpCodes.GETARG_B(ie), 0, (cond == 0) ? 1 : 0);
//        }
//        // else go through
//        }
//        discharge2anyreg(fs, e);
//        freeexp(fs, e);
//        return condjump(fs, LuaOpCodes.OpCode.OP_TESTSET, LuaOpCodes.NO_REG, e.u.s.info, cond);
        return 0
    }
    
    public static func luaK_goiftrue(fs:FuncState!, e:expdesc!) {
//        int pc; // pc of last jump
//        luaK_dischargevars(fs, e);
//        switch (e.k) {
//        case VK:
//        case VKNUM:
//        case VTRUE: {
//        pc = NO_JUMP; // always true; do nothing
//        break;
//        }
//        case VFALSE: {
//        pc = luaK_jump(fs); // always jump
//        break;
//        }
//        case VJMP: {
//        invertjump(fs, e);
//        pc = e.u.s.info;
//        break;
//        }
//        default: {
//        pc = jumponcond(fs, e, 0);
//        break;
//        }
//        }
//        int[] f_ref = new int[1];
//        f_ref[0] = e.f;
//        luaK_concat(fs, f_ref, pc); // insert last jump in `f' list  - ref
//        e.f = f_ref[0];
//        luaK_patchtohere(fs, e.t);
//        e.t = NO_JUMP;
    }
    
    private static func luaK_goiffalse(fs:FuncState!, e:expdesc!) {
//        int pc; // pc of last jump
//        luaK_dischargevars(fs, e);
//        switch (e.k) {
//        case VNIL:
//        case VFALSE: {
//        pc = LuaCode.NO_JUMP; // always false; do nothing
//        break;
//        }
//        case VTRUE: {
//        pc = luaK_jump(fs); // always jump
//        break;
//        }
//        case VJMP: {
//        pc = e.u.s.info;
//        break;
//        }
//        default: {
//        pc = jumponcond(fs, e, 1);
//        break;
//        }
//        }
//        int[] t_ref = new int[1];
//        t_ref[0] = e.t;
//        luaK_concat(fs, t_ref, pc); // insert last jump in `t' list  - ref
//        e.t = t_ref[0];
//        luaK_patchtohere(fs, e.f);
//        e.f = NO_JUMP;
    }
    
    private static func codenot(fs:FuncState!, e:expdesc!) {
//        luaK_dischargevars(fs, e);
//        switch (e.k) {
//        case VNIL:
//        case VFALSE: {
//        e.k = LuaParser.expkind.VTRUE;
//        break;
//        }
//        case VK:
//        case VKNUM:
//        case VTRUE: {
//        e.k = LuaParser.expkind.VFALSE;
//        break;
//        }
//        case VJMP: {
//        invertjump(fs, e);
//        break;
//        }
//        case VRELOCABLE:
//        case VNONRELOC: {
//        discharge2anyreg(fs, e);
//        freeexp(fs, e);
//        e.u.s.info = luaK_codeABC(fs, LuaOpCodes.OpCode.OP_NOT, 0, e.u.s.info, 0);
//        e.k = LuaParser.expkind.VRELOCABLE;
//        break;
//        }
//        default: {
//        LuaLimits.lua_assert(0); // cannot happen
//        break;
//        }
//    }
//
//    //
//    // interchange true and false lists
//    //
//
//    if (true) {
//    int temp = e.f;
//    e.f = e.t;
//    e.t = temp;
//    }
//    removevalues(fs, e.f);
//    removevalues(fs, e.t);
    }
    
    public static func luaK_indexed(fs:FuncState!, t:expdesc!, k:expdesc!) {
//        t.u.s.aux = luaK_exp2RK(fs, k);
//        t.k = LuaParser.expkind.VINDEXED;
    }
    
    private static func constfolding(op:OpCode, e1:expdesc!, e2:expdesc!) -> Int {
//        double v1, v2, r; //lua_Number
//        if ((isnumeral(e1)==0) || (isnumeral(e2)==0)) {
//        return 0;
//        }
//        v1 = e1.u.nval;
//        v2 = e2.u.nval;
//        switch (op) {
//        case OP_ADD: {
//        r = LuaConf.luai_numadd(v1, v2);
//        break;
//        }
//        case OP_SUB: {
//        r = LuaConf.luai_numsub(v1, v2);
//        break;
//        }
//        case OP_MUL: {
//        r = LuaConf.luai_nummul(v1, v2);
//        break;
//        }
//        case OP_DIV: {
//        if (v2 == 0) {
//        return 0; // do not attempt to divide by 0
//        }
//        r = LuaConf.luai_numdiv(v1, v2);
//        break;
//        }
//        case OP_MOD: {
//        if (v2 == 0) {
//        return 0; // do not attempt to divide by 0
//        }
//        r = LuaConf.luai_nummod(v1, v2);
//        break;
//        }
//        case OP_POW: {
//        r = LuaConf.luai_numpow(v1, v2);
//        break;
//        }
//        case OP_UNM: {
//        r = LuaConf.luai_numunm(v1);
//        break;
//        }
//        case OP_LEN: {
//        return 0; // no constant folding for 'len'
//        }
//        default: {
//        LuaLimits.lua_assert(0);
//        r = 0;
//        break;
//        }
//        }
//        if (LuaConf.luai_numisnan(r)) {
//        return 0; // do not attempt to produce NaN
//        }
//        e1.u.nval = r;
//        return 1;
        return 0
    }
    
    private static func codearith(fs:FuncState!, op:OpCode, e1:expdesc!, e2:expdesc!) {
//        if (constfolding(op, e1, e2) != 0) {
//        return;
//        }
//        else {
//        int o2 = (op != LuaOpCodes.OpCode.OP_UNM && op != LuaOpCodes.OpCode.OP_LEN) ? luaK_exp2RK(fs, e2) : 0;
//        int o1 = luaK_exp2RK(fs, e1);
//        if (o1 > o2) {
//        freeexp(fs, e1);
//        freeexp(fs, e2);
//        }
//        else {
//        freeexp(fs, e2);
//        freeexp(fs, e1);
//        }
//        e1.u.s.info = luaK_codeABC(fs, op, 0, o1, o2);
//        e1.k = LuaParser.expkind.VRELOCABLE;
//        }
    }
    
    private static func codecomp(fs:FuncState!, op:OpCode, cond:Int, e1:expdesc!, e2:expdesc!) {
//        int o1 = luaK_exp2RK(fs, e1);
//        int o2 = luaK_exp2RK(fs, e2);
//        freeexp(fs, e2);
//        freeexp(fs, e1);
//        if (cond == 0 && op != LuaOpCodes.OpCode.OP_EQ) {
//        int temp; // exchange args to replace by `<' or `<='
//        temp = o1;
//        o1 = o2;
//        o2 = temp; // o1 <==> o2
//        cond = 1;
//        }
//        e1.u.s.info = condjump(fs, op, cond, o1, o2);
//        e1.k = LuaParser.expkind.VJMP;
    }
    
    
    public static func luaK_prefix(fs:FuncState, op:UnOpr, e:expdesc!) {
//        LuaParser.expdesc e2 = new LuaParser.expdesc();
//        e2.t = e2.f = NO_JUMP;
//        e2.k = LuaParser.expkind.VKNUM;
//        e2.u.nval = 0;
//        switch (op) {
//        case OPR_MINUS: {
//        if (isnumeral(e)==0) {
//        luaK_exp2anyreg(fs, e); // cannot operate on non-numeric constants
//        }
//        codearith(fs, LuaOpCodes.OpCode.OP_UNM, e, e2);
//        break;
//        }
//        case OPR_NOT: {
//        codenot(fs, e);
//        break;
//        }
//        case OPR_LEN: {
//        luaK_exp2anyreg(fs, e); // cannot operate on constants
//        codearith(fs, LuaOpCodes.OpCode.OP_LEN, e, e2);
//        break;
//        }
//        default: {
//        LuaLimits.lua_assert(0);
//        break;
//        }
//        }
    }
    
    
    public static func luaK_infix(fs:FuncState!, op:BinOpr, v:expdesc!) {
//        switch (op) {
//        case OPR_AND: {
//        luaK_goiftrue(fs, v);
//        break;
//        }
//        case OPR_OR: {
//        luaK_goiffalse(fs, v);
//        break;
//        }
//        case OPR_CONCAT: {
//        luaK_exp2nextreg(fs, v); // operand must be on the `stack'
//        break;
//        }
//        case OPR_ADD:
//        case OPR_SUB:
//        case OPR_MUL:
//        case OPR_DIV:
//        case OPR_MOD:
//        case OPR_POW: {
//        if ((isnumeral(v)==0)) {
//        luaK_exp2RK(fs, v);
//        }
//        break;
//        }
//        default: {
//        luaK_exp2RK(fs, v);
//        break;
//        }
//        }
    }
    
    
    public static func luaK_posfix(fs:FuncState!, op:BinOpr!, e1:expdesc!, e2:expdesc!) {
//        switch (op) {
//        case OPR_AND: {
//        LuaLimits.lua_assert(e1.t == NO_JUMP); // list must be closed
//        luaK_dischargevars(fs, e2);
//        int[] f_ref = new int[1];
//        f_ref[0] = e2.f;
//        luaK_concat(fs, f_ref, e1.f); //ref
//        e2.f = f_ref[0];
//        e1.Copy(e2);
//        break;
//        }
//        case OPR_OR: {
//        LuaLimits.lua_assert(e1.f == NO_JUMP); // list must be closed
//        luaK_dischargevars(fs, e2);
//        int[] t_ref = new int[1];
//        t_ref[0] = e2.t;
//        luaK_concat(fs, t_ref, e1.t); //ref
//        e2.t = t_ref[0];
//        e1.Copy(e2);
//        break;
//        }
//        case OPR_CONCAT: {
//        luaK_exp2val(fs, e2);
//        if (e2.k == LuaParser.expkind.VRELOCABLE && LuaOpCodes.GET_OPCODE(getcode(fs, e2)) == LuaOpCodes.OpCode.OP_CONCAT) {
//        LuaLimits.lua_assert(e1.u.s.info == LuaOpCodes.GETARG_B(getcode(fs, e2)) - 1);
//        freeexp(fs, e1);
//        LuaOpCodes.SETARG_B(getcode(fs, e2), e1.u.s.info);
//        e1.k = LuaParser.expkind.VRELOCABLE;
//        e1.u.s.info = e2.u.s.info;
//        }
//        else {
//        luaK_exp2nextreg(fs, e2); // operand must be on the 'stack'
//        codearith(fs, LuaOpCodes.OpCode.OP_CONCAT, e1, e2);
//        }
//        break;
//        }
//        case OPR_ADD: {
//        codearith(fs, LuaOpCodes.OpCode.OP_ADD, e1, e2);
//        break;
//        }
//        case OPR_SUB: {
//        codearith(fs, LuaOpCodes.OpCode.OP_SUB, e1, e2);
//        break;
//        }
//        case OPR_MUL: {
//        codearith(fs, LuaOpCodes.OpCode.OP_MUL, e1, e2);
//        break;
//        }
//        case OPR_DIV: {
//        codearith(fs, LuaOpCodes.OpCode.OP_DIV, e1, e2);
//        break;
//        }
//        case OPR_MOD: {
//        codearith(fs, LuaOpCodes.OpCode.OP_MOD, e1, e2);
//        break;
//        }
//        case OPR_POW: {
//        codearith(fs, LuaOpCodes.OpCode.OP_POW, e1, e2);
//        break;
//        }
//        case OPR_EQ: {
//        codecomp(fs, LuaOpCodes.OpCode.OP_EQ, 1, e1, e2);
//        break;
//        }
//        case OPR_NE: {
//        codecomp(fs, LuaOpCodes.OpCode.OP_EQ, 0, e1, e2);
//        break;
//        }
//        case OPR_LT: {
//        codecomp(fs, LuaOpCodes.OpCode.OP_LT, 1, e1, e2);
//        break;
//        }
//        case OPR_LE: {
//        codecomp(fs, LuaOpCodes.OpCode.OP_LE, 1, e1, e2);
//        break;
//        }
//        case OPR_GT: {
//        codecomp(fs, LuaOpCodes.OpCode.OP_LT, 0, e1, e2);
//        break;
//        }
//        case OPR_GE: {
//        codecomp(fs, LuaOpCodes.OpCode.OP_LE, 0, e1, e2);
//        break;
//        }
//        default: {
//        LuaLimits.lua_assert(0);
//        break;
//        }
//        }
    }
    
    public static func luaK_fixline(fs:FuncState!, line:Int) {
//        fs.f.lineinfo[fs.pc - 1] = line;
    }
    
    
    private static func luaK_code(fs:FuncState!, i:Int, line:Int) -> Int {
//        LuaObject.Proto f = fs.f;
//        dischargejpc(fs); // `pc' will change
//        // put new instruction in code array
//        long[][] code_ref = new long[1][];
//        code_ref[0] = f.code;
//        int[] sizecode_ref = new int[1];
//        sizecode_ref[0] = f.sizecode;
//        LuaMem.luaM_growvector_long(fs.L, code_ref, fs.pc, sizecode_ref, LuaLimits.MAX_INT, CLib.CharPtr.toCharPtr("code size overflow"), new ClassType(ClassType.TYPE_LONG)); //ref - ref
//        f.sizecode = sizecode_ref[0];
//        f.code = code_ref[0];
//        f.code[fs.pc] = (long)i; //uint
//        // save corresponding line information
//        int[][] lineinfo_ref = new int[1][];
//        lineinfo_ref[0] = f.lineinfo;
//        int[] sizelineinfo_ref = new int[1];
//        sizelineinfo_ref[0] = f.sizelineinfo;
//        LuaMem.luaM_growvector_int(fs.L, lineinfo_ref, fs.pc, sizelineinfo_ref, LuaLimits.MAX_INT, CLib.CharPtr.toCharPtr("code size overflow"), new ClassType(ClassType.TYPE_INT)); //ref - ref
//        f.sizelineinfo = sizelineinfo_ref[0];
//        f.lineinfo = lineinfo_ref[0];
//        f.lineinfo[fs.pc] = line;
//        return fs.pc++;
        return 0
    }
    
    public static func luaK_codeABC(fs:FuncState!, o:OpCode, a:Int, b:Int, c:Int) -> Int {
//        LuaLimits.lua_assert(LuaOpCodes.getOpMode(o) == LuaOpCodes.OpMode.iABC);
//        LuaLimits.lua_assert(LuaOpCodes.getBMode(o) != LuaOpCodes.OpArgMask.OpArgN || b == 0);
//        LuaLimits.lua_assert(LuaOpCodes.getCMode(o) != LuaOpCodes.OpArgMask.OpArgN || c == 0);
//        return luaK_code(fs, LuaOpCodes.CREATE_ABC(o, a, b, c), fs.ls.lastline);
        return 0
    }
    
    public static func luaK_codeABx(fs:FuncState!, o:OpCode, a:Int, bc:Int) -> Int {
//        LuaLimits.lua_assert(LuaOpCodes.getOpMode(o) == LuaOpCodes.OpMode.iABx || LuaOpCodes.getOpMode(o) == LuaOpCodes.OpMode.iAsBx);
//        LuaLimits.lua_assert(LuaOpCodes.getCMode(o) == LuaOpCodes.OpArgMask.OpArgN);
//        return luaK_code(fs, LuaOpCodes.CREATE_ABx(o, a, bc), fs.ls.lastline);
        return 0
    }
    
    public static func luaK_setlist(fs:FuncState!, base_:Int, nelems:Int, tostore:Int) {
//        int c = (nelems - 1) / LuaOpCodes.LFIELDS_PER_FLUSH + 1;
//        int b = (tostore == Lua.LUA_MULTRET) ? 0 : tostore;
//        LuaLimits.lua_assert(tostore != 0);
//        if (c <= LuaOpCodes.MAXARG_C) {
//        luaK_codeABC(fs, LuaOpCodes.OpCode.OP_SETLIST, base_, b, c);
//        }
//        else {
//        luaK_codeABC(fs, LuaOpCodes.OpCode.OP_SETLIST, base_, b, 0);
//        luaK_code(fs, c, fs.ls.lastline);
//        }
//        fs.freereg = base_ + 1; // free registers with list values
    }
}

