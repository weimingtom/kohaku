//package kurumi;

//
// ** $Id: lua.h,v 1.218.1.5 2008/08/06 13:30:12 roberto Exp $
// ** Lua - An Extensible Extension Language
// ** Lua.org, PUC-Rio, Brazil (http://www.lua.org)
// ** See Copyright Notice at the end of this file
//

//using lua_Number = Double;
//using lua_Integer = System.Int32;

public class Lua {
    public static let LUA_VERSION:String = "Lua 5.1"
    public static let LUA_RELEASE:String = "Lua 5.1.4"
    public static let LUA_VERSION_NUM:Int = 501
    public static let LUA_COPYRIGHT:String = "Copyright (C) 1994-2008 Lua.org, PUC-Rio"
    public static let LUA_AUTHORS:String = "R. Ierusalimschy, L. H. de Figueiredo & W. Celes"
    
    // mark for precompiled code (`<esc>Lua')
    public static let LUA_SIGNATURE:String = "\u{001b}Lua"
    
    // option for multiple returns in `lua_pcall' and `lua_call'
    public static let LUA_MULTRET:Int = -1
    
    //
    //         ** pseudo-indices
    //
    public static let LUA_REGISTRYINDEX:Int = -10000;
    public static let LUA_ENVIRONINDEX:Int = -10001;
    public static let LUA_GLOBALSINDEX:Int = -10002;
    public static func lua_upvalueindex(i:Int) -> Int {
        return LUA_GLOBALSINDEX - i;
    }
    
    // thread status; 0 is OK
    public static let LUA_YIELD:Int = 1
    public static let LUA_ERRRUN:Int = 2
    public static let LUA_ERRSYNTAX:Int = 3
    public static let LUA_ERRMEM:Int = 4
    public static let LUA_ERRERR:Int = 5
}

public protocol lua_CFunction {
    func exec(L:lua_State!) -> Int
}

public protocol lua_Reader {
    /*sz*/
    /*out*/
    /*uint*/
    func exec(L:lua_State!, ud:Any!, sz:[Int]!) -> CharPtr!
}

// functions that read/write blocks when loading/dumping Lua chunks
//public delegate int lua_Writer(lua_State L, CharPtr p, int//uint// sz, object ud);
public protocol lua_Writer {
    //uint sz
    func exec(L:lua_State!, p:CharPtr!, sz:Int, ud:Any!) -> Int
}

public protocol lua_Alloc {
    func exec(t:ClassType!) -> Any!
}

extension Lua {
    //
    //         ** basic types
    //
    public static let LUA_TNONE:Int = -1
    
    public static let LUA_TNIL:Int = 0
    public static let LUA_TBOOLEAN:Int = 1
    public static let LUA_TLIGHTUSERDATA:Int = 2
    public static let LUA_TNUMBER:Int = 3
    public static let LUA_TSTRING:Int = 4
    public static let LUA_TTABLE:Int = 5
    public static let LUA_TFUNCTION:Int = 6
    public static let LUA_TUSERDATA:Int = 7
    public static let LUA_TTHREAD:Int = 8
    
    // minimum Lua stack available to a C function
    public static let LUA_MINSTACK:Int = 20
    
    // type of numbers in Lua
    //typedef LUA_NUMBER lua_Number;
    
    // type for integer functions
    //typedef LUA_INTEGER lua_Integer;
    
    //
    //         ** garbage-collection function and options
    //
    public static let LUA_GCSTOP:Int = 0
    public static let LUA_GCRESTART:Int = 1
    public static let LUA_GCCOLLECT:Int = 2
    public static let LUA_GCCOUNT:Int = 3
    public static let LUA_GCCOUNTB:Int = 4
    public static let LUA_GCSTEP:Int = 5
    public static let LUA_GCSETPAUSE:Int = 6
    public static let LUA_GCSETSTEPMUL:Int = 7
    
    //
    //         ** ===============================================================
    //         ** some useful macros
    //         ** ===============================================================
    //
    public static func lua_pop(L:lua_State, n:Int) {
        //LuaAPI.lua_settop(L, -(n) - 1);
    }
    
    public static func lua_newtable(L:lua_State) {
        //LuaAPI.lua_createtable(L, 0, 0);
    }
    
    public static func lua_register(L:lua_State!, n:CharPtr!, f:lua_CFunction!) {
        //lua_pushcfunction(L, f);
        //lua_setglobal(L, n);
    }
    
    public static func lua_pushcfunction(L:lua_State!, f:lua_CFunction!) {
        //LuaAPI.lua_pushcclosure(L, f, 0);
    }
    
    public static func lua_strlen(L:lua_State!, i:Int) -> Int { //uint
        //return LuaAPI.lua_objlen(L, i);
        return 0
    }
    
    public static func lua_isfunction(L:lua_State!, n:Int) -> Bool  {
//        return LuaAPI.lua_type(L, n) == LUA_TFUNCTION;
        return false
    }
    
    public static func lua_istable(L:lua_State, n:Int) -> Bool {
//        return LuaAPI.lua_type(L, n) == LUA_TTABLE;
        return false
    }

    public static func lua_islightuserdata(L:lua_State!, n:Int) -> Bool {
//        return LuaAPI.lua_type(L, n) == LUA_TLIGHTUSERDATA;
        return false
    }
    
    public static func lua_isnil(L:lua_State!, n:Int) -> Bool {
//        return LuaAPI.lua_type(L, n) == LUA_TNIL;
        return false
    }
    
    public static func lua_isboolean(L:lua_State!, n:Int) -> Bool {
//        return LuaAPI.lua_type(L, n) == LUA_TBOOLEAN;
        return false
    }

    public static func lua_isthread(L:lua_State!, n:Int) -> Bool {
//    return LuaAPI.lua_type(L, n) == LUA_TTHREAD;
        return false
    }

    public static func lua_isnone(L:lua_State!, n:Int) -> Bool {
//        return LuaAPI.lua_type(L, n) == LUA_TNONE;
        return false
    }
    
    public static func lua_isnoneornil(L:lua_State!, n:Double) -> Bool { //lua_Number
//        return LuaAPI.lua_type(L, (int)n) <= 0;
        return false
    }
    
    public static func lua_pushliteral(L:lua_State!, s:CharPtr!) {
        //TODO: Implement use using lua_pushlstring instead of lua_pushstring
        //lua_pushlstring(L, "" s, (sizeof(s)/GetUnmanagedSize(typeof(char)))-1)
//        LuaAPI.lua_pushstring(L, s);
    }
    
    public static func lua_setglobal(L:lua_State!, s:CharPtr!) {
//        LuaAPI.lua_setfield(L, LUA_GLOBALSINDEX, s);
    }
    
    public static func lua_getglobal(L:lua_State!, s:CharPtr!) {
//        LuaAPI.lua_getfield(L, LUA_GLOBALSINDEX, s);
    }
    
    public static func lua_tostring(L:lua_State, i:Int) -> CharPtr! {
//        int[] blah = new int[1]; //uint
//        return LuaAPI.lua_tolstring(L, i, blah); //out
        return nil
    }
    
    ////#define lua_open()    luaL_newstate()
    public static func lua_open() -> lua_State! {
//        return LuaAuxLib.luaL_newstate();
        return nil
    }
    
    ////#define lua_getregistry(L)    lua_pushvalue(L, LUA_REGISTRYINDEX)
    public static func lua_getregistry(L:lua_State!) {
//        LuaAPI.lua_pushvalue(L, LUA_REGISTRYINDEX);
    }
    
    ////#define lua_getgccount(L)    lua_gc(L, LUA_GCCOUNT, 0)
    public static func lua_getgccount(L:lua_State!) -> Int {
//        return LuaAPI.lua_gc(L, LUA_GCCOUNT, 0);
        return 0
    }
    
    
    ///#define lua_Chunkreader        lua_Reader
    ///#define lua_Chunkwriter        lua_Writer
    
    
    //
    //         ** {======================================================================
    //         ** Debug API
    //         ** =======================================================================
    //
    
    
    //
    //         ** Event codes
    //
    public static let LUA_HOOKCALL:Int = 0
    public static let LUA_HOOKRET:Int = 1
    public static let LUA_HOOKLINE:Int = 2
    public static let LUA_HOOKCOUNT:Int = 3
    public static let LUA_HOOKTAILRET:Int = 4
    
    //
    //         ** Event masks
    //
    public static let LUA_MASKCALL:Int = (1 << LUA_HOOKCALL)
    public static let LUA_MASKRET:Int = (1 << LUA_HOOKRET)
    public static let LUA_MASKLINE:Int = (1 << LUA_HOOKLINE)
    public static let LUA_MASKCOUNT:Int = (1 << LUA_HOOKCOUNT)
}


/* Functions to be called by the debuger in specific events */
//public delegate void lua_Hook(lua_State L, lua_Debug ar);
public protocol lua_Hook {
    func exec(L:lua_State!, ar:lua_Debug!)
}

public class lua_Debug
{
    public var event_:Int = 0
    public var name:CharPtr!    /* (n) */
    public var namewhat:CharPtr!    /* (n) `global', `local', `field', `method' */
    public var what:CharPtr!    /* (S) `Lua', `C', `main', `tail' */
    public var source:CharPtr!    /* (S) */
    public var currentline:Int = 0    /* (l) */
    public var nups:Int = 0        /* (u) number of upvalues */
    public var linedefined:Int = 0    /* (S) */
    public var lastlinedefined:Int = 0    /* (S) */
    //[Character](count:LuaConf.LUA_IDSIZE)
    public var short_src:CharPtr! = CharPtr.toCharPtr(chars:[Character](repeating: "\0", count:LuaConf.LUA_IDSIZE)) /* (S) */
    /* private part */
    public var i_ci:Int = 0  /* active function */
}

// }======================================================================

extension Lua {
//        *****************************************************************************
//         * Copyright (C) 1994-2008 Lua.org, PUC-Rio.  All rights reserved.
//         *
//         * Permission is hereby granted, free of charge, to any person obtaining
//         * a copy of this software and associated documentation files (the
//         * "Software"), to deal in the Software without restriction, including
//         * without limitation the rights to use, copy, modify, merge, publish,
//         * distribute, sublicense, and/or sell copies of the Software, and to
//         * permit persons to whom the Software is furnished to do so, subject to
//         * the following conditions:
//         *
//         * The above copyright notice and this permission notice shall be
//         * included in all copies or substantial portions of the Software.
//         *
//         * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//         * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//         * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
//         * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
//         * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
//         * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
//         * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//         *****************************************************************************
}

//public delegate int lua_CFunction(lua_State L);
//public delegate CharPtr lua_Reader(lua_State L, object ud, out int/*uint*/ sz);

//public interface lua_CFunction
//{
//    int exec(lua_State L);
//}
//public interface lua_Reader
//{
//    CharPtr exec(lua_State L, object ud, /*out*/ int[]/*uint*/ sz);
//}

//
//     ** prototype for memory-allocation functions
//
//public delegate object lua_Alloc(object ud, object ptr, uint osize, uint nsize);

//public delegate object lua_Alloc(Type t);
//public interface lua_Alloc
//{
//    object exec(ClassType t);
//}


//
//     ** functions that read/write blocks when loading/dumping Lua chunks
//
//public delegate int lua_Writer(lua_State L, CharPtr p, int/*uint*/ sz, object ud);
//public interface lua_Writer
//{
//    int exec(lua_State L, CharPtr p, int/*uint*/ sz, object ud);
//}


// Functions to be called by the debuger in specific events
//public delegate void lua_Hook(lua_State L, lua_Debug ar);
//public interface lua_Hook
//{
//    void exec(lua_State L, lua_Debug ar);
//}

