//
//  main.swift
//  kohaku
//
//  Created by  on 2018/2/1.
//  Copyright © 2018年 weimingtom. All rights reserved.
//

import Foundation

print("Hello, World!")

print(Lua.LUA_MINSTACK)

