//package kurumi;

//
// ** $Id: ldblib.c,v 1.104.1.3 2008/01/21 13:11:21 roberto Exp $
// ** Interface from Lua to its debug API
// ** See Copyright Notice in lua.h
//

public class LuaDebugLib {
    fileprivate static func db_getregistry(L:lua_State!) -> Int {
        LuaAPI.lua_pushvalue(L: L, idx: Lua.LUA_REGISTRYINDEX)
        return 1
    }
    
    fileprivate static func db_getmetatable(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checkany(L: L, narg: 1)
        if (LuaAPI.lua_getmetatable(L: L, objindex: 1) == 0) {
            LuaAPI.lua_pushnil(L: L) // no metatable
        }
        return 1
    }
    
    fileprivate static func db_setmetatable(L:lua_State!) -> Int {
        let t:Int = LuaAPI.lua_type(L: L, idx: 2)
        LuaAuxLib.luaL_argcheck(L: L, cond: t == Lua.LUA_TNIL || t == Lua.LUA_TTABLE, numarg: 2, extramsg: "nil or table expected")
        LuaAPI.lua_settop(L: L, idx: 2)
        LuaAPI.lua_pushboolean(L: L, b: LuaAPI.lua_setmetatable(L: L, objindex: 1))
        return 1
    }
    
    fileprivate static func db_getfenv(L:lua_State!) -> Int {
        LuaAPI.lua_getfenv(L: L, idx: 1)
        return 1
    }
    
    
    fileprivate static func db_setfenv(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checktype(L: L, narg: 2, t: Lua.LUA_TTABLE)
        LuaAPI.lua_settop(L: L, idx: 2)
        if (LuaAPI.lua_setfenv(L: L, idx: 1) == 0) {
            _ = LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: LuaConf.LUA_QL(x: "setfenv").toString() + " cannot change environment of given object"));
        }
        return 1
    }

    fileprivate static func settabss(L:lua_State!, i:CharPtr!, v:CharPtr!) {
        LuaAPI.lua_pushstring(L: L, s: v)
        LuaAPI.lua_setfield(L: L, idx: -2, k: i)
    }
    
    fileprivate static func settabsi(L:lua_State!, i:CharPtr!, v:Int) {
        LuaAPI.lua_pushinteger(L: L, n: v);
        LuaAPI.lua_setfield(L: L, idx: -2, k: i);
    }
    
    fileprivate static func getthread(L:lua_State!, arg:inout [Int]!) -> lua_State! { //out
        if (Lua.lua_isthread(L: L, n: 1)) {
            arg[0] = 1
            return LuaAPI.lua_tothread(L: L, idx: 1)
        }
        else {
            arg[0] = 0
            return L
        }
    }
    
    fileprivate static func treatstackoption(L:lua_State!, L1:lua_State!, fname:CharPtr!) {
        if (L === L1) {
            LuaAPI.lua_pushvalue(L: L, idx: -2)
            LuaAPI.lua_remove(L: L, idx: -3)
        }
        else {
            LuaAPI.lua_xmove(from: L1, to: L, n: 1)
        }
        LuaAPI.lua_setfield(L: L, idx: -2, k: fname)
    }
    
    fileprivate static func db_getinfo(L:lua_State!) -> Int {
        let ar:lua_Debug! = lua_Debug()
        var arg:[Int]! = [Int](repeating: 0, count: 1)
        let L1:lua_State! = getthread(L: L, arg: &arg) //out
        var options:CharPtr! = LuaAuxLib.luaL_optstring(L: L, n: arg[0] + 2, d: CharPtr.toCharPtr(str: "flnSu"));
        if (LuaAPI.lua_isnumber(L: L, idx: arg[0] + 1) != 0) {
            if (LuaDebug.lua_getstack(L: L1, level: Int(LuaAPI.lua_tointeger(L: L, idx: arg[0] + 1)), ar: ar) == 0) {
                LuaAPI.lua_pushnil(L: L) // level out of range
                return 1;
            }
        }
        else if (Lua.lua_isfunction(L: L, n: arg[0] + 1)) {
            _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: ">%s"), p: options)
            options = Lua.lua_tostring(L: L, i: -1)
            LuaAPI.lua_pushvalue(L: L, idx: arg[0] + 1)
            LuaAPI.lua_xmove(from: L, to: L1, n: 1)
        }
        else {
            return LuaAuxLib.luaL_argerror(L: L, narg: arg[0] + 1, extramsg: CharPtr.toCharPtr(str: "function or level expected"));
        }
        if (LuaDebug.lua_getinfo(L: L1, what: options, ar: ar) == 0) {
            return LuaAuxLib.luaL_argerror(L: L, narg: arg[0] + 2, extramsg: CharPtr.toCharPtr(str: "invalid option"))
        }
        LuaAPI.lua_createtable(L: L, narray: 0, nrec: 2)
        if (CharPtr.isNotEqual(ptr1: CLib.strchr(str: options, c: "S"), ptr2: nil)) {
            settabss(L: L, i: CharPtr.toCharPtr(str: "source"), v: ar.source)
            settabss(L: L, i: CharPtr.toCharPtr(str: "short_src"), v: ar.short_src)
            settabsi(L: L, i: CharPtr.toCharPtr(str: "linedefined"), v: ar.linedefined)
            settabsi(L: L, i: CharPtr.toCharPtr(str: "lastlinedefined"), v: ar.lastlinedefined)
            settabss(L: L, i: CharPtr.toCharPtr(str: "what"), v: ar.what)
        }
        if (CharPtr.isNotEqual(ptr1: CLib.strchr(str: options, c: "l"), ptr2: nil)) {
            settabsi(L: L, i: CharPtr.toCharPtr(str: "currentline"), v: ar.currentline)
        }
        if (CharPtr.isNotEqual(ptr1: CLib.strchr(str: options, c: "u"), ptr2: nil)) {
            settabsi(L: L, i: CharPtr.toCharPtr(str: "nups"), v: ar.nups)
        }
        if (CharPtr.isNotEqual(ptr1: CLib.strchr(str: options, c: "n"), ptr2: nil)) {
            settabss(L: L, i: CharPtr.toCharPtr(str: "name"), v: ar.name)
            settabss(L: L, i: CharPtr.toCharPtr(str: "namewhat"), v: ar.namewhat)
        }
        if (CharPtr.isNotEqual(ptr1: CLib.strchr(str: options, c: "L"), ptr2: nil)) {
            treatstackoption(L: L, L1: L1, fname: CharPtr.toCharPtr(str: "activelines"))
        }
        if (CharPtr.isNotEqual(ptr1: CLib.strchr(str: options, c: "f"), ptr2: nil)) {
            treatstackoption(L: L, L1: L1, fname: CharPtr.toCharPtr(str: "func"))
        }
        return 1 // return table
    }
    
    fileprivate static func db_getlocal(L:lua_State!) -> Int {
        var arg:[Int]! = [Int](repeating: 0, count: 1)
        let L1:lua_State! = getthread(L: L, arg: &arg) //out
        let ar:lua_Debug! = lua_Debug()
        var name:CharPtr!
        if (LuaDebug.lua_getstack(L: L1, level: LuaAuxLib.luaL_checkint(L: L, n: arg[0] + 1), ar: ar) == 0) { // out of range?
            return LuaAuxLib.luaL_argerror(L: L, narg: arg[0] + 1, extramsg: CharPtr.toCharPtr(str: "level out of range"))
        }
        name = LuaDebug.lua_getlocal(L: L1, ar: ar, n: LuaAuxLib.luaL_checkint(L: L, n: arg[0] + 2))
        if (CharPtr.isNotEqual(ptr1: name, ptr2: nil)) {
            LuaAPI.lua_xmove(from: L1, to: L, n: 1)
            LuaAPI.lua_pushstring(L: L, s: name)
            LuaAPI.lua_pushvalue(L: L, idx: -2)
            return 2
        }
        else {
            LuaAPI.lua_pushnil(L: L)
            return 1
        }
    }
    
    fileprivate static func db_setlocal(L:lua_State!) -> Int {
        var arg:[Int]! = [Int](repeating: 0, count: 1)
        let L1:lua_State! = getthread(L: L, arg: &arg) //out
        let ar:lua_Debug! = lua_Debug()
        if (LuaDebug.lua_getstack(L: L1, level: LuaAuxLib.luaL_checkint(L: L, n: arg[0] + 1), ar: ar) == 0) { // out of range?
            return LuaAuxLib.luaL_argerror(L: L, narg: arg[0] + 1, extramsg: CharPtr.toCharPtr(str: "level out of range"))
        }
        LuaAuxLib.luaL_checkany(L: L, narg: arg[0] + 3)
        LuaAPI.lua_settop(L: L, idx: arg[0] + 3)
        LuaAPI.lua_xmove(from: L, to: L1, n: 1)
        LuaAPI.lua_pushstring(L: L, s: LuaDebug.lua_setlocal(L: L1, ar: ar, n: LuaAuxLib.luaL_checkint(L: L, n: arg[0] + 2)))
        return 1
    }
    
    fileprivate static func auxupvalue(L:lua_State!, get:Int) -> Int {
        var name:CharPtr
        let n:Int = LuaAuxLib.luaL_checkint(L: L, n: 2)
        LuaAuxLib.luaL_checktype(L: L, narg: 1, t: Lua.LUA_TFUNCTION)
        if (LuaAPI.lua_iscfunction(L: L, idx: 1)) { // cannot touch C upvalues from Lua
            return 0
        }
        //FIXME:???
        //{
        name = (get != 0) ? LuaAPI.lua_getupvalue(L: L, funcindex: 1, n: n) : LuaAPI.lua_setupvalue(L: L, funcindex: 1, n: n);
        //}
        if (CharPtr.isEqual(ptr1: name, ptr2: nil)) {
            return 0;
        }
        LuaAPI.lua_pushstring(L: L, s: name)
        LuaAPI.lua_insert(L: L, idx: -(get + 1))
        return get + 1
    }
    
    
    fileprivate static func db_getupvalue(L:lua_State!) -> Int {
        return auxupvalue(L: L, get: 1)
    }
    
    fileprivate static func db_setupvalue(L:lua_State!) -> Int {
        LuaAuxLib.luaL_checkany(L: L, narg: 3)
        return auxupvalue(L: L, get: 0)
    }
    
    private static let KEY_HOOK:String = "h"
    
    private static let hooknames:[String] = [ "call", "return", "line", "count", "tail return" ]
    
    fileprivate static func hookf(L:lua_State!, ar:lua_Debug!) {
        LuaAPI.lua_pushlightuserdata(L: L, p: KEY_HOOK)
        LuaAPI.lua_rawget(L: L, idx: Lua.LUA_REGISTRYINDEX)
        LuaAPI.lua_pushlightuserdata(L: L, p: L)
        LuaAPI.lua_rawget(L: L, idx: -2)
        if (Lua.lua_isfunction(L: L, n: -1)) {
            LuaAPI.lua_pushstring(L: L, s: CharPtr.toCharPtr(str: hooknames[Int(ar.event_)]))
            if (ar.currentline >= 0) {
                LuaAPI.lua_pushinteger(L: L, n: ar.currentline)
            }
            else {
                LuaAPI.lua_pushnil(L: L)
            }
            LuaLimits.lua_assert(c: LuaDebug.lua_getinfo(L: L, what: CharPtr.toCharPtr(str: "lS"), ar: ar))
            LuaAPI.lua_call(L: L, nargs: 2, nresults: 0)
        }
    }
}

public class hookf_delegate: lua_Hook {
    public func exec(L:lua_State!, ar:lua_Debug!) {
        LuaDebugLib.hookf(L: L, ar: ar)
    }
}

extension LuaDebugLib {
    private static func makemask(smask:CharPtr!, count:Int) -> Int {
        var mask:Int = 0
        if (CharPtr.isNotEqual(ptr1: CLib.strchr(str: smask, c: "c"), ptr2: nil)) {
            mask |= Lua.LUA_MASKCALL
        }
        if (CharPtr.isNotEqual(ptr1: CLib.strchr(str: smask, c: "r"), ptr2: nil)) {
            mask |= Lua.LUA_MASKRET
        }
        if (CharPtr.isNotEqual(ptr1: CLib.strchr(str: smask, c: "l"), ptr2: nil)) {
            mask |= Lua.LUA_MASKLINE
        }
        if (count > 0) {
            mask |= Lua.LUA_MASKCOUNT
        }
        return mask
    }
    
    private static func unmakemask(mask:Int, smask:CharPtr!) -> CharPtr! {
        var i:Int = 0
        if ((mask & Lua.LUA_MASKCALL) != 0) {
            smask.set(offset: i, val: "c")
            i += 1
        }
        if ((mask & Lua.LUA_MASKRET) != 0) {
            smask.set(offset: i, val: "r")
            i += 1
        }
        if ((mask & Lua.LUA_MASKLINE) != 0) {
            smask.set(offset: i, val: "l")
            i += 1
        }
        smask.set(offset: i, val: "\0")
        return smask
    }
    
    private static func gethooktable(L:lua_State!) {
        LuaAPI.lua_pushlightuserdata(L: L, p: KEY_HOOK)
        LuaAPI.lua_rawget(L: L, idx: Lua.LUA_REGISTRYINDEX)
        if (!Lua.lua_istable(L: L, n: -1)) {
            Lua.lua_pop(L: L, n: 1)
            LuaAPI.lua_createtable(L: L, narray: 0, nrec: 1)
            LuaAPI.lua_pushlightuserdata(L: L, p: KEY_HOOK)
            LuaAPI.lua_pushvalue(L: L, idx: -2)
            LuaAPI.lua_rawset(L: L, idx: Lua.LUA_REGISTRYINDEX)
        }
    }
    
    fileprivate static func db_sethook(L:lua_State!) -> Int {
        var arg:[Int]! = [Int](repeating: 0, count: 1)
        var mask:Int, count:Int
        var func_:lua_Hook!
        let L1:lua_State! = getthread(L: L, arg: &arg) //out
        if (Lua.lua_isnoneornil(L: L, n: Double(arg[0] + 1))) {
            LuaAPI.lua_settop(L: L, idx: arg[0] + 1)
            func_ = nil
            mask = 0
            count = 0 // turn off hooks
        }
        else {
            let smask:CharPtr! = LuaAuxLib.luaL_checkstring(L: L, n: arg[0] + 2)
            LuaAuxLib.luaL_checktype(L: L, narg: arg[0] + 1, t: Lua.LUA_TFUNCTION)
            count = LuaAuxLib.luaL_optint(L: L, n: arg[0] + 3, d: 0)
            func_ = hookf_delegate()
            mask = makemask(smask: smask, count: count)
        }
        gethooktable(L: L)
        LuaAPI.lua_pushlightuserdata(L: L, p: L1)
        LuaAPI.lua_pushvalue(L: L, idx: arg[0] + 1)
        LuaAPI.lua_rawset(L: L, idx: -3) // set new hook
        Lua.lua_pop(L: L, n: 1) // remove hook table
        _ = LuaDebug.lua_sethook(L: L1, func_: func_, mask: mask, count: count) // set hooks
        return 0
    }
    
    fileprivate static func db_gethook(L:lua_State!) -> Int {
        var arg:[Int]! = [Int](repeating: 0, count: 1)
        let L1:lua_State! = getthread(L: L, arg: &arg) //out
        let buff:CharPtr! = CharPtr.toCharPtr(chars: [Character](repeating: "\0", count: 5))
        let mask:Int = LuaDebug.lua_gethookmask(L: L1)
        let hook:lua_Hook! = LuaDebug.lua_gethook(L: L1)
        if (hook != nil && (hook is hookf_delegate)) { // external hook?
            Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: "external hook"));
        }
        else {
            gethooktable(L: L)
            LuaAPI.lua_pushlightuserdata(L: L, p: L1)
            LuaAPI.lua_rawget(L: L, idx: -2) // get hook
            LuaAPI.lua_remove(L: L, idx: -2) // remove hook table
        }
        LuaAPI.lua_pushstring(L: L, s: unmakemask(mask: mask, smask: buff))
        LuaAPI.lua_pushinteger(L: L, n: LuaDebug.lua_gethookcount(L: L1))
        return 3
    }
    
    
    fileprivate static func db_debug(L:lua_State!) -> Int {
        while (true) {
            let buffer:CharPtr! = CharPtr.toCharPtr(chars: [Character](repeating: "\0", count: 250))
            CLib.fputs(str: CharPtr.toCharPtr(str: "lua_debug> "), stream: CLib.stderr)
            if (CharPtr.isEqual(ptr1: CLib.fgets(str: buffer, stream: CLib.stdin), ptr2: nil) || CLib.strcmp(s1: buffer, s2: CharPtr.toCharPtr(str: "cont\n")) == 0) {
                return 0
            }
            if (LuaAuxLib.luaL_loadbuffer(L: L, buff: buffer, size: CLib.strlen(str: buffer), name: CharPtr.toCharPtr(str: "=(debug command)")) != 0 || LuaAPI.lua_pcall(L: L, nargs: 0, nresults: 0, errfunc: 0) != 0) { //(uint)
                CLib.fputs(str: Lua.lua_tostring(L: L, i: -1), stream: CLib.stderr)
                CLib.fputs(str: CharPtr.toCharPtr(str: "\n"), stream: CLib.stderr)
            }
            LuaAPI.lua_settop(L: L, idx: 0) // remove eventual returns
        }
    }
    
    public static let LEVELS1:Int = 12 // size of the first part of the stack
    public static let LEVELS2:Int = 10 // size of the second part of the stack
    
    fileprivate static func db_errorfb(L:lua_State!) -> Int {
        var level:Int
        var firstpart:Bool = true // still before eventual `...'
        var arg:[Int]! = [Int](repeating: 0, count: 1)
        let L1:lua_State! = getthread(L: L, arg: &arg) //out
        let ar:lua_Debug! = lua_Debug()
        if (LuaAPI.lua_isnumber(L: L, idx: arg[0] + 2) != 0) {
            level = Int(LuaAPI.lua_tointeger(L: L, idx: arg[0] + 2))
            Lua.lua_pop(L: L, n: 1)
        }
        else {
            level = (L === L1) ? 1 : 0; // level 0 may be this own function
        }
        if (LuaAPI.lua_gettop(L: L) == arg[0]) {
            Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: ""))
        }
        else if (LuaAPI.lua_isstring(L: L, idx: arg[0] + 1) == 0) {
            return 1; // message is not a string
        }
        else {
            Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: "\n"))
        }
        Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: "stack traceback:"));
        while (true) {
            let rr:Bool = LuaDebug.lua_getstack(L: L1, level: level, ar: ar) != 0
            level += 1
            if (!rr) {
                break
            }
            if (level > LEVELS1 && firstpart) {
                // no more than `LEVELS2' more levels?
                if (LuaDebug.lua_getstack(L: L1, level: level + LEVELS2, ar: ar) == 0) {
                    level -= 1 // keep going
                }
                else {
                    Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: "\n\t...")); // too many levels
                    while (LuaDebug.lua_getstack(L: L1, level: level + LEVELS2, ar: ar) != 0) { // find last levels
                        level += 1
                    }
                }
                firstpart = false
                continue
            }
            Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: "\n\t"))
            _ = LuaDebug.lua_getinfo(L: L1, what: CharPtr.toCharPtr(str: "Snl"), ar: ar)
            _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: "%s:"), p: ar.short_src)
            if (ar.currentline > 0) {
                _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: "%d:"), p: ar.currentline)
            }
            if (CharPtr.isNotEqualChar(ptr: ar.namewhat, ch: "\0")) { // is there a name?
                _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: " in function " + LuaConf.getLUA_QS().toString()), p: ar.name)
            }
            else {
                if (CharPtr.isEqualChar(ptr: ar.what, ch: "m")) { // main?
                    _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: " in main chunk"));
                }
                else if (CharPtr.isEqualChar(ptr: ar.what, ch: "C") || CharPtr.isEqualChar(ptr: ar.what, ch: "t")) {
                    Lua.lua_pushliteral(L: L, s: CharPtr.toCharPtr(str: " ?")); // C function or tail call
                }
                else {
                    _ = LuaAPI.lua_pushfstring(L: L, fmt: CharPtr.toCharPtr(str: " in function <%s:%d>"), p: ar.short_src, ar.linedefined);
                }
            }
            LuaAPI.lua_concat(L: L, n: LuaAPI.lua_gettop(L: L) - arg[0]);
        }
        LuaAPI.lua_concat(L: L, n: LuaAPI.lua_gettop(L: L) - arg[0]);
        return 1
    }
    
    private static let dblib:[luaL_Reg] = [
        luaL_Reg(name: CharPtr.toCharPtr(str: "debug"),  func_: LuaDebugLib_delegate(name: "db_debug")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "getfenv"),  func_: LuaDebugLib_delegate(name: "db_getfenv")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "gethook"),  func_: LuaDebugLib_delegate(name: "db_gethook")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "getinfo"),  func_: LuaDebugLib_delegate(name: "db_getinfo")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "getlocal"),  func_: LuaDebugLib_delegate(name: "db_getlocal")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "getregistry"),  func_: LuaDebugLib_delegate(name: "db_getregistry")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "getmetatable"),  func_: LuaDebugLib_delegate(name: "db_getmetatable")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "getupvalue"),  func_: LuaDebugLib_delegate(name: "db_getupvalue")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "setfenv"),  func_: LuaDebugLib_delegate(name: "db_setfenv")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "sethook"),  func_: LuaDebugLib_delegate(name: "db_sethook")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "setlocal"),  func_: LuaDebugLib_delegate(name: "db_setlocal")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "setmetatable"),  func_: LuaDebugLib_delegate(name: "db_setmetatable")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "setupvalue"),  func_: LuaDebugLib_delegate(name: "db_setupvalue")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "traceback"),  func_: LuaDebugLib_delegate(name: "db_errorfb")),
        luaL_Reg(name: nil, func_: nil)
    ]
}


public class LuaDebugLib_delegate: lua_CFunction {
    private var name:String!
    
    public init(name:String!) {
        self.name = name
    }
    
    public func exec(L:lua_State!) -> Int {
        if ("db_debug" == name) {
            return LuaDebugLib.db_debug(L: L)
        }
        else if ("db_getfenv" == name) {
            return LuaDebugLib.db_getfenv(L: L)
        }
        else if ("db_gethook" == name) {
            return LuaDebugLib.db_gethook(L: L)
        }
        else if ("db_getinfo" == name) {
            return LuaDebugLib.db_getinfo(L: L)
        }
        else if ("db_getlocal" == name) {
            return LuaDebugLib.db_getlocal(L: L)
        }
        else if ("db_getregistry" == name) {
            return LuaDebugLib.db_getregistry(L: L)
        }
        else if ("db_getmetatable" == name) {
            return LuaDebugLib.db_getmetatable(L: L)
        }
        else if ("db_getupvalue" == name) {
            return LuaDebugLib.db_getupvalue(L: L)
        }
        else if ("db_setfenv" == name) {
            return LuaDebugLib.db_setfenv(L: L)
        }
        else if ("db_sethook" == name) {
            return LuaDebugLib.db_sethook(L: L)
        }
        else if ("db_setlocal" == name) {
            return LuaDebugLib.db_setlocal(L: L)
        }
        else if ("db_setmetatable" == name) {
            return LuaDebugLib.db_setmetatable(L: L)
        }
        else if ("db_setupvalue" == name) {
            return LuaDebugLib.db_setupvalue(L: L)
        }
        else if ("db_errorfb" == name) {
            return LuaDebugLib.db_errorfb(L: L)
        }
        else {
            return 0
        }
    }
}

extension LuaDebugLib {
    public static func luaopen_debug(L:lua_State!) -> Int {
        LuaAuxLib.luaL_register(L: L, libname: CharPtr.toCharPtr(str: LuaLib.LUA_DBLIBNAME), l: dblib)
        return 1
    }
}
