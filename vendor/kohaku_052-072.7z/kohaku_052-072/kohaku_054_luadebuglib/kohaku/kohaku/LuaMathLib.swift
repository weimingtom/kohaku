#if os(OSX) || os(iOS)
    import Darwin
#elseif os(Linux)
    import GLibc
#endif
import Foundation

//package kurumi;

//
// ** $Id: lmathlib.c,v 1.67.1.1 2007/12/27 13:02:25 roberto Exp $
// ** Standard mathematical library
// ** See Copyright Notice in lua.h
//

//using lua_Number = System.Double;

public class LuaMathLib {
    public static let PI:Double = 3.14159265358979323846
    public static let RADIANS_PER_DEGREE:Double = PI / 180.0
    
    fileprivate static func math_abs(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: abs(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_sin(L:lua_State) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: sin(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_sinh(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: sinh(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_cos(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: cos(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_cosh(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: cosh(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_tan(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: tan(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_tanh(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: tanh(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_asin(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: asin(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_acos(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: acos(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_atan(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: atan(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_atan2(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: atan2(LuaAuxLib.luaL_checknumber(L: L, narg: 1), LuaAuxLib.luaL_checknumber(L: L, narg: 2)))
        return 1
    }
    
    fileprivate static func math_ceil(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: ceil(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_floor(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: floor(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_fmod(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: CLib.fmod(a: LuaAuxLib.luaL_checknumber(L: L, narg: 1), b: LuaAuxLib.luaL_checknumber(L: L, narg: 2)))
        return 1
    }
    
    fileprivate static func math_modf(L:lua_State!) -> Int {
        var ip:[Double] = [Double](repeating: 0, count:1)
        let fp:Double = CLib.modf(a: LuaAuxLib.luaL_checknumber(L: L, narg: 1), b: ip); //out
        LuaAPI.lua_pushnumber(L: L, n: ip[0])
        LuaAPI.lua_pushnumber(L: L, n: fp)
        return 2
    }
    
    fileprivate static func math_sqrt(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: sqrt(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_pow(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: pow(LuaAuxLib.luaL_checknumber(L: L, narg: 1), LuaAuxLib.luaL_checknumber(L: L, narg: 2)))
        return 1
    }
    
    fileprivate static func math_log(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: log(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_log10(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: log10(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_exp(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: exp(LuaAuxLib.luaL_checknumber(L: L, narg: 1)))
        return 1
    }
    
    fileprivate static func math_deg(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: LuaAuxLib.luaL_checknumber(L: L, narg: 1) / RADIANS_PER_DEGREE)
        return 1
    }
    
    fileprivate static func math_rad(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: LuaAuxLib.luaL_checknumber(L: L, narg: 1) * RADIANS_PER_DEGREE)
        return 1
    }

    fileprivate static func math_frexp(L:lua_State!) -> Int {
        var e:[Int] = [Int](repeating: 0, count: 1)
        LuaAPI.lua_pushnumber(L: L, n: CLib.frexp(x: LuaAuxLib.luaL_checknumber(L: L, narg: 1), expptr: e)) //out
        LuaAPI.lua_pushinteger(L: L, n: e[0])
        return 2
    }
    
    fileprivate static func math_ldexp(L:lua_State!) -> Int {
        LuaAPI.lua_pushnumber(L: L, n: CLib.ldexp(x: LuaAuxLib.luaL_checknumber(L: L, narg: 1), expptr: LuaAuxLib.luaL_checkint(L: L, n: 2)))
        return 1
    }
    
    fileprivate static func math_min(L:lua_State!) -> Int {
        let n:Int = LuaAPI.lua_gettop(L: L) // number of arguments
        var dmin:Double = LuaAuxLib.luaL_checknumber(L: L, narg: 1) //lua_Number
        for i:Int in 2...n {
            let d:Double = LuaAuxLib.luaL_checknumber(L: L, narg: i) //lua_Number
            if (d < dmin) {
                dmin = d
            }
        }
        LuaAPI.lua_pushnumber(L: L, n: dmin)
        return 1
    }
    
    
    fileprivate static func math_max(L:lua_State!) -> Int {
        let n:Int = LuaAPI.lua_gettop(L: L) // number of arguments
        var dmax:Double = LuaAuxLib.luaL_checknumber(L: L, narg: 1) //lua_Number
        for i:Int in 2...n {
            let d:Double = LuaAuxLib.luaL_checknumber(L: L, narg: i) //lua_Number
            if (d > dmax) {
                dmax = d
            }
        }
        LuaAPI.lua_pushnumber(L: L, n: dmax);
        return 1
    }
    
//    private static java.util.Random rng = new java.util.Random();
    
    fileprivate static func math_random(L:lua_State!) -> Int {
        //             the `%' avoids the (rare) case of r==1, and is needed also because on
        //             some systems (SunOS!) `rand()' may return a value larger than RAND_MAX
        //lua_Number r = (lua_Number)(rng.Next()%RAND_MAX) / (lua_Number)RAND_MAX;
        let r:Double = drand48() //lua_Number - lua_Number
        switch (LuaAPI.lua_gettop(L: L)) {
            // check number of arguments
            case 0:
                // no arguments
                LuaAPI.lua_pushnumber(L: L, n: r) // Number between 0 and 1
                break
            
            case 1:
                // only upper limit
                let u:Int = LuaAuxLib.luaL_checkint(L: L, n: 1)
                LuaAuxLib.luaL_argcheck(L: L, cond: 1 <= u, numarg: 1, extramsg: "interval is empty")
                LuaAPI.lua_pushnumber(L: L, n: floor(r * Double(u)) + 1) // int between 1 and `u'
                break
            
            case 2:
                // lower and upper limits
                let l:Int = LuaAuxLib.luaL_checkint(L: L, n: 1)
                let u:Int = LuaAuxLib.luaL_checkint(L: L, n: 2)
                LuaAuxLib.luaL_argcheck(L: L, cond: l <= u, numarg: 2, extramsg: "interval is empty")
                LuaAPI.lua_pushnumber(L: L, n: floor(r * Double(u - l + 1)) + Double(l)) // int between `l' and `u'
                break
            
            default:
                return LuaAuxLib.luaL_error(L: L, fmt: CharPtr.toCharPtr(str: "wrong number of arguments"))
        }
        return 1
    }
    
    
    fileprivate static func math_randomseed(L:lua_State!) -> Int {
        //srand(luaL_checkint(L, 1));
        srand48(LuaAuxLib.luaL_checkint(L: L, n: 1))
        return 0
    }
    
    private static let mathlib:[luaL_Reg]! = [
        luaL_Reg(name: CharPtr.toCharPtr(str: "abs"),  func_: LuaMathLib_delegate(name: "math_abs")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "acos"),  func_: LuaMathLib_delegate(name: "math_acos")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "asin"),  func_: LuaMathLib_delegate(name: "math_asin")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "atan2"),  func_: LuaMathLib_delegate(name: "math_atan2")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "atan"),  func_: LuaMathLib_delegate(name: "math_atan")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "ceil"),  func_: LuaMathLib_delegate(name: "math_ceil")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "cosh"),  func_: LuaMathLib_delegate(name: "math_cosh")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "cos"),  func_: LuaMathLib_delegate(name: "math_cos")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "deg"),  func_: LuaMathLib_delegate(name: "math_deg")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "exp"),  func_: LuaMathLib_delegate(name: "math_exp")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "floor"),  func_: LuaMathLib_delegate(name: "math_floor")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "fmod"),  func_: LuaMathLib_delegate(name: "math_fmod")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "frexp"),  func_: LuaMathLib_delegate(name: "math_frexp")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "ldexp"),  func_: LuaMathLib_delegate(name: "math_ldexp")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "log10"),  func_: LuaMathLib_delegate(name: "math_log10")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "log"),  func_: LuaMathLib_delegate(name: "math_log")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "max"),  func_: LuaMathLib_delegate(name: "math_max")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "min"),  func_: LuaMathLib_delegate(name: "math_min")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "modf"),  func_: LuaMathLib_delegate(name: "math_modf")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "pow"),  func_: LuaMathLib_delegate(name: "math_pow")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "rad"),  func_: LuaMathLib_delegate(name: "math_rad")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "random"),  func_: LuaMathLib_delegate(name: "math_random")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "randomseed"),  func_: LuaMathLib_delegate(name: "math_randomseed")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "sinh"),  func_: LuaMathLib_delegate(name: "math_sinh")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "sin"),  func_: LuaMathLib_delegate(name: "math_sin")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "sqrt"),  func_: LuaMathLib_delegate(name: "math_sqrt")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "tanh"),  func_: LuaMathLib_delegate(name: "math_tanh")),
        luaL_Reg(name: CharPtr.toCharPtr(str: "tan"),  func_: LuaMathLib_delegate(name: "math_tan")),
        luaL_Reg(name: nil, func_: nil)
    ]
}

public class LuaMathLib_delegate: lua_CFunction {
    private var name:String!
    
    public init(name:String!) {
        self.name = name
    }
    
    public func exec(L:lua_State!) -> Int {
        if ("math_abs" == name) {
            return LuaMathLib.math_abs(L: L)
        }
        else if ("math_acos" == name) {
            return LuaMathLib.math_acos(L: L)
        }
        else if ("math_asin" == name) {
            return LuaMathLib.math_asin(L: L)
        }
        else if ("math_atan2" == name) {
            return LuaMathLib.math_atan2(L: L)
        }
        else if ("math_atan" == name) {
            return LuaMathLib.math_atan(L: L)
        }
        else if ("math_ceil" == name) {
            return LuaMathLib.math_ceil(L: L)
        }
        else if ("math_cosh" == name) {
            return LuaMathLib.math_cosh(L: L)
        }
        else if ("math_cos" == name) {
            return LuaMathLib.math_cos(L: L)
        }
        else if ("math_deg" == name) {
            return LuaMathLib.math_deg(L: L)
        }
        else if ("math_exp" == name) {
            return LuaMathLib.math_exp(L: L)
        }
        else if ("math_floor" == name) {
            return LuaMathLib.math_floor(L: L)
        }
        else if ("math_fmod" == name) {
            return LuaMathLib.math_fmod(L: L)
        }
        else if ("math_frexp" == name) {
            return LuaMathLib.math_frexp(L: L)
        }
        else if ("math_ldexp" == name) {
            return LuaMathLib.math_ldexp(L: L)
        }
        else if ("math_log10" == name) {
            return LuaMathLib.math_log10(L: L)
        }
        else if ("math_log" == name) {
            return LuaMathLib.math_log(L: L)
        }
        else if ("math_max" == name) {
            return LuaMathLib.math_max(L: L)
        }
        else if ("math_min" == name) {
            return LuaMathLib.math_min(L: L)
        }
        else if ("math_modf" == name) {
            return LuaMathLib.math_modf(L: L)
        }
        else if ("math_pow" == name) {
            return LuaMathLib.math_pow(L: L)
        }
        else if ("math_rad" == name) {
            return LuaMathLib.math_rad(L: L)
        }
        else if ("math_random" == name) {
            return LuaMathLib.math_random(L: L)
        }
        else if ("math_randomseed" == name) {
            return LuaMathLib.math_randomseed(L: L)
        }
        else if ("math_sinh" == name) {
            return LuaMathLib.math_sinh(L: L)
        }
        else if ("math_sin" == name) {
            return LuaMathLib.math_sin(L: L)
        }
        else if ("math_sqrt" == name) {
            return LuaMathLib.math_sqrt(L: L)
        }
        else if ("math_tanh" == name) {
            return LuaMathLib.math_tanh(L: L)
        }
        else if ("math_tan" == name) {
            return LuaMathLib.math_tan(L: L)
        }
        else {
            return 0
        }
    }
}

extension LuaMathLib {
    //
    //         ** Open math library
    //
    public static func luaopen_math(L:lua_State!) -> Int {
        LuaAuxLib.luaL_register(L: L, libname: CharPtr.toCharPtr(str: LuaLib.LUA_MATHLIBNAME), l: mathlib)
        LuaAPI.lua_pushnumber(L: L, n: PI)
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "pi"))
        LuaAPI.lua_pushnumber(L: L, n: CLib.HUGE_VAL)
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "huge"))
        ///#if LUA_COMPAT_MOD
        LuaAPI.lua_getfield(L: L, idx: -1, k: CharPtr.toCharPtr(str: "fmod"))
        LuaAPI.lua_setfield(L: L, idx: -2, k: CharPtr.toCharPtr(str: "mod"))
        ///#endif
        return 1
    }
}
