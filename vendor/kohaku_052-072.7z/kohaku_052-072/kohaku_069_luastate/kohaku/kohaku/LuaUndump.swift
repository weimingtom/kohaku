//package kurumi;

//
// ** $Id: lundump.c,v 2.7.1.4 2008/04/04 19:51:41 roberto Exp $
// ** load precompiled Lua chunks
// ** See Copyright Notice in lua.h
//

//using TValue = Lua.TValue;
//using lua_Number = System.Double;
//using lu_byte = System.Byte;
//using StkId = TValue;
//using Instruction = System.UInt32;

public class LuaUndump {
    // for header of binary files -- this is Lua 5.1
    public static let LUAC_VERSION:Int = 0x51
    
    // for header of binary files -- this is the official format
    public static let LUAC_FORMAT:Int = 0
    
    // size of header of binary files
    public static let LUAC_HEADERSIZE:Int = 12
}

public class LoadState {
    public var L:lua_State!
    public var Z:ZIO!
    public var b:Mbuffer!
    public var name:CharPtr!
}

extension LuaUndump {
    ///#ifdef LUAC_TRUST_BINARIES
    ///#define IF(c,s)
    ///#define error(S,s)
    ///#else
    ///#define IF(c,s)        if (c) error(S,s)
    
    public static func IF(c:Int, s:String!) {
    
    }
    
    public static func IF(c:Bool, s:String!) {
    
    }
    
    private static func error(S:LoadState!, why:CharPtr!) {
        _ = LuaObject.luaO_pushfstring(L: S.L, fmt: CharPtr.toCharPtr(str: "%s: %s in precompiled chunk"), args: S.name, why)
        LuaDo.luaD_throw(L: S.L, errcode: Lua.LUA_ERRSYNTAX)
    }
    ///#endif
    
    public static func LoadMem(S:LoadState!, t:ClassType!) -> Any! {
        let size:Int = t.GetMarshalSizeOf()
        let str:CharPtr! = CharPtr.toCharPtr(chars: [Character](repeating: "\0", count: size))
        LoadBlock(S: S, b: str, size: size)
        var bytes:[UInt8]! = [UInt8](repeating: 0, count: str.chars.count)
        for i:Int in 0 ..< str.chars.count {
            bytes[i] = ClassType.charToByte(ch: str.chars[i])
        }
        let b:Any! = t.bytesToObj(bytes: bytes)
        return b
    }
    
    public static func LoadMem(S:LoadState!, t:ClassType!, n:Int) -> Any! {
        //ArrayList array = new ArrayList();
        var array:[Any?]! = [Any?](repeating: nil, count: n)
        for i:Int in 0 ..< n {
            array[i] = LoadMem(S: S, t: t)
        }
        return t.ToArray(arr: array)
    }
    
    public static func LoadByte(S:LoadState!) -> UInt8 { //lu_byte
        return UInt8(LoadChar(S: S)) //lu_byte
    }
    
    public static func LoadVar(S:LoadState!, t:ClassType!) -> Any! {
        return LoadMem(S: S, t: t)
    }
    
    public static func LoadVector(S:LoadState!, t:ClassType!, n:Int) -> Any! {
        return LoadMem(S: S, t: t, n: n)
    }
    
    private static func LoadBlock(S:LoadState!, b:CharPtr!, size:Int) {
        let r:Int = LuaZIO.luaZ_read(z: S.Z, b: b, n: size) //(uint) - uint
        IF(c: r != 0, s: "unexpected end")
    }
    
    private static func LoadChar(S:LoadState!) -> Int {
        return Int(ClassType.charToByte(ch: LoadVar(S: S, t: ClassType(type: ClassType.TYPE_CHAR)) as! Character))
    }
    
    private static func LoadInt(S:LoadState!) -> Int {
        let x:Int = LoadVar(S: S, t: ClassType(type: ClassType.TYPE_INT)) as! Int
        IF(c: x < 0, s: "bad integer")
        return x
    }
    
    private static func LoadNumber(S:LoadState!) -> Double { //lua_Number
        return LoadVar(S: S, t: ClassType(type: ClassType.TYPE_DOUBLE)) as! Double //lua_Number - lua_Number
    }
    
    private static func LoadString(S:LoadState!) -> TString! {
        //typeof(int/*uint*/)
        let size:Int = LoadVar(S: S, t: ClassType(type: ClassType.TYPE_INT)) as! Int //uint - uint
        if (size == 0) {
            return nil
        }
        else {
            let s:CharPtr! = LuaZIO.luaZ_openspace(L: S.L, buff: S.b, n: size)
            LoadBlock(S: S, b: s, size: Int(size))
            return LuaString.luaS_newlstr(L: S.L, str: s, l: size - 1) // remove trailing '\0'
        }
    }
    
    private static func LoadCode(S:LoadState!, f:Proto!) {
        let n:Int = LoadInt(S: S)
        //UInt32
        //Instruction
        f.code = LuaMem.luaM_newvector_long(L: S.L, n: n, t: ClassType(type: ClassType.TYPE_LONG))
        f.sizecode = n
        f.code = LoadVector(S: S, t: ClassType(type: ClassType.TYPE_LONG), n: n) as! [Int64] //Instruction[] - UInt32[]
    }

    
    private static func LoadConstants(S:LoadState!, f:Proto!) {
        var n:Int
        n = LoadInt(S: S)
        f.k = LuaMem.luaM_newvector_TValue(L: S.L, n: n, t: ClassType(type: ClassType.TYPE_TVALUE))
        f.sizek = n;
        for i:Int in 0 ..< n {
            LuaObject.setnilvalue(obj: f.k[i])
        }
        for i:Int in 0 ..< n {
            let o:TValue! = f.k[i]
            let t:Int = LoadChar(S: S)
            switch (t) {
            case Lua.LUA_TNIL:
                LuaObject.setnilvalue(obj: o)
                break;
            
            case Lua.LUA_TBOOLEAN:
                LuaObject.setbvalue(obj: o, x: LoadChar(S: S))
                break;
            
            case Lua.LUA_TNUMBER:
                LuaObject.setnvalue(obj: o, x: LoadNumber(S: S))
                break;
            
            case Lua.LUA_TSTRING:
                LuaObject.setsvalue2n(L: S.L, obj: o, x: LoadString(S: S))
                break;
            
            default:
                error(S: S, why: CharPtr.toCharPtr(str: "bad constant"))
                break
            }
        }
        n = LoadInt(S: S)
        f.p = LuaMem.luaM_newvector_Proto(L: S.L, n: n, t: ClassType(type: ClassType.TYPE_PROTO))
        f.sizep = n;
        for i:Int in 0 ..< n {
            f.p[i] = nil
        }
        for i:Int in 0 ..< n {
            f.p[i] = LoadFunction(S: S, p: f.source)
        }
    }
    
    
    private static func LoadDebug(S:LoadState!, f:Proto!) {
        var n:Int
        n = LoadInt(S: S)
        f.lineinfo = LuaMem.luaM_newvector_int(L: S.L, n: n, t: ClassType(type: ClassType.TYPE_INT))
        f.sizelineinfo = n;
        f.lineinfo = LoadVector(S: S, t: ClassType(type: ClassType.TYPE_INT), n: n) as! [Int] //typeof(int)
        n = LoadInt(S: S)
        f.locvars = LuaMem.luaM_newvector_LocVar(L: S.L, n: n, t: ClassType(type: ClassType.TYPE_LOCVAR))
        f.sizelocvars = n
        for i:Int in 0 ..< n {
            f.locvars[i].varname = nil
        }
        for i:Int in 0 ..< n {
            f.locvars[i].varname = LoadString(S: S)
            f.locvars[i].startpc = LoadInt(S: S)
            f.locvars[i].endpc = LoadInt(S: S)
        }
        n = LoadInt(S: S)
        f.upvalues = LuaMem.luaM_newvector_TString(L: S.L, n: n, t: ClassType(type: ClassType.TYPE_TSTRING))
        f.sizeupvalues = n;
        for i:Int in 0 ..< n {
            f.upvalues[i] = nil
        }
        for i:Int in 0 ..< n {
            f.upvalues[i] = LoadString(S: S)
        }
    }
    
    private static func LoadFunction(S:LoadState!, p:TString!) -> Proto! {
        var f:Proto!
        S.L.nCcalls += 1
        if (S.L.nCcalls > LuaConf.LUAI_MAXCCALLS) {
            error(S: S, why: CharPtr.toCharPtr(str: "code too deep"))
        }
        f = LuaFunc.luaF_newproto(L: S.L)
        LuaObject.setptvalue2s(L: S.L, obj: S.L.top, x: f)
        LuaDo.incr_top(L: S.L)
        f.source = LoadString(S: S)
        if (f.source == nil) {
            f.source = p
        }
        f.linedefined = LoadInt(S: S)
        f.lastlinedefined = LoadInt(S: S)
        f.nups = Int8(LoadByte(S: S))
        f.numparams = Int8(LoadByte(S: S))
        f.is_vararg = Int8(LoadByte(S: S))
        f.maxstacksize = Int8(LoadByte(S: S))
        LoadCode(S: S, f: f)
        LoadConstants(S: S, f: f)
        LoadDebug(S: S, f: f)
        IF(c: LuaDebug.luaG_checkcode(pt: f) == 0 ? 1 : 0, s: "bad code")
        var top:[TValue?]! = [TValue?](repeating: nil, count: 1)
        top[0] = S.L.top
        //StkId
        _ = TValue.dec(value: top) //ref
        S.L.top = top[0]
        S.L.nCcalls -= 1
        return f
    }
    
    private static func LoadHeader(S:LoadState!) {
        let h:CharPtr! = CharPtr.toCharPtr(chars: [Character](repeating: "\0", count: LUAC_HEADERSIZE))
        let s:CharPtr! = CharPtr.toCharPtr(chars: [Character](repeating: "\0", count: LUAC_HEADERSIZE))
        luaU_header(h: h)
        LoadBlock(S: S, b: s, size: LUAC_HEADERSIZE)
        IF(c: CLib.memcmp(ptr1: h, ptr2: s, size: LUAC_HEADERSIZE) != 0, s: "bad header")
    }
    
    //
    //         ** load precompiled chunk
    //
    public static func luaU_undump(L:lua_State!, Z:ZIO!, buff:Mbuffer!, name:CharPtr!) -> Proto! {
        let S:LoadState! = LoadState()
        if (name.get(offset: 0) == "@" || name.get(offset: 0) == "=") {
            S.name = CharPtr.plus(ptr: name, offset: 1)
        }
        else if (name.get(offset: 0) == ClassType.charAt(str: Lua.LUA_SIGNATURE, idx: 0)) {
            S.name = CharPtr.toCharPtr(str: "binary string")
        }
        else {
            S.name = name;
        }
        S.L = L
        S.Z = Z
        S.b = buff
        LoadHeader(S: S)
        return LoadFunction(S: S, p: LuaString.luaS_newliteral(L: L, s: CharPtr.toCharPtr(str: "=?")))
    }
    
    //
    //         * make header
    //
    public static func luaU_header(h:CharPtr!) {
        var h:CharPtr! = CharPtr(ptr: h)
        let x:Int = 1
        CLib.memcpy(ptr1: h, ptr2: CharPtr.toCharPtr(str: Lua.LUA_SIGNATURE), size: Lua.LUA_SIGNATURE.utf8.count)
        h = h.add(ofs: Lua.LUA_SIGNATURE.utf8.count)
        h.set(offset: 0, val: ClassType.intToChar(ch: LUAC_VERSION))
        h.inc()
        h.set(offset: 0, val: ClassType.intToChar(ch: LUAC_FORMAT))
        h.inc()
        //*h++=(char)*(char*)&x;                /* endianness */
        h.set(offset: 0, val: ClassType.intToChar(ch: x)) // endianness
        h.inc()
        h.set(offset: 0, val: ClassType.intToChar(ch: ClassType.SizeOfInt()))
        h.inc()
        //FIXME:
        h.set(offset: 0, val: ClassType.intToChar(ch: ClassType.SizeOfLong()))
        //sizeof(long/*uint*/)
        h.inc()
        h.set(offset: 0, val: ClassType.intToChar(ch: ClassType.SizeOfLong()))
        //sizeof(long/*UInt32*//*Instruction*/));
        h.inc()
        h.set(offset: 0, val: ClassType.intToChar(ch: ClassType.SizeOfDouble()))
        //sizeof(Double/*lua_Number*/)
        h.inc()
        //(h++)[0] = ((lua_Number)0.5 == 0) ? 0 : 1;        /* is lua_Number integral? */
        h.set(offset: 0, val: "\0") // always 0 on this build
    }
}
