//package kurumi;

//
// ** $Id: lvm.c,v 2.63.1.3 2007/12/28 15:32:23 roberto Exp $
// ** Lua virtual machine
// ** See Copyright Notice in lua.h
//

//using TValue = Lua.TValue;
//using StkId = TValue;
//using lua_Number = System.Double;
//using lu_byte = System.Byte;
//using ptrdiff_t = System.Int32;
//using Instruction = System.UInt32;

public class LuaVM {
    public static func tostring(L:lua_State!, o:TValue!) -> Int { //StkId
        return ((LuaObject.ttype(o: o) == Lua.LUA_TSTRING) || (luaV_tostring(L: L, obj: o) != 0)) ? 1 : 0
    }
    
    public static func tonumber(o:inout [TValue?]!, n:TValue!) -> Int { //StkId - ref
        if (LuaObject.ttype(o: o[0]) == Lua.LUA_TNUMBER) {
            return 1
        }
        o[0] = luaV_tonumber(obj: o[0], n: n)
        return o[0] != nil ? 1 : 0
    }
    
    public static func equalobj(L:lua_State!, o1:TValue!, o2:TValue!) -> Int {
        return ((LuaObject.ttype(o: o1) == LuaObject.ttype(o: o2)) && (luaV_equalval(L: L, t1: o1, t2: o2) != 0)) ? 1 : 0
    }
    
    // limit for table tag-method chains (to avoid loops)
    public static let MAXTAGLOOP:Int = 100
    
    public static func luaV_tonumber(obj:TValue!, n:TValue!) -> TValue! {
        var num:[Double] = [Double](repeating: 0, count: 1) //lua_Number
        if (LuaObject.ttisnumber(o: obj)) {
            return obj
        }
        if (LuaObject.ttisstring(o: obj) && (LuaObject.luaO_str2d(s: LuaObject.svalue(o: obj), result: num) != 0)) { //out
            LuaObject.setnvalue(obj: n, x: num[0])
            return n
        }
        else {
            return nil
        }
    }
    
    
    public static func luaV_tostring(L:lua_State!, obj:TValue!) -> Int { //StkId
        if (!LuaObject.ttisnumber(o: obj)) {
            return 0
        }
        else {
            let n:Double = LuaObject.nvalue(o: obj) //lua_Number
            let s:CharPtr! = LuaConf.lua_number2str(n: n)
            LuaObject.setsvalue2s(L: L, obj: obj, x: LuaString.luaS_new(L: L, s: s))
            return 1
        }
    }
    
    
    private static func traceexec(L:lua_State!, pc:InstructionPtr!) {
        let mask:Int8 = L.hookmask; //lu_byte
        let oldpc:InstructionPtr! = InstructionPtr.Assign(ptr: L.savedpc)
        L.savedpc = InstructionPtr.Assign(ptr: pc)
        if (((Int(mask) & Lua.LUA_MASKCOUNT) != 0) && (L.hookcount == 0)) {
            LuaDebug.resethookcount(L: L);
            LuaDo.luaD_callhook(L: L, event_: Lua.LUA_HOOKCOUNT, line: -1)
        }
        if ((Int(mask) & Lua.LUA_MASKLINE) != 0) {
            let p:Proto! = LuaState.ci_func(ci: L.ci).l.p
            let npc:Int = LuaDebug.pcRel(pc: pc, p: p)
            let newline:Int = LuaDebug.getline(f: p, pc: npc)
            //                 call linehook when enter a new function, when jump back (loop),
            //               or when enter a new line
            if (npc == 0 || InstructionPtr.lessEqual(p1: pc, p2: oldpc) || newline != LuaDebug.getline(f: p, pc: LuaDebug.pcRel(pc: oldpc, p: p))) {
                LuaDo.luaD_callhook(L: L, event_: Lua.LUA_HOOKLINE, line: newline)
            }
        }
    }
    
    private static func callTMres(L:lua_State!, res:TValue!, f:TValue!, p1:TValue!, p2:TValue!) { //StkId
        var res:TValue! = res
        let result:Int = LuaDo.savestack(L: L, p: res) //ptrdiff_t - Int32
        LuaObject.setobj2s(L: L, obj: L.top, x: f) // push function
        LuaObject.setobj2s(L: L, obj: TValue.plus(value: L.top, offset: 1), x: p1) // 1st argument
        LuaObject.setobj2s(L: L, obj: TValue.plus(value: L.top, offset: 2), x: p2) // 2nd argument
        LuaDo.luaD_checkstack(L: L, n: 3)
        L.top = TValue.plus(value: L.top, offset: 3)
        LuaDo.luaD_call(L: L, func_: TValue.minus(value: L.top, offset: 3), nResults: 1)
        res = LuaDo.restorestack(L: L, n: result)
        var top:[TValue?]! = [TValue?](repeating: nil, count: 1)
        top[0] = L.top;
        //StkId
        _ = TValue.dec(value: top) //ref
        L.top = top[0]
        LuaObject.setobjs2s(L: L, obj: res, x: L.top)
    }
    
    private static func callTM(L:lua_State!, f:TValue!, p1:TValue!, p2:TValue!, p3:TValue!) {
        LuaObject.setobj2s(L: L, obj: L.top, x: f) // push function
        LuaObject.setobj2s(L: L, obj: TValue.plus(value: L.top, offset: 1), x: p1) // 1st argument
        LuaObject.setobj2s(L: L, obj: TValue.plus(value: L.top, offset: 2), x: p2) // 2nd argument
        LuaObject.setobj2s(L: L, obj: TValue.plus(value: L.top, offset: 3), x: p3) // 3th argument
        LuaDo.luaD_checkstack(L: L, n: 4)
        L.top = TValue.plus(value: L.top, offset: 4)
        LuaDo.luaD_call(L: L, func_: TValue.minus(value: L.top, offset: 4), nResults: 0)
    }
    
    public static func luaV_gettable(L:lua_State!, t:TValue!, key:TValue!, val:TValue!) { //StkId
        var t:TValue! = t
        for _:Int in 0 ..< MAXTAGLOOP {
            var tm:TValue!
            if (LuaObject.ttistable(o: t)) {
                // `t' is a table?
                let h:Table! = LuaObject.hvalue(o: t)
                let res:TValue! = LuaTable.luaH_get(t: h, key: key) // do a primitive get
                if (!LuaObject.ttisnil(o: res)) { // result is no nil?
                    // or no TM?
                    LuaObject.setobj2s(L: L, obj: val, x: res)
                    return
                } else {
                    tm = LuaTM.fasttm(l: L, et: h.metatable, e: TMS.TM_INDEX)
                    if (tm == nil) {
                        // or no TM?
                        LuaObject.setobj2s(L: L, obj: val, x: res)
                        return
                    }
                }
                // else will try the tag method
            }
            else {
                tm = LuaTM.luaT_gettmbyobj(L: L, o: t, event_: TMS.TM_INDEX)
                if (LuaObject.ttisnil(o: tm)) {
                    LuaDebug.luaG_typeerror(L: L, o: t, op: CharPtr.toCharPtr(str: "index"))
                }
            }
            if (LuaObject.ttisfunction(o: tm)) {
                callTMres(L: L, res: val, f: tm, p1: t, p2: key)
                return
            }
            t = tm // else repeat with `tm'
        }
        LuaDebug.luaG_runerror(L: L, fmt: CharPtr.toCharPtr(str: "loop in gettable"))
    }
    
    public static func luaV_settable(L:lua_State!, t:TValue!, key:TValue!, val:TValue!) { //StkId
        var t:TValue! = t
        for _:Int in 0 ..< MAXTAGLOOP {
            var tm:TValue!
            if (LuaObject.ttistable(o: t)) {
                // `t' is a table?
                let h:Table! = LuaObject.hvalue(o: t)
                let oldval:TValue! = LuaTable.luaH_set(L: L, t: h, key: key) // do a primitive set
                if (!LuaObject.ttisnil(o: oldval)) { // result is no nil?
                    // or no TM?
                    LuaObject.setobj2t(L: L, obj: oldval, x: val)
                    LuaGC.luaC_barriert(L: L, t: h, v: val)
                    return
                } else {
                    tm = LuaTM.fasttm(l: L, et: h.metatable, e: TMS.TM_NEWINDEX)
                    if (tm == nil) {
                        // or no TM?
                        LuaObject.setobj2t(L: L, obj: oldval, x: val)
                        LuaGC.luaC_barriert(L: L, t: h, v: val)
                        return
                    }
                }
                // else will try the tag method
            }
            else {
                tm = LuaTM.luaT_gettmbyobj(L: L, o: t, event_: TMS.TM_NEWINDEX)
                if (LuaObject.ttisnil(o: tm)) {
                    LuaDebug.luaG_typeerror(L: L, o: t, op: CharPtr.toCharPtr(str: "index"))
                }
            }
            if (LuaObject.ttisfunction(o: tm)) {
                callTM(L: L, f: tm, p1: t, p2: key, p3: val)
                return
            }
            t = tm // else repeat with `tm'
        }
        LuaDebug.luaG_runerror(L: L, fmt: CharPtr.toCharPtr(str: "loop in settable"))
    }
    
    private static func call_binTM(L:lua_State!, p1:TValue!, p2:TValue!, res:TValue!, event_:TMS) -> Int { //StkId
        var tm:TValue! = LuaTM.luaT_gettmbyobj(L: L, o: p1, event_: event_) // try first operand
        if (LuaObject.ttisnil(o: tm)) {
            tm = LuaTM.luaT_gettmbyobj(L: L, o: p2, event_: event_) // try second operand
        }
        if (LuaObject.ttisnil(o: tm)) {
            return 0
        }
        callTMres(L: L, res: res, f: tm, p1: p1, p2: p2)
        return 1
    }
    
    private static func get_compTM(L:lua_State!, mt1:Table!, mt2:Table!, event_:TMS) -> TValue! {
        let tm1:TValue! = LuaTM.fasttm(l: L, et: mt1, e: event_)
        var tm2:TValue!
        if (tm1 == nil) {
            return nil // no metamethod
        }
        if (mt1 === mt2) {
            return tm1 // same metatables => same metamethods
        }
        tm2 = LuaTM.fasttm(l: L, et: mt2, e: event_)
        if (tm2 == nil) {
            return nil // no metamethod
        }
        if (LuaObject.luaO_rawequalObj(t1: tm1, t2: tm2) != 0) { // same metamethods?
            return tm1
        }
        return nil
    }
    
    private static func call_orderTM(L:lua_State!, p1:TValue!, p2:TValue!, event_:TMS) -> Int {
        let tm1:TValue! = LuaTM.luaT_gettmbyobj(L: L, o: p1, event_: event_)
        var tm2:TValue!
        if (LuaObject.ttisnil(o: tm1)) {
            return -1; // no metamethod?
        }
        tm2 = LuaTM.luaT_gettmbyobj(L: L, o: p2, event_: event_);
        if (LuaObject.luaO_rawequalObj(t1: tm1, t2: tm2) == 0) { // different metamethods?
            return -1
        }
        callTMres(L: L, res: L.top, f: tm1, p1: p1, p2: p2)
        return LuaObject.l_isfalse(o: L.top) == 0 ? 1 : 0
    }
    
    private static func l_strcmp(ls:TString!, rs:TString!) -> Int {
        var l:CharPtr! = LuaObject.getstr(ts: ls)
        var ll:Int = ls.getTsv().len //uint
        var r:CharPtr! = LuaObject.getstr(ts: rs)
        var lr:Int = rs.getTsv().len //uint
        while true {
            //int temp = strcoll(l, r);
            let temp:Int = ClassType.compareTo(str1: l.toString(), str2: r.toString())
            if (temp != 0) {
                return temp
            }
            else {
                // strings are equal up to a `\0'
                var len:Int = l.toString().count // index of first `\0' in both strings  - (uint) - uint
                if (len == lr) { // r is finished?
                    return (len == ll) ? 0 : 1;
                }
                else if (len == ll) { // l is finished?
                    return -1 // l is smaller than r (because r is not finished)
                }
                // both strings longer than `len'; go on comparing (after the `\0')
                len += 1
                l = CharPtr.plus(ptr: l, offset: len)
                ll -= len
                r = CharPtr.plus(ptr: r, offset: len)
                lr -= len
            }
        }
    }
    
    
    public static func luaV_lessthan(L:lua_State!, l:TValue!, r:TValue!) -> Int {
        var res:Int
        if (LuaObject.ttype(o: l) != LuaObject.ttype(o: r)) {
            return LuaDebug.luaG_ordererror(L: L, p1: l, p2: r)
        }
        else if (LuaObject.ttisnumber(o: l)) {
            return LuaConf.luai_numlt(a: LuaObject.nvalue(o: l), b: LuaObject.nvalue(o: r)) ? 1 : 0
        }
        else if (LuaObject.ttisstring(o: l)) {
            return (l_strcmp(ls: LuaObject.rawtsvalue(o: l), rs: LuaObject.rawtsvalue(o: r)) < 0) ? 1 : 0
        }
        else {
            res = call_orderTM(L: L, p1: l, p2: r, event_: TMS.TM_LT)
            if (res != -1) {
                return res
            }
        }
        return LuaDebug.luaG_ordererror(L: L, p1: l, p2: r)
    }
    
    private static func lessequal(L:lua_State!, l:TValue!, r:TValue!) -> Int {
        var res:Int
        if (LuaObject.ttype(o: l) != LuaObject.ttype(o: r)) {
            return LuaDebug.luaG_ordererror(L: L, p1: l, p2: r)
        }
        else if (LuaObject.ttisnumber(o: l)) {
            return LuaConf.luai_numle(a: LuaObject.nvalue(o: l), b: LuaObject.nvalue(o: r)) ? 1 : 0
        
        }
        else if (LuaObject.ttisstring(o: l)) {
            return (l_strcmp(ls: LuaObject.rawtsvalue(o: l), rs: LuaObject.rawtsvalue(o: r)) <= 0) ? 1 : 0
        }
        else { // first try `le'
            res = call_orderTM(L: L, p1: l, p2: r, event_: TMS.TM_LE)
            if (res != -1) {
                return res
            }
            else { // else try `lt'
                res = call_orderTM(L: L, p1: r, p2: l, event_: TMS.TM_LT)
                if (res != -1) {
                    return (res == 0) ? 1 : 0
                }
            }
        }
        return LuaDebug.luaG_ordererror(L: L, p1: l, p2: r)
    }
    
    private static var mybuff:CharPtr! = nil

    
    public static func luaV_equalval(L:lua_State!, t1:TValue!, t2:TValue!) -> Int {
        var tm:TValue! = nil
        LuaLimits.lua_assert(c: LuaObject.ttype(o: t1) == LuaObject.ttype(o: t2))
        switch (LuaObject.ttype(o: t1)) {
        case Lua.LUA_TNIL:
            return 1
        
        case Lua.LUA_TNUMBER:
            return LuaConf.luai_numeq(a: LuaObject.nvalue(o: t1), b: LuaObject.nvalue(o: t2)) ? 1 : 0
        
        case Lua.LUA_TBOOLEAN:
            return (LuaObject.bvalue(o: t1) == LuaObject.bvalue(o: t2)) ? 1 : 0 // true must be 1 !!
        
        case Lua.LUA_TLIGHTUSERDATA:
            return ((LuaObject.pvalue(o: t1) as AnyObject!) === (LuaObject.pvalue(o: t2) as AnyObject!)) ? 1 : 0
        
        case Lua.LUA_TUSERDATA:
            //FIXME: !!!!!!!!!!!!!!!!!remove as AnyObject!
            if ((LuaObject.uvalue(o: t1) as AnyObject!) === (LuaObject.uvalue(o: t2) as AnyObject!)) {
                return 1
            }
            tm = get_compTM(L: L, mt1: LuaObject.uvalue(o: t1).metatable, mt2: LuaObject.uvalue(o: t2).metatable, event_: TMS.TM_EQ)
            break // will try TM
        
        case Lua.LUA_TTABLE:
            if ((LuaObject.hvalue(o: t1) as AnyObject!) === (LuaObject.hvalue(o: t2) as AnyObject!)) {
                return 1
            }
            tm = get_compTM(L: L, mt1: LuaObject.hvalue(o: t1).metatable, mt2: LuaObject.hvalue(o: t2).metatable, event_: TMS.TM_EQ)
            break // will try TM
        
        default:
            return ((LuaObject.gcvalue(o: t1) as AnyObject!) === (LuaObject.gcvalue(o: t2) as AnyObject!)) ? 1 : 0
        }
        if (tm == nil) {
            return 0 // no TM?
        }
        callTMres(L: L, res: L.top, f: tm, p1: t1, p2: t2) // call TM
        return LuaObject.l_isfalse(o: L.top) == 0 ? 1 : 0
    }
    
    public static func luaV_concat(L:lua_State!, total:Int, last:Int) {
        var total:Int = total
        var last:Int = last
        repeat {
            let top:TValue! = TValue.plus(value: L.base_, offset: last + 1) //StkId
            var n:Int = 2 // number of elements handled in this pass (at least 2)
            if (!(LuaObject.ttisstring(o: TValue.minus(value: top, offset: 2)) || LuaObject.ttisnumber(o: TValue.minus(value: top, offset: 2))) || (tostring(L: L, o: TValue.minus(value: top, offset: 1)) == 0)) {
                if (call_binTM(L: L, p1: TValue.minus(value: top, offset: 2), p2: TValue.minus(value: top, offset: 1), res: TValue.minus(value: top, offset: 2), event_: TMS.TM_CONCAT) == 0) {
                    LuaDebug.luaG_concaterror(L: L, p1: TValue.minus(value: top, offset: 2), p2: TValue.minus(value: top, offset: 1));
                }
            }
            else if (LuaObject.tsvalue(o: TValue.minus(value: top, offset: 1)).len == 0) { // second op is empty?
                _ = tostring(L: L, o: TValue.minus(value: top, offset: 2)) // result is first op (as string)
            }
            else {
                // at least two string values; get as many as possible
                var tl:Int = LuaObject.tsvalue(o: TValue.minus(value: top, offset: 1)).len //uint
                var buffer:CharPtr!
                var i:Int
                // collect total length
                n = 1
                while (n < total && (tostring(L: L, o: TValue.minus(value: TValue.minus(value: top, offset: n), offset: 1)) != 0)) { //FIXME:
                    let l:Int = LuaObject.tsvalue(o: TValue.minus(value: TValue.minus(value: top, offset: n), offset: 1)).len; //uint
                    if (l >= LuaLimits.MAX_SIZET - tl) {
                        LuaDebug.luaG_runerror(L: L, fmt: CharPtr.toCharPtr(str: "string length overflow"))
                    }
                    tl += l
                    n += 1
                }
                buffer = LuaZIO.luaZ_openspace(L: L, buff: LuaState.G(L: L).buff, n: tl)
                if (CharPtr.isEqual(ptr1: mybuff, ptr2: nil)) {
                    mybuff = buffer
                }
                tl = 0
                i = n
                while (i > 0) {
                    // concat all strings
                    let l:Int = LuaObject.tsvalue(o: TValue.minus(value: top, offset: i)).len //uint
                    CLib.memcpy_char(dst: buffer.chars, offset: tl, src: LuaObject.svalue(o: TValue.minus(value: top, offset: i)).chars, length: Int(l)) //(int)
                    tl += l
                    i -= 1
                }
                LuaObject.setsvalue2s(L: L, obj: TValue.minus(value: top, offset: n), x: LuaString.luaS_newlstr(L: L, str: buffer, l: tl))
            }
            total -= n - 1 // got `n' strings to create 1 new
            last -= n - 1
        } while (total > 1) // repeat until only 1 result left
    }
    
    
    public static func Arith(L:lua_State!, ra:TValue!, rb:TValue!, rc:TValue!, op:TMS) { //StkId
        let tempb:TValue! = TValue()
        let tempc:TValue! = TValue()
        var b:TValue!, c:TValue!
        b = luaV_tonumber(obj: rb, n: tempb)
        if (b != nil) {
            c = luaV_tonumber(obj: rc, n: tempc)
            if (c != nil) {
                let nb:Double = LuaObject.nvalue(o: b)
                let nc:Double = LuaObject.nvalue(o: c) //lua_Number
                switch (op) {
                case TMS.TM_ADD:
                    LuaObject.setnvalue(obj: ra, x: LuaConf.luai_numadd(a: nb, b: nc))
                    break
                
                case TMS.TM_SUB:
                    LuaObject.setnvalue(obj: ra, x: LuaConf.luai_numsub(a: nb, b: nc))
                    break
                
                case TMS.TM_MUL:
                    LuaObject.setnvalue(obj: ra, x: LuaConf.luai_nummul(a: nb, b: nc))
                    break
                
                case TMS.TM_DIV:
                    LuaObject.setnvalue(obj: ra, x: LuaConf.luai_numdiv(a: nb, b: nc))
                    break
                
                case TMS.TM_MOD:
                    LuaObject.setnvalue(obj: ra, x: LuaConf.luai_nummod(a: nb, b: nc))
                    break
                
                case TMS.TM_POW:
                    LuaObject.setnvalue(obj: ra, x: LuaConf.luai_numpow(a: nb, b: nc))
                    break
                
                case TMS.TM_UNM:
                    LuaObject.setnvalue(obj: ra, x: LuaConf.luai_numunm(a: nb));
                    break
                
                default:
                    LuaLimits.lua_assert(c: false)
                    break
                }
            }
        }
        else if (call_binTM(L: L, p1: rb, p2: rc, res: ra, event_: op) == 0) {
            LuaDebug.luaG_aritherror(L: L, p1: rb, p2: rc)
        }
    }
    
    //
    //         ** some macros for common tasks in `luaV_execute'
    //
    public static func runtime_check(L:lua_State!, c:Bool) {
        ClassType.Assert(condition: c);
    }
    
    ///#define RA(i)    (base+GETARG_A(i))
    // to be used after possible stack reallocation
    ///#define RB(i)    check_exp(getBMode(GET_OPCODE(i)) == OpArgMask.OpArgR, base+GETARG_B(i))
    ///#define RC(i)    check_exp(getCMode(GET_OPCODE(i)) == OpArgMask.OpArgR, base+GETARG_C(i))
    ///#define RKB(i)    check_exp(getBMode(GET_OPCODE(i)) == OpArgMask.OpArgK, \
    //ISK(GETARG_B(i)) ? k+INDEXK(GETARG_B(i)) : base+GETARG_B(i))
    ///#define RKC(i)    check_exp(getCMode(GET_OPCODE(i)) == OpArgMask.OpArgK, \
    //    ISK(GETARG_C(i)) ? k+INDEXK(GETARG_C(i)) : base+GETARG_C(i))
    ///#define KBx(i)    check_exp(getBMode(GET_OPCODE(i)) == OpArgMask.OpArgK, k+GETARG_Bx(i))
    
    // todo: implement proper checks, as above
    public static func RA(L:lua_State!, base_:TValue!, i:Int64) -> TValue! { //Instruction - UInt32 - StkId
        return TValue.plus(value: base_, offset: LuaOpCodes.GETARG_A(i: i))
    }
    
    public static func RB(L:lua_State!, base_:TValue!, i:Int64) -> TValue! { //Instruction - UInt32 - StkId
        return TValue.plus(value: base_, offset: LuaOpCodes.GETARG_B(i: i))
    }
    
    public static func RC(L:lua_State!, base_:TValue!, i:Int64) -> TValue! { //Instruction - UInt32 - StkId
        return TValue.plus(value: base_, offset: LuaOpCodes.GETARG_C(i: i))
    }
    
    public static func RKB(L:lua_State!, base_:TValue!, i:Int64, k:[TValue]!) -> TValue! { //Instruction - UInt32 - StkId
        return LuaOpCodes.ISK(x: LuaOpCodes.GETARG_B(i: i)) != 0 ? k[LuaOpCodes.INDEXK(r: LuaOpCodes.GETARG_B(i: i))] : TValue.plus(value: base_, offset: LuaOpCodes.GETARG_B(i: i))
    }
    
    public static func RKC(L:lua_State!, base_:TValue!, i:Int64, k:[TValue]!) -> TValue! { //Instruction - UInt32 - StkId
        return LuaOpCodes.ISK(x: LuaOpCodes.GETARG_C(i: i)) != 0 ? k[LuaOpCodes.INDEXK(r: LuaOpCodes.GETARG_C(i: i))] : TValue.plus(value: base_, offset: LuaOpCodes.GETARG_C(i: i))
    }
    
    public static func KBx(L:lua_State!, i:Int64, k:[TValue]!) -> TValue! { //Instruction - UInt32
        return k[LuaOpCodes.GETARG_Bx(i: i)]
    }
    
    public static func dojump(L:lua_State!, pc:InstructionPtr!, i:Int) {
        pc.pc += i
        LuaLimits.luai_threadyield(L: L)
    }
    
    ///#define Protect(x)    { L.savedpc = pc; {x;}; base = L.base_; }
    
    public static func arith_op(L:lua_State!, op:op_delegate!, tm:TMS, base_:TValue!, i:Int64, k:[TValue]!, ra:TValue!, pc:InstructionPtr!) { //StkId - Instruction - UInt32 - StkId
        var base_:TValue! = base_
        let rb:TValue! = RKB(L: L, base_: base_, i: i, k: k)
        let rc:TValue! = RKC(L: L, base_: base_, i: i, k: k)
        if (LuaObject.ttisnumber(o: rb) && LuaObject.ttisnumber(o: rc)) {
            let nb:Double = LuaObject.nvalue(o: rb)
            let nc:Double = LuaObject.nvalue(o: rc) //lua_Number
            LuaObject.setnvalue(obj: ra, x: op.exec(a: nb, b: nc))
        }
        else {
            //Protect(
            L.savedpc = InstructionPtr.Assign(ptr: pc)
            Arith(L: L, ra: ra, rb: rb, rc: rc, op: tm);
            base_ = L.base_;
            //);
        }
    }
    
    private static func Dump(pc:Int, i:Int64) { //Instruction - UInt32
        let A:Int = LuaOpCodes.GETARG_A(i: i)
        let B:Int = LuaOpCodes.GETARG_B(i: i)
        let C:Int = LuaOpCodes.GETARG_C(i: i)
        let Bx:Int = LuaOpCodes.GETARG_Bx(i: i)
        var sBx:Int = LuaOpCodes.GETARG_sBx(i: i)
        if ((sBx & 0x100) != 0) {
            sBx = -(sBx & 0xff)
        }
        StreamProxy.Write(str: "" + String(pc) + " (" + String(i) + "): ") //FIXME:"{0,5} ({1,10}): "
        StreamProxy.Write(str: "" + LuaOpCodes.luaP_opnames[LuaOpCodes.GET_OPCODE(i: i).getValue()].toString() + "\t") //"{0,-10}\t"
        switch (LuaOpCodes.GET_OPCODE(i: i)) {
        case OpCode.OP_CLOSE:
            StreamProxy.Write(str: "" + String(A) + "")
            break
        
        case OpCode.OP_MOVE,
        OpCode.OP_LOADNIL,
        OpCode.OP_GETUPVAL,
        OpCode.OP_SETUPVAL,
        OpCode.OP_UNM,
        OpCode.OP_NOT,
        OpCode.OP_RETURN:
            StreamProxy.Write(str: "" + String(A) + ", " + String(B) + "")
            break
        
        case OpCode.OP_LOADBOOL,
        OpCode.OP_GETTABLE,
        OpCode.OP_SETTABLE,
        OpCode.OP_NEWTABLE,
        OpCode.OP_SELF,
        OpCode.OP_ADD,
        OpCode.OP_SUB,
        OpCode.OP_MUL,
        OpCode.OP_DIV,
        OpCode.OP_POW,
        OpCode.OP_CONCAT,
        OpCode.OP_EQ,
        OpCode.OP_LT,
        OpCode.OP_LE,
        OpCode.OP_TEST,
        OpCode.OP_CALL,
        OpCode.OP_TAILCALL:
            StreamProxy.Write(str: "" + String(A) + ", " + String(B) + ", " + String(C) + "")
            break
        
        case OpCode.OP_LOADK:
            StreamProxy.Write(str: "" + String(A) + ", " + String(Bx) + "")
            break
        
        case OpCode.OP_GETGLOBAL,
        OpCode.OP_SETGLOBAL,
        OpCode.OP_SETLIST,
        OpCode.OP_CLOSURE:
            StreamProxy.Write(str: "" + String(A) + ", " + String(Bx) + "")
            break
        
        case OpCode.OP_TFORLOOP:
            StreamProxy.Write(str: "" + String(A) + ", " + String(C) + "")
            break
        
        case OpCode.OP_JMP,
        OpCode.OP_FORLOOP,
        OpCode.OP_FORPREP:
            StreamProxy.Write(str: "" + String(A) + ", " + String(sBx) + "")
            break
            
        default:
            break
        }
        StreamProxy.WriteLine()
    }
    
    public static func luaV_execute(L:lua_State!, nexeccalls:Int) {
        var nexeccalls:Int = nexeccalls
        var cl:LClosure!
        var base_:TValue! //StkId
        var k:[TValue]!
        //const
        var pc:InstructionPtr!
        //reentry:  /* entry point */
        while (true) {
            var reentry:Bool = false
            
            LuaLimits.lua_assert(c: LuaState.isLua(ci: L.ci))
            pc = InstructionPtr.Assign(ptr: L.savedpc)
            cl = LuaObject.clvalue(o: L.ci.func_).l
            base_ = L.base_;
            k = cl.p.k;
            // main loop of interpreter
            while true {
                var pc_ref:[InstructionPtr?]! = [InstructionPtr?](repeating: nil, count: 1)
                pc_ref[0] = pc
                let ret:InstructionPtr! = InstructionPtr.inc(ptr: pc_ref) //ref
                pc = pc_ref[0]
                //const
                let i:Int64 = ret.get(index: 0) //Instruction - UInt32
                var ra:TValue! //StkId
                if (((Int(L.hookmask) & (Lua.LUA_MASKLINE | Lua.LUA_MASKCOUNT)) != 0)) {
                    L.hookcount -= 1
                    if ((L.hookcount == 0) || ((Int(L.hookmask) & Lua.LUA_MASKLINE) != 0)) {
                        traceexec(L: L, pc: pc)
                        if (L.status == Lua.LUA_YIELD) {
                            // did hook yield?
                            L.savedpc = InstructionPtr(codes: pc.codes, pc: pc.pc - 1)
                            return
                        }
                        base_ = L.base_
                    }
                }
                // warning!! several calls may realloc the stack and invalidate `ra'
                ra = RA(L: L, base_: base_, i: i);
                LuaLimits.lua_assert(c: base_ === L.base_ && L.base_ === L.ci.base_)
                LuaLimits.lua_assert(c: TValue.lessEqual(a: base_, b: L.top) && ((TValue.minus(value: L.top, array: L.stack)) <= L.stacksize))
                LuaLimits.lua_assert(c: L.top === L.ci.top || (LuaDebug.luaG_checkopenop(i: i) != 0))
                //Dump(pc.pc, i);
                
                var reentry2:Bool = false

                switch (LuaOpCodes.GET_OPCODE(i: i)) {
                case OpCode.OP_MOVE:
                    LuaObject.setobjs2s(L: L, obj: ra, x: RB(L: L, base_: base_, i: i))
                    continue;
                
                case OpCode.OP_LOADK:
                    LuaObject.setobj2s(L: L, obj: ra, x: KBx(L: L, i: i, k: k))
                    continue;
                
                case OpCode.OP_LOADBOOL:
                    LuaObject.setbvalue(obj: ra, x: LuaOpCodes.GETARG_B(i: i))
                    if (LuaOpCodes.GETARG_C(i: i) != 0) {
                        var pc_ref2:[InstructionPtr?] = [InstructionPtr?](repeating: nil, count: 1)
                        pc_ref2[0] = pc
                        _ = InstructionPtr.inc(ptr: pc_ref2) // skip next instruction (if C)  - ref
                        pc = pc_ref2[0]
                    }
                    continue
                    
                case OpCode.OP_LOADNIL:
                    var rb:TValue! = RB(L: L, base_: base_, i: i)
                    repeat {
                        var rb_ref:[TValue?]! = [TValue?](repeating: nil, count: 1)
                        rb_ref[0] = rb
                        let ret2:TValue! = TValue.dec(value: rb_ref) //ref - StkId
                        rb = rb_ref[0]
                        LuaObject.setnilvalue(obj: ret2)
                    } while (TValue.greaterEqual(a: rb, b: ra))
                    continue;
                
                case OpCode.OP_GETUPVAL:
                    let b:Int = LuaOpCodes.GETARG_B(i: i)
                    LuaObject.setobj2s(L: L, obj: ra, x: cl.upvals[b].v)
                    continue
                
                case OpCode.OP_GETGLOBAL:
                    let g:TValue! = TValue()
                    let rb:TValue! = KBx(L: L, i: i, k: k)
                    LuaObject.sethvalue(L: L, obj: g, x: cl.getEnv())
                    LuaLimits.lua_assert(c: LuaObject.ttisstring(o: rb));
                    //Protect(
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    luaV_gettable(L: L, t: g, key: rb, val: ra)
                    base_ = L.base_
                    //);
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    continue;
                    
                case OpCode.OP_GETTABLE:
                    //Protect(
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    luaV_gettable(L: L, t: RB(L: L, base_: base_, i: i), key: RKC(L: L, base_: base_, i: i, k: k), val: ra)
                    base_ = L.base_
                    //);
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    continue
                    
                case OpCode.OP_SETGLOBAL:
                    let g:TValue! = TValue()
                    LuaObject.sethvalue(L: L, obj: g, x: cl.getEnv())
                    LuaLimits.lua_assert(c: LuaObject.ttisstring(o: KBx(L: L, i: i, k: k)))
                    //Protect(
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    luaV_settable(L: L, t: g, key: KBx(L: L, i: i, k: k), val: ra)
                    base_ = L.base_
                    //);
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    continue
                    
                case OpCode.OP_SETUPVAL:
                    let uv:UpVal! = cl.upvals[LuaOpCodes.GETARG_B(i: i)]
                    LuaObject.setobj(L: L, obj1: uv.v, obj2: ra)
                    LuaGC.luaC_barrier(L: L, p: uv, v: ra)
                    continue
                    
                case OpCode.OP_SETTABLE:
                    //Protect(
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    luaV_settable(L: L, t: ra, key: RKB(L: L, base_: base_, i: i, k: k), val: RKC(L: L, base_: base_, i: i, k: k))
                    base_ = L.base_
                    //);
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    continue
                    
                case OpCode.OP_NEWTABLE:
                    let b:Int = LuaOpCodes.GETARG_B(i: i)
                    let c:Int = LuaOpCodes.GETARG_C(i: i)
                    LuaObject.sethvalue(L: L, obj: ra, x: LuaTable.luaH_new(L: L, narray: LuaObject.luaO_fb2int(x: b), nhash: LuaObject.luaO_fb2int(x: c)))
                    //Protect(
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    LuaGC.luaC_checkGC(L: L)
                    base_ = L.base_
                    //);
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    continue
                    
                case OpCode.OP_SELF:
                    //StkId
                    let rb:TValue! = RB(L: L, base_: base_, i: i)
                    LuaObject.setobjs2s(L: L, obj: TValue.plus(value: ra, offset: 1), x: rb)
                    //Protect(
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    luaV_gettable(L: L, t: rb, key: RKC(L: L, base_: base_, i: i, k: k), val: ra)
                    base_ = L.base_
                    //);
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    continue
                    
                case OpCode.OP_ADD:
                    arith_op(L: L, op: luai_numadd_delegate(), tm: TMS.TM_ADD, base_: base_, i: i, k: k, ra: ra, pc: pc)
                    continue
                    
                case OpCode.OP_SUB:
                    arith_op(L: L, op: luai_numsub_delegate(), tm: TMS.TM_SUB, base_: base_, i: i, k: k, ra: ra, pc: pc)
                    continue
                    
                case OpCode.OP_MUL:
                    arith_op(L: L, op: luai_nummul_delegate(), tm: TMS.TM_MUL, base_: base_, i: i, k: k, ra: ra, pc: pc)
                    continue
            
                case OpCode.OP_DIV:
                    arith_op(L: L, op: luai_numdiv_delegate(), tm: TMS.TM_DIV, base_: base_, i: i, k: k, ra: ra, pc: pc)
                    continue
                    
                case OpCode.OP_MOD:
                    arith_op(L: L, op: luai_nummod_delegate(), tm: TMS.TM_MOD, base_: base_, i: i, k: k, ra: ra, pc: pc)
                    continue
                    
                case OpCode.OP_POW:
                    arith_op(L: L, op: luai_numpow_delegate(), tm: TMS.TM_POW, base_: base_, i: i, k: k, ra: ra, pc: pc)
                    continue
                    
                case OpCode.OP_UNM:
                    let rb:TValue! = RB(L: L, base_: base_, i: i)
                    if (LuaObject.ttisnumber(o: rb)) {
                        let nb:Double = LuaObject.nvalue(o: rb) //lua_Number
                        LuaObject.setnvalue(obj: ra, x: LuaConf.luai_numunm(a: nb))
                    }
                    else {
                        //Protect(
                        L.savedpc = InstructionPtr.Assign(ptr: pc)
                        Arith(L: L, ra: ra, rb: rb, rc: rb, op: TMS.TM_UNM)
                        base_ = L.base_
                        //);
                        L.savedpc = InstructionPtr.Assign(ptr: pc)
                    }
                    continue
                    
                case OpCode.OP_NOT:
                    let res:Int = LuaObject.l_isfalse(o: RB(L: L, base_: base_, i: i)) == 0 ? 0 : 1 // next assignment may change this value
                    LuaObject.setbvalue(obj: ra, x: res)
                    continue
                    
                case OpCode.OP_LEN:
                    let rb:TValue! = RB(L: L, base_: base_, i: i)
                    switch (LuaObject.ttype(o: rb)) {
                    case Lua.LUA_TTABLE:
                        LuaObject.setnvalue(obj: ra, x: Double(LuaTable.luaH_getn(t: LuaObject.hvalue(o: rb)))) //lua_Number
                        break
                    
                    case Lua.LUA_TSTRING:
                        LuaObject.setnvalue(obj: ra, x: Double(LuaObject.tsvalue(o: rb).len)) //lua_Number
                        break
                    
                    default:
                        // try metamethod
                        //Protect(
                        L.savedpc = InstructionPtr.Assign(ptr: pc)
                        if (call_binTM(L: L, p1: rb, p2: LuaObject.luaO_nilobject, res: ra, event_: TMS.TM_LEN) == 0) {
                            LuaDebug.luaG_typeerror(L: L, o: rb, op: CharPtr.toCharPtr(str: "get length of"))
                        }
                        base_ = L.base_
                        //)
                        break
                    }
                    continue
                    
                case OpCode.OP_CONCAT:
                    let b:Int = LuaOpCodes.GETARG_B(i: i)
                    let c:Int = LuaOpCodes.GETARG_C(i: i)
                    //Protect(
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    luaV_concat(L: L, total: c - b + 1, last: c)
                    LuaGC.luaC_checkGC(L: L)
                    base_ = L.base_
                    //);
                    LuaObject.setobjs2s(L: L, obj: RA(L: L, base_: base_, i: i), x: TValue.plus(value: base_, offset: b))
                    continue
                    
                case OpCode.OP_JMP:
                    dojump(L: L, pc: pc, i: LuaOpCodes.GETARG_sBx(i: i))
                    continue
                    
                case OpCode.OP_EQ:
                    let rb:TValue! = RKB(L: L, base_: base_, i: i, k: k)
                    let rc:TValue! = RKC(L: L, base_: base_, i: i, k: k)
                    //Protect(
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    if (equalobj(L: L, o1: rb, o2: rc) == LuaOpCodes.GETARG_A(i: i)) {
                        dojump(L: L, pc: pc, i: LuaOpCodes.GETARG_sBx(i: pc.get(index: 0)))
                    }
                    base_ = L.base_
                    //);
                    var pc_ref2:[InstructionPtr?]! = [InstructionPtr?](repeating: nil, count: 1)
                    pc_ref2[0] = pc
                    _ = InstructionPtr.inc(ptr: pc_ref2) //ref
                    pc = pc_ref2[0]
                    continue
                    
                case OpCode.OP_LT:
                    //Protect(
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    if (luaV_lessthan(L: L, l: RKB(L: L, base_: base_, i: i, k: k), r: RKC(L: L, base_: base_, i: i, k: k)) == LuaOpCodes.GETARG_A(i: i)) {
                        dojump(L: L, pc: pc, i: LuaOpCodes.GETARG_sBx(i: pc.get(index: 0)))
                    }
                    base_ = L.base_
                    //);
                    var pc_ref3:[InstructionPtr?] = [InstructionPtr?](repeating: nil, count: 1)
                    pc_ref3[0] = pc
                    _ = InstructionPtr.inc(ptr: pc_ref3) //ref
                    pc = pc_ref3[0]
                    continue
                    
                case OpCode.OP_LE:
                    //Protect(
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    if (lessequal(L: L, l: RKB(L: L, base_: base_, i: i, k: k), r: RKC(L: L, base_: base_, i: i, k: k)) == LuaOpCodes.GETARG_A(i: i)) {
                        dojump(L: L, pc: pc, i: LuaOpCodes.GETARG_sBx(i: pc.get(index: 0)))
                    }
                    base_ = L.base_;
                    //);
                    var pc_ref4:[InstructionPtr?] = [InstructionPtr?](repeating: nil, count: 1)
                    pc_ref4[0] = pc
                    _ = InstructionPtr.inc(ptr: pc_ref4) //ref
                    pc = pc_ref4[0]
                    continue
                    
                case OpCode.OP_TEST:
                    if (LuaObject.l_isfalse(o: ra) != LuaOpCodes.GETARG_C(i: i)) {
                        dojump(L: L, pc: pc, i: LuaOpCodes.GETARG_sBx(i: pc.get(index: 0)))
                    }
                    var pc_ref5:[InstructionPtr?] = [InstructionPtr?](repeating: nil, count: 1)
                    pc_ref5[0] = pc
                    _ = InstructionPtr.inc(ptr: pc_ref5) //ref
                    pc = pc_ref5[0]
                    continue
                    
                case OpCode.OP_TESTSET:
                    let rb:TValue! = RB(L: L, base_: base_, i: i)
                    if (LuaObject.l_isfalse(o: rb) != LuaOpCodes.GETARG_C(i: i)) {
                        LuaObject.setobjs2s(L: L, obj: ra, x: rb)
                        dojump(L: L, pc: pc, i: LuaOpCodes.GETARG_sBx(i: pc.get(index: 0)))
                    }
                    var pc_ref6:[InstructionPtr?] = [InstructionPtr?](repeating: nil, count: 1)
                    pc_ref6[0] = pc
                    _ = InstructionPtr.inc(ptr: pc_ref6) //ref
                    pc = pc_ref6[0]
                    continue
                    
                case OpCode.OP_CALL:
                    let b:Int = LuaOpCodes.GETARG_B(i: i)
                    let nresults:Int = LuaOpCodes.GETARG_C(i: i) - 1
                    if (b != 0) {
                        L.top = TValue.plus(value: ra, offset: b) // else previous instruction set top
                    }
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    var reentry3:Bool = false
                    switch (LuaDo.luaD_precall(L: L, func_: ra, nresults: nresults)) {
                    case LuaDo.PCRLUA:
                        nexeccalls += 1
                        //goto reentry;  /* restart luaV_execute over new Lua function */
                        reentry3 = true;
                        break
                    
                    case LuaDo.PCRC:
                        // it was a C function (`precall' called it); adjust results
                        if (nresults >= 0) {
                        L.top = L.ci.top;
                        }
                        base_ = L.base_;
                        continue;
                    
                    default:
                        return; // yield
                    }
                    if (reentry3) {
                        reentry2 = true;
                        break;
                    }
                    else {
                        break;
                    }
                    
                case OpCode.OP_TAILCALL:
                    let b:Int = LuaOpCodes.GETARG_B(i: i)
                    if (b != 0) {
                        L.top = TValue.plus(value: ra, offset: b) // else previous instruction set top
                    }
                    L.savedpc = InstructionPtr.Assign(ptr: pc);
                    LuaLimits.lua_assert(c: LuaOpCodes.GETARG_C(i: i) - 1 == Lua.LUA_MULTRET)
                    var reentry4:Bool = false
                    switch (LuaDo.luaD_precall(L: L, func_: ra, nresults: Lua.LUA_MULTRET)) {
                    case LuaDo.PCRLUA:
                        // tail call: put new frame in place of previous one
                        let ci:CallInfo! = CallInfo.minus(value: L.ci, offset: 1) // previous frame
                        var aux:Int
                        let func_:TValue! = ci.func_; //StkId
                        let pfunc:TValue! = CallInfo.plus(value: ci, offset: 1).func_; // previous function index  - StkId
                        if (L.openupval != nil) {
                            LuaFunc.luaF_close(L: L, level: ci.base_);
                        }
                        ci.base_ = TValue.plus(value: ci.func_, offset: TValue.minus(a: ci.get(offset: 1).base_, b: pfunc));
                        L.base_ = ci.base_
                        aux = 0
                        while (TValue.lessThan(a: TValue.plus(value: pfunc, offset: aux), b: L.top)) { // move frame down
                            LuaObject.setobjs2s(L: L, obj: TValue.plus(value: func_, offset: aux), x: TValue.plus(value: pfunc, offset: aux))
                            aux += 1
                        }
                        L.top = TValue.plus(value: func_, offset: aux); // correct top
                        ci.top = L.top
                        LuaLimits.lua_assert(c: L.top === TValue.plus(value: L.base_, offset: Int(LuaObject.clvalue(o: func_).l.p.maxstacksize)))
                        ci.savedpc = InstructionPtr.Assign(ptr: L.savedpc)
                        ci.tailcalls += 1 // one more call lost
                        var ci_ref3:[CallInfo?]! = [CallInfo?](repeating: nil, count: 1)
                        ci_ref3[0] = L.ci;
                        _ = CallInfo.dec(value: &ci_ref3) // remove new frame  - ref
                        L.ci = ci_ref3[0]
                        //goto reentry;
                        reentry4 = true
                        break
                    
                    case LuaDo.PCRC:
                        // it was a C function (`precall' called it)
                        base_ = L.base_
                        continue
                    
                    default:
                        return // yield
                    }
                    if (reentry4) {
                        reentry2 = true
                        break
                    }
                    else {
                        break
                    }
                    
                case OpCode.OP_RETURN:
                    var b:Int = LuaOpCodes.GETARG_B(i: i);
                    if (b != 0) {
                        L.top = TValue.plus(value: ra, offset: b - 1); //FIXME:
                    }
                    if (L.openupval != nil) {
                        LuaFunc.luaF_close(L: L, level: base_)
                    }
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    b = LuaDo.luaD_poscall(L: L, firstResult: ra)
                    nexeccalls -= 1
                    if (nexeccalls == 0) { // was previous function running `here'?
                        return; // no: return
                    }
                    else {
                        // yes: continue its execution
                        if (b != 0) {
                            L.top = L.ci.top;
                        }
                        LuaLimits.lua_assert(c: LuaState.isLua(ci: L.ci))
                        LuaLimits.lua_assert(c: LuaOpCodes.GET_OPCODE(i: L.ci.savedpc.get(index: -1)) == OpCode.OP_CALL);
                        //goto reentry;
                        reentry2 = true
                        break;
                    }
                    
                case OpCode.OP_FORLOOP:
                    let step:Double = LuaObject.nvalue(o: TValue.plus(value: ra, offset: 2)); //lua_Number
                    let idx:Double = LuaConf.luai_numadd(a: LuaObject.nvalue(o: ra), b: step); // increment index  - lua_Number
                    let limit:Double = LuaObject.nvalue(o: TValue.plus(value: ra, offset: 1)) //lua_Number
                    if (LuaConf.luai_numlt(a: 0, b: step) ? LuaConf.luai_numle(a: idx, b: limit) : LuaConf.luai_numle(a: limit, b: idx)) {
                        dojump(L: L, pc: pc, i: LuaOpCodes.GETARG_sBx(i: i)) // jump back
                        LuaObject.setnvalue(obj: ra, x: idx) // update internal index...
                        LuaObject.setnvalue(obj: TValue.plus(value: ra, offset: 3), x: idx) //...and external index
                    }
                    continue
                    
                case OpCode.OP_FORPREP:
                    var init_:TValue! = ra;
                    var plimit:TValue! = TValue.plus(value: ra, offset: 1)
                    var pstep:TValue! = TValue.plus(value: ra, offset: 2)
                    L.savedpc = InstructionPtr.Assign(ptr: pc); // next steps may throw errors
                    var retxxx:Int
                    var init_ref:[TValue?]! = [TValue?](repeating: nil, count: 1)
                    init_ref[0] = init_
                    retxxx = tonumber(o: &init_ref, n: ra) //ref
                    init_ = init_ref[0]
                    if (retxxx == 0) {
                        LuaDebug.luaG_runerror(L: L, fmt: CharPtr.toCharPtr(str: LuaConf.LUA_QL(x: "for").toString() + " initial value must be a number"))
                    }
                    else {
                        var plimit_ref:[TValue?]! = [TValue?](repeating: nil, count: 1)
                        plimit_ref[0] = plimit;
                        retxxx = tonumber(o: &plimit_ref, n: TValue.plus(value: ra, offset: 1)); //ref
                        plimit = plimit_ref[0];
                        if (retxxx == 0) {
                            LuaDebug.luaG_runerror(L: L, fmt: CharPtr.toCharPtr(str: LuaConf.LUA_QL(x: "for").toString() + " limit must be a number"))
                        }
                        else {
                            var pstep_ref:[TValue?]! = [TValue?](repeating: nil, count: 1)
                            pstep_ref[0] = pstep;
                            retxxx = tonumber(o: &pstep_ref, n: TValue.plus(value: ra, offset: 2)) //ref
                            pstep = pstep_ref[0]
                            if (retxxx == 0) {
                                LuaDebug.luaG_runerror(L: L, fmt: CharPtr.toCharPtr(str: LuaConf.LUA_QL(x: "for").toString() + " step must be a number"));
                            }
                        }
                    }
                    LuaObject.setnvalue(obj: ra, x: LuaConf.luai_numsub(a: LuaObject.nvalue(o: ra), b: LuaObject.nvalue(o: pstep)))
                    dojump(L: L, pc: pc, i: LuaOpCodes.GETARG_sBx(i: i))
                    continue
                    
                case OpCode.OP_TFORLOOP:
                    var cb:TValue! = TValue.plus(value: ra, offset: 3) // call base  - StkId
                    LuaObject.setobjs2s(L: L, obj: TValue.plus(value: cb, offset: 2), x: TValue.plus(value: ra, offset: 2))
                    LuaObject.setobjs2s(L: L, obj: TValue.plus(value: cb, offset: 1), x: TValue.plus(value: ra, offset: 1))
                    LuaObject.setobjs2s(L: L, obj: cb, x: ra)
                    L.top = TValue.plus(value: cb, offset: 3) // func. + 2 args (state and index)
                    //Protect(
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    LuaDo.luaD_call(L: L, func_: cb, nResults: LuaOpCodes.GETARG_C(i: i))
                    base_ = L.base_;
                    //);
                    L.top = L.ci.top;
                    cb = TValue.plus(value: RA(L: L, base_: base_, i: i), offset: 3) // previous call may change the stack
                    if (!LuaObject.ttisnil(o: cb)) {
                        // continue loop?
                        LuaObject.setobjs2s(L: L, obj: TValue.minus(value: cb, offset: 1), x: cb); // save control variable
                        dojump(L: L, pc: pc, i: LuaOpCodes.GETARG_sBx(i: pc.get(index: 0))) // jump back
                    }
                    var pc_ref3:[InstructionPtr?] = [InstructionPtr?](repeating: nil, count: 1)
                    pc_ref3[0] = pc
                    _ = InstructionPtr.inc(ptr: pc_ref3) //ref
                    pc = pc_ref3[0]
                    continue
                    
                case OpCode.OP_SETLIST:
                    var n:Int = LuaOpCodes.GETARG_B(i: i)
                    var c:Int = LuaOpCodes.GETARG_C(i: i)
                    var last:Int
                    var h:Table!
                    if (n == 0) {
                        n = LuaLimits.cast_int(i: TValue.minus(a: L.top, b: ra)) - 1
                        L.top = L.ci.top
                    }
                    if (c == 0) {
                        c = LuaLimits.cast_int_instruction(i: pc.get(index: 0))
                        var pc_ref5:[InstructionPtr?] = [InstructionPtr?](repeating: nil, count: 1)
                        pc_ref5[0] = pc
                        _ = InstructionPtr.inc(ptr: pc_ref5) //ref
                        pc = pc_ref5[0]
                    }
                    runtime_check(L: L, c: LuaObject.ttistable(o: ra))
                    h = LuaObject.hvalue(o: ra)
                    last = ((c - 1) * LuaOpCodes.LFIELDS_PER_FLUSH) + n;
                    if (last > h.sizearray) { // needs more space?
                        LuaTable.luaH_resizearray(L: L, t: h, nasize: last); // pre-alloc it at once
                    }
                    while (n > 0) {
                        let val:TValue! = TValue.plus(value: ra, offset: n)
                        LuaObject.setobj2t(L: L, obj: LuaTable.luaH_setnum(L: L, t: h, key: last), x: val)
                        last -= 1
                        LuaGC.luaC_barriert(L: L, t: h, v: val)
                        n -= 1
                    }
                    continue
                    
                case OpCode.OP_CLOSE:
                    LuaFunc.luaF_close(L: L, level: ra)
                    continue
                    
                case OpCode.OP_CLOSURE:
                    var p:Proto!
                    var ncl:Closure!
                    var nup:Int, j:Int
                    p = cl.p.p[LuaOpCodes.GETARG_Bx(i: i)]
                    nup = Int(p.nups)
                    ncl = LuaFunc.luaF_newLclosure(L: L, nelems: nup, e: cl.getEnv())
                    ncl.l.p = p
                    j = 0
                    while (j < nup) {
                        if (LuaOpCodes.GET_OPCODE(i: pc.get(index: 0)) == OpCode.OP_GETUPVAL) {
                            ncl.l.upvals[j] = cl.upvals[LuaOpCodes.GETARG_B(i: pc.get(index: 0))]
                        }
                        else {
                            LuaLimits.lua_assert(c: LuaOpCodes.GET_OPCODE(i: pc.get(index: 0)) == OpCode.OP_MOVE);
                            ncl.l.upvals[j] = LuaFunc.luaF_findupval(L: L, level: TValue.plus(value: base_, offset: LuaOpCodes.GETARG_B(i: pc.get(index: 0))));
                        }

                        j += 1
                        var pc_ref4:[InstructionPtr?]! = [InstructionPtr?](repeating: nil, count: 1)
                        pc_ref4[0] = pc
                        _ = InstructionPtr.inc(ptr: pc_ref4) //ref
                        pc = pc_ref4[0]
                    }
                    LuaObject.setclvalue(L: L, obj: ra, x: ncl)
                    //Protect(
                    L.savedpc = InstructionPtr.Assign(ptr: pc)
                    LuaGC.luaC_checkGC(L: L)
                    base_ = L.base_;
                    //);
                    continue
                    
                case OpCode.OP_VARARG:
                    var b:Int = LuaOpCodes.GETARG_B(i: i) - 1
                    var j:Int
                    let ci:CallInfo! = L.ci
                    let n:Int = LuaLimits.cast_int(i: TValue.minus(a: ci.base_, b: ci.func_)) - Int(cl.p.numparams) - 1
                    if (b == Lua.LUA_MULTRET) {
                        //Protect(
                        L.savedpc = InstructionPtr.Assign(ptr: pc)
                        LuaDo.luaD_checkstack(L: L, n: n)
                        base_ = L.base_
                        //);
                        ra = RA(L: L, base_: base_, i: i) // previous call may change the stack
                        b = n
                        L.top = TValue.plus(value: ra, offset: n)
                    }
                    j = 0
                    while (j < b) {
                        if (j < n) {
                            LuaObject.setobjs2s(L: L, obj: TValue.plus(value: ra, offset: j), x: TValue.plus(value: TValue.minus(value: ci.base_, offset: n), offset: j)) //FIXME:
                        }
                        else {
                            LuaObject.setnilvalue(obj: TValue.plus(value: ra, offset: j))
                        }
                        j += 1
                    }
                    continue
                } //end switch
                if (reentry2 == true) {
                    reentry = true
                    break
                }
            } //end for
            if (reentry == true) {
                continue;
            }
            else {
                break;
            }
        } //end while
    }

}
