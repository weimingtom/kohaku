//package kurumi;

//
// ** $Id: ltm.c,v 2.8.1.1 2007/12/27 13:02:25 roberto Exp $
// ** Tag methods
// ** See Copyright Notice in lua.h
//
//using TValue = Lua.TValue;

public class LuaTM {

}

/*
 * WARNING: if you change the order of this enumeration,
 * grep "ORDER TM"
 */
public enum TMS : Int {
    case TM_INDEX
    case TM_NEWINDEX
    case TM_GC
    case TM_MODE
    case TM_EQ  /* last tag method with `fast' access */
    case TM_ADD
    case TM_SUB
    case TM_MUL
    case TM_DIV
    case TM_MOD
    case TM_POW
    case TM_UNM
    case TM_LEN
    case TM_LT
    case TM_LE
    case TM_CONCAT
    case TM_CALL
    case TM_N        /* number of elements in the enum */
    
    public func getValue() -> Int {
        return self.rawValue
    }
    
    public static func forValue(value:Int) -> TMS {
        return TMS(rawValue: value)!
    }
}

extension LuaTM {
    public static func convertTMStoInt(tms:TMS) -> Int {
        switch (tms) {
        case .TM_INDEX:
            return 0
        
        case .TM_NEWINDEX:
            return 1
        
        case .TM_GC:
            return 2
        
        case .TM_MODE:
            return 3
        
        case .TM_EQ:
            return 4
        
        case .TM_ADD:
            return 5
        
        case .TM_SUB:
            return 6
        
        case .TM_MUL:
            return 7
        
        case .TM_DIV:
            return 8
        
        case .TM_MOD:
            return 9
        
        case .TM_POW:
            return 10
        
        case .TM_UNM:
            return 11
        
        case .TM_LEN:
            return 12
        
        case .TM_LT:
            return 13
        
        case .TM_LE:
            return 14
        
        case .TM_CONCAT:
            return 15
        
        case .TM_CALL:
            return 16
        
        case .TM_N:
            return 17
        }
        //assert(false, "convertTMStoInt error");
    }
    
    public static func gfasttm(g:global_State!, et:Table!, e:TMS) -> TValue! {
        return (et == nil) ? nil : ((et.flags & (1 << e.getValue())) != 0) ? nil : luaT_gettm(events: et, event_: e, ename: g.tmname[e.getValue()])
    }
    
    public static func fasttm(l:lua_State!, et:Table!, e:TMS) -> TValue! {
        return gfasttm(g: LuaState.G(L: l), et: et, e: e)
    }
    
    public static let luaT_typenames:[CharPtr] = [
        CharPtr.toCharPtr(str: "nil"),
        CharPtr.toCharPtr(str: "boolean"),
        CharPtr.toCharPtr(str: "userdata"),
        CharPtr.toCharPtr(str: "number"),
        CharPtr.toCharPtr(str: "string"),
        CharPtr.toCharPtr(str: "table"),
        CharPtr.toCharPtr(str: "function"),
        CharPtr.toCharPtr(str: "userdata"),
        CharPtr.toCharPtr(str: "thread"),
        CharPtr.toCharPtr(str: "proto"),
        CharPtr.toCharPtr(str: "upval")
    ]
    
    private static let luaT_eventname:[CharPtr] = [
        CharPtr.toCharPtr(str: "__index"),
        CharPtr.toCharPtr(str: "__newindex"),
        CharPtr.toCharPtr(str: "__gc"),
        CharPtr.toCharPtr(str: "__mode"),
        CharPtr.toCharPtr(str: "__eq"),
        CharPtr.toCharPtr(str: "__add"),
        CharPtr.toCharPtr(str: "__sub"),
        CharPtr.toCharPtr(str: "__mul"),
        CharPtr.toCharPtr(str: "__div"),
        CharPtr.toCharPtr(str: "__mod"),
        CharPtr.toCharPtr(str: "__pow"),
        CharPtr.toCharPtr(str: "__unm"),
        CharPtr.toCharPtr(str: "__len"),
        CharPtr.toCharPtr(str: "__lt"),
        CharPtr.toCharPtr(str: "__le"),
        CharPtr.toCharPtr(str: "__concat"),
        CharPtr.toCharPtr(str: "__call")
    ]
    
    public static func luaT_init(L:lua_State!) {
        for i:Int in 0 ..< TMS.TM_N.getValue() {
            LuaState.G(L: L).tmname[i] = LuaString.luaS_new(L: L, s: luaT_eventname[i])
            LuaString.luaS_fix(s: LuaState.G(L: L).tmname[i]) // never collect these names
        }
    }
    
    //
    //         ** function to be used with macro "fasttm": optimized for absence of
    //         ** tag methods
    //
    public static func luaT_gettm(events:Table!, event_:TMS, ename:TString!) -> TValue! {
        //const
        let tm:TValue! = LuaTable.luaH_getstr(t: events, key: ename)
        LuaLimits.lua_assert(c: convertTMStoInt(tms: event_) <= convertTMStoInt(tms: TMS.TM_EQ))
        if (LuaObject.ttisnil(o: tm)) {
            // no tag method?
            events.flags |= Int8(1 << event_.getValue()) // cache this fact
            return nil
        }
        else {
            return tm
        }
    }
    
    public static func luaT_gettmbyobj(L:lua_State!, o:TValue!, event_:TMS) -> TValue! {
        var mt:Table!
        switch (LuaObject.ttype(o: o)) {
        case Lua.LUA_TTABLE:
            mt = LuaObject.hvalue(o: o).metatable
            break
        
        case Lua.LUA_TUSERDATA:
            mt = LuaObject.uvalue(o: o).metatable
            break
        
        default:
            mt = LuaState.G(L: L).mt[LuaObject.ttype(o: o)]
            break
        }
        return ((mt != nil) ? LuaTable.luaH_getstr(t: mt, key: LuaState.G(L: L).tmname[event_.getValue()]) : LuaObject.luaO_nilobject)
    }
}
