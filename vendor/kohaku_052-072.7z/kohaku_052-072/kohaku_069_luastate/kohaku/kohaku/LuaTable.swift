//package kurumi;

//
// ** $Id: ltable.c,v 2.32.1.2 2007/12/28 15:32:23 roberto Exp $
// ** Lua tables (hash)
// ** See Copyright Notice in lua.h
//

//using TValue = Lua.TValue;
//using StkId = TValue;
//using lua_Number = System.Double;

public class LuaTable {
    //
    //         ** Implementation of tables (aka arrays, objects, or hash tables).
    //         ** Tables keep its elements in two parts: an array part and a hash part.
    //         ** Non-negative integer keys are all candidates to be kept in the array
    //         ** part. The actual size of the array is the largest `n' such that at
    //         ** least half the slots between 0 and n are in use.
    //         ** Hash uses a mix of chained scatter table with Brent's variation.
    //         ** A main invariant of these tables is that, if an element is not
    //         ** in its main position (i.e. the `original' position that its hash gives
    //         ** to it), then the colliding element is in its own main position.
    //         ** Hence even when the load factor reaches 100%, performance remains good.
    //
    
    public static func gnode(t:Table!, i:Int) -> Node! {
        return t.node[i]
    }
    
    public static func gkey(n:Node!) -> TKey_nk! {
        return n.i_key.nk
    }
    
    public static func gval(n:Node!) -> TValue! {
        return n.i_val
    }
    
    public static func gnext(n:Node!) -> Node! {
        return n.i_key.nk.next
    }
    
    public static func gnext_set(n:Node!, v:Node!) {
        n.i_key.nk.next = v
    }
    
    public static func key2tval(n:Node!) -> TValue! {
        return n.i_key.getTvk()
    }
    
    //
    //         ** max size of array part is 2^MAXBITS
    //
    ///#if LUAI_BITSINT > 26
    public static let MAXBITS:Int = 26 // in the dotnet port LUAI_BITSINT is 32
    ///#else
    //public const int MAXBITS        = (LUAI_BITSINT-2);
    ///#endif
    
    public static let MAXASIZE:Int = (1 << MAXBITS)
    
    //public static Node gnode(Table t, int i)    {return t.node[i];}
    public static func hashpow2(t:Table!, n:Double) -> Node! { //lua_Number
        return gnode(t: t, i: Int(CLib.lmod(a: n, b: Double(LuaObject.sizenode(t: t)))))
    }
    
    public static func hashstr(t:Table!, str:TString!) -> Node! {
        return hashpow2(t: t, n: Double(str.getTsv().hash))
    }
    
    public static func hashboolean(t:Table!, p:Int) -> Node! {
        return hashpow2(t: t, n: Double(p))
    }
    
    //
    //         ** for some types, it is better to avoid modulus by power of 2, as
    //         ** they tend to have many 2 factors.
    //
    public static func hashmod(t:Table!, n:Int) -> Node! {
        return gnode(t: t, i: (n % ((LuaObject.sizenode(t: t) - 1) | 1)))
    }
    
    public static func hashpointer(t:Table!, p:Any!) -> Node! {
        return hashmod(t: t, n: ClassType.hashCode(o: p))
    }
    
    //
    //         ** number of ints inside a lua_Number
    //
    public static let numints:Int = ClassType.GetNumInts() //const

    
    //static const Node dummynode_ = {
    //{{null}, LUA_TNIL},  /* value */
    //{{{null}, LUA_TNIL, null}}  /* key */
    //};
    public static var dummynode_:Node! = Node(
        i_val: TValue(value: Value(), tt: Lua.LUA_TNIL),
        i_key: TKey(value: Value(), tt: Lua.LUA_TNIL, next: nil)
    );
    public static var dummynode:Node! = dummynode_
    
    //
    //         ** hash for lua_Numbers
    //
    private static func hashnum(t:Table!, n:Double) -> Node! { //lua_Number
        var a:[Int] = ClassType.GetBytes(d: n)
        for i:Int in 1 ..< a.count {
            a[0] += a[i]
        }
        return hashmod(t: t, n: Int(a[0] & 0xff))
    }
    
    //
    //         ** returns the `main' position of an element in a table (that is, the index
    //         ** of its hash value)
    //
    private static func mainposition(t:Table!, key:TValue!) -> Node! {
        switch (LuaObject.ttype(o: key)) {
        case Lua.LUA_TNUMBER:
            return hashnum(t: t, n: LuaObject.nvalue(o: key))
        
        case Lua.LUA_TSTRING:
            return hashstr(t: t, str: LuaObject.rawtsvalue(o: key))
        
        case Lua.LUA_TBOOLEAN:
            return hashboolean(t: t, p: LuaObject.bvalue(o: key))
        
        case Lua.LUA_TLIGHTUSERDATA:
            return hashpointer(t: t, p: LuaObject.pvalue(o: key))
        
        default:
            return hashpointer(t: t, p: LuaObject.gcvalue(o: key))
        }
    }
    
    
    //
    //         ** returns the index for `key' if `key' is an appropriate key to live in
    //         ** the array part of the table, -1 otherwise.
    //
    private static func arrayindex(key:TValue!) -> Int {
        if (LuaObject.ttisnumber(o: key)) {
            let n:Double = LuaObject.nvalue(o: key); //lua_Number
            var k:[Int] = [Int](repeating: 0, count: 1)
            LuaConf.lua_number2int(i: k, d: n) //out
            if (LuaConf.luai_numeq(a: LuaLimits.cast_num(i: k[0]), b: n)) {
                return k[0];
            }
        }
        return -1 // `key' did not match some condition
    }
    
    //
    //         ** returns the index of a `key' for table traversals. First goes all
    //         ** elements in the array part, then elements in the hash part. The
    //         ** beginning of a traversal is signalled by -1.
    //
    private static func findindex(L:lua_State!, t:Table!, key:TValue!) -> Int { //StkId
        var i:Int
        if (LuaObject.ttisnil(o: key)) {
            return -1 // first iteration
        }
        i = arrayindex(key: key)
        if (0 < i && i <= t.sizearray) { // is `key' inside array part?
            return i - 1 // yes; that's the index (corrected to C)
        }
        else {
            var n:Node! = mainposition(t: t, key: key)
            repeat {
                // check whether `key' is somewhere in the chain
                // key may be dead already, but it is ok to use it in `next'
                if ((LuaObject.luaO_rawequalObj(t1: key2tval(n: n), t2: key) != 0) || (LuaObject.ttype(o: gkey(n: n)) == LuaObject.LUA_TDEADKEY && LuaObject.iscollectable(o: key) && LuaObject.gcvalue(o: gkey(n: n)) === LuaObject.gcvalue(o: key))) {
                    i = LuaLimits.cast_int(i: Node.minus(n1: n, n2: gnode(t: t, i: 0))) // key index in hash table
                    // hash elements are numbered after array ones
                    return i + t.sizearray
                }
                else {
                    n = gnext(n: n)
                }
            } while (Node.isNotEqual(n1: n, n2: nil))
            LuaDebug.luaG_runerror(L: L, fmt: CharPtr.toCharPtr(str: "invalid key to " + LuaConf.LUA_QL(x: "next").toString())) // key not found
            return 0 // to avoid warnings
        }
    }
    
    public static func luaH_next(L:lua_State!, t:Table!, key:TValue!) -> Int { //StkId
        var i:Int = findindex(L: L, t: t, key: key) // find original element
        i += 1
        while (i < t.sizearray) {
            // try first array part
            if (!LuaObject.ttisnil(o: t.array[i])) {
                // a non-nil value?
                LuaObject.setnvalue(obj: key, x: LuaLimits.cast_num(i: i + 1))
                LuaObject.setobj2s(L: L, obj: TValue.plus(value: key, offset: 1), x: t.array[i])
                return 1;
            }
            i += 1
        }
        i -= t.sizearray
        while (i < LuaObject.sizenode(t: t)) {
            // then hash part
            if (!LuaObject.ttisnil(o: gval(n: gnode(t: t, i: i)))) {
                // a non-nil value?
                LuaObject.setobj2s(L: L, obj: key, x: key2tval(n: gnode(t: t, i: i)))
                LuaObject.setobj2s(L: L, obj: TValue.plus(value: key, offset: 1), x: gval(n: gnode(t: t, i: i)))
                return 1;
            }
            i += 1
        }
        return 0 // no more elements
    }
    
    
    //
    //         ** {=============================================================
    //         ** Rehash
    //         ** ==============================================================
    //
    
    private static func computesizes(nums:[Int]!, narray:inout [Int]!) -> Int { //ref
        var i:Int
        var twotoi:Int // 2^i
        var a:Int = 0; // number of elements smaller than 2^i
        var na:Int = 0; // number of elements to go to array part
        var n:Int = 0; // optimal size for array part
        i = 0
        twotoi = 1
        while (twotoi / 2 < narray[0]) {
            if (nums[i] > 0) {
                a += nums[i]
                if (a > twotoi / 2) {
                    // more than half elements present?
                    n = twotoi // optimal size (till now)
                    na = a // all elements smaller than n will go to array part
                }
            }
            if (a == narray[0]) {
                break // all elements already counted
            }
            i += 1
            twotoi *= 2
        }
        narray[0] = n
        LuaLimits.lua_assert(c: narray[0] / 2 <= na && na <= narray[0])
        return na
    }
    
    private static func countint(key:TValue!, nums:inout [Int]!) -> Int {
        let k:Int = arrayindex(key: key)
        if (0 < k && k <= MAXASIZE) {
            // is `key' an appropriate array index?
            nums[LuaObject.ceillog2(x: k)] += 1 // count as such
            return 1
        }
        else {
            return 0
        }
    }
    
    private static func numusearray(t:Table!, nums:inout [Int]!) -> Int {
        var lg:Int
        var ttlg:Int // 2^lg
        var ause:Int = 0 // summation of `nums'
        var i:Int = 1 // count to traverse all array keys
        lg = 0
        ttlg = 1
        while (lg <= MAXBITS) {
            // for each slice
            var lc:Int = 0 // counter
            var lim:Int = ttlg
            if (lim > t.sizearray) {
                lim = t.sizearray // adjust upper limit
                if (i > lim) {
                    break // no more elements to count
                }
            }
            // count elements in range (2^(lg-1), 2^lg]
            while (i <= lim) {
                if (!LuaObject.ttisnil(o: t.array[i - 1])) {
                    lc += 1
                }
                i += 1
            }
            nums[lg] += lc
            ause += lc
            lg += 1
            ttlg *= 2
        }
        return ause
    }
    
    private static func numusehash(t:Table!, nums:inout [Int]!, pnasize:inout [Int]!) -> Int { //ref
        var totaluse:Int = 0; // total number of elements
        var ause:Int = 0; // summation of `nums'
        var i:Int = LuaObject.sizenode(t: t)
        while (i != 0) {
            i -= 1
            let n:Node! = t.node[i];
            if (!LuaObject.ttisnil(o: gval(n: n))) {
                ause += countint(key: key2tval(n: n), nums: &nums)
                totaluse += 1
            }
        }
        pnasize[0] += ause
        return totaluse
    }
    
    private static func setarrayvector(L:lua_State!, t:Table!, size:Int) {
        var array_ref:[[TValue]] = [[TValue]](repeating:[], count: 1)
        array_ref[0] = t.array
        _ = LuaMem.luaM_reallocvector_TValue(L: L, v: array_ref, oldn: t.sizearray, n: size, t: ClassType(type: ClassType.TYPE_TVALUE)) //, TValue - ref
        t.array = array_ref[0];
        for i:Int in t.sizearray ..< size {
            LuaObject.setnilvalue(obj: t.array[i])
        }
        t.sizearray = size;
    }
    
    private static func setnodevector(L:lua_State!, t:Table!, size:Int) {
        var size:Int = size
        var lsize:Int
        if (size == 0) {
            // no elements to hash part?
            t.node = [ dummynode ] // use common `dummynode'
            lsize = 0
        }
        else {
            var _:Int
            lsize = LuaObject.ceillog2(x: size)
            if (lsize > MAXBITS) {
                LuaDebug.luaG_runerror(L: L, fmt: CharPtr.toCharPtr(str: "table overflow"))
            }
            size = LuaObject.twoto(x: lsize)
            let nodes:[Node]! = LuaMem.luaM_newvector_Node(L: L, n: size, t: ClassType(type: ClassType.TYPE_NODE));
            t.node = nodes
            for i:Int in 0 ..< size {
                let n:Node! = gnode(t: t, i: i)
                gnext_set(n: n, v: nil)
                LuaObject.setnilvalue(obj: gkey(n: n))
                LuaObject.setnilvalue(obj: gval(n: n))
            }
        }
        t.lsizenode = LuaLimits.cast_byte(i: lsize)
        t.lastfree = size // all positions are free
    }
    
    private static func resize(L:lua_State!, t:Table!, nasize:Int, nhsize:Int) {
        var i:Int
        let oldasize:Int = t.sizearray
        let oldhsize:Int = Int(t.lsizenode)
        var nold:[Node]! = t.node // save old hash...
        if (nasize > oldasize) { // array part must grow?
            setarrayvector(L: L, t: t, size: nasize)
        }
        // create new hash part with appropriate size
        setnodevector(L: L, t: t, size: nhsize)
        if (nasize < oldasize) {
            // array part must shrink?
            t.sizearray = nasize;
            // re-insert elements from vanishing slice
            for i in nasize ..< oldasize {
                if (!LuaObject.ttisnil(o: t.array[i])) {
                    LuaObject.setobjt2t(L: L, obj: luaH_setnum(L: L, t: t, key: i + 1), x: t.array[i])
                }
            }
            // shrink array
            var array_ref:[[TValue]] = [[TValue]](repeating: [], count: 1)
            array_ref[0] = t.array;
            _ = LuaMem.luaM_reallocvector_TValue(L: L, v: array_ref, oldn: oldasize, n: nasize, t: ClassType(type: ClassType.TYPE_TVALUE)) //, TValue - ref
            t.array = array_ref[0]
        }
        // re-insert elements from hash part
        i = LuaObject.twoto(x: oldhsize) - 1
        while (i >= 0) {
            let old:Node! = nold[i]
            if (!LuaObject.ttisnil(o: gval(n: old))) {
                LuaObject.setobjt2t(L: L, obj: luaH_set(L: L, t: t, key: key2tval(n: old)), x: gval(n: old))
            }
            i -= 1
        }
        if (Node.isNotEqual(n1: nold[0], n2: dummynode)) {
            LuaMem.luaM_freearray_Node(L: L, b: nold, t: ClassType(type: ClassType.TYPE_NODE)) // free old array
        }
    }
    
    public static func luaH_resizearray(L:lua_State!, t:Table!, nasize:Int) {
        let nsize:Int = (Node.isEqual(n1: t.node[0], n2: dummynode)) ? 0 : LuaObject.sizenode(t: t)
        resize(L: L, t: t, nasize: nasize, nhsize: nsize)
    }
    
    private static func rehash(L:lua_State!, t:Table!, ek:TValue!) {
        var nasize:[Int]! = [Int](repeating: 0, count: 1)
        var na:Int
        var nums:[Int]! = [Int](repeating: 0, count: MAXBITS + 1) // nums[i] = number of keys between 2^(i-1) and 2^i
        var totaluse:Int
        for i:Int in 0 ... MAXBITS {
            nums[i] = 0 // reset counts
        }
        nasize[0] = numusearray(t: t, nums: &nums) // count keys in array part
        totaluse = nasize[0] // all those keys are integer keys
        totaluse += numusehash(t: t, nums: &nums, pnasize: &nasize) // count keys in hash part  - ref
        // count extra key
        nasize[0] += countint(key: ek, nums: &nums)
        totaluse += 1
        // compute new size for array part
        na = computesizes(nums: nums, narray: &nasize) //ref
        // resize the table to new computed sizes
        resize(L: L, t: t, nasize: nasize[0], nhsize: totaluse - na)
    }
    
    //
    //         ** }=============================================================
    //
    
    public static func luaH_new(L:lua_State!, narray:Int, nhash:Int) -> Table! {
        let t:Table! = LuaMem.luaM_new_Table(L: L, t: ClassType(type: ClassType.TYPE_TABLE))
        LuaGC.luaC_link(L: L, o: LuaState.obj2gco(v: t), tt: Int8(Lua.LUA_TTABLE))
        t.metatable = nil
        t.flags = LuaLimits.cast_byte(i: ~0)
        // temporary values (kept only if some malloc fails)
        t.array = nil
        t.sizearray = 0
        t.lsizenode = 0
        t.node = [ dummynode ]
        setarrayvector(L: L, t: t, size: narray)
        setnodevector(L: L, t: t, size: nhash)
        return t
    }
    
    public static func luaH_free(L:lua_State!, t:Table!) {
        if (Node.isNotEqual(n1: t.node[0], n2: dummynode)) {
            LuaMem.luaM_freearray_Node(L: L, b: t.node, t: ClassType(type: ClassType.TYPE_NODE));
        }
        LuaMem.luaM_freearray_TValue(L: L, b: t.array, t: ClassType(type: ClassType.TYPE_TVALUE))
        LuaMem.luaM_free_Table(L: L, b: t, t: ClassType(type: ClassType.TYPE_TABLE));
    }
    
    private static func getfreepos(t:Table!) -> Node! {
        while (t.lastfree > 0) {
            t.lastfree -= 1
            if (LuaObject.ttisnil(o: gkey(n: t.node[t.lastfree]))) {
                return t.node[t.lastfree];
            }
        }
        return nil // could not find a free place
    }
    
    //
    //         ** inserts a new key into a hash table; first, check whether key's main
    //         ** position is free. If not, check whether colliding node is in its main
    //         ** position or not: if it is not, move colliding node to an empty place and
    //         ** put new key in its main position; otherwise (colliding node is in its main
    //         ** position), new key goes to an empty position.
    //
    private static func newkey(L:lua_State!, t:Table!, key:TValue!) -> TValue! {
        var mp:Node! = mainposition(t: t, key: key)
        if (!LuaObject.ttisnil(o: gval(n: mp)) || Node.isEqual(n1: mp, n2: dummynode)) {
            var othern:Node!
            let n:Node! = getfreepos(t: t) // get a free place
            if (Node.isEqual(n1: n, n2: nil)) {
                // cannot find a free place?
                rehash(L: L, t: t, ek: key) // grow table
                return luaH_set(L: L, t: t, key: key) // re-insert key into grown table
            }
            LuaLimits.lua_assert(c: Node.isNotEqual(n1: n, n2: dummynode))
            othern = mainposition(t: t, key: key2tval(n: mp))
            if (Node.isNotEqual(n1: othern, n2: mp)) {
                // is colliding node out of its main position?
                // yes; move colliding node into free position
                while (Node.isNotEqual(n1: gnext(n: othern), n2: mp)) {
                    othern = gnext(n: othern) // find previous
                }
                gnext_set(n: othern, v: n) // redo the chain with `n' in place of `mp'
                n.i_val = TValue(value: mp.i_val) // copy colliding node into free pos. (mp.next also goes)
                n.i_key = TKey(copy: mp.i_key)
                gnext_set(n: mp, v: nil); // now `mp' is free
                LuaObject.setnilvalue(obj: gval(n: mp))
            }
            else {
                // colliding node is in its own main position
                // new node will go into free position
                gnext_set(n: n, v: gnext(n: mp)) // chain new position
                gnext_set(n: mp, v: n)
                mp = n;
            }
        }
        gkey(n: mp).value.copyFrom(copy: key.value)
        gkey(n: mp).tt = key.tt
        LuaGC.luaC_barriert(L: L, t: t, v: key)
        LuaLimits.lua_assert(c: LuaObject.ttisnil(o: gval(n: mp)))
        return gval(n: mp)
    }
    
    //
    //         ** search function for integers
    //
    public static func luaH_getnum(t:Table!, key:Int) -> TValue! {
        // (1 <= key && key <= t.sizearray)
        if (Int64((Int64(key - 1)) & 0xffffffff) < Int64(Int64(t.sizearray) & 0xffffffff)) { //uint - uint
            return t.array[key - 1]
        }
        else {
            let nk:Double = LuaLimits.cast_num(i: key) //lua_Number
            var n:Node! = hashnum(t: t, n: nk)
            repeat {
                // check whether `key' is somewhere in the chain
                if (LuaObject.ttisnumber(o: gkey(n: n)) && LuaConf.luai_numeq(a: LuaObject.nvalue(o: gkey(n: n)), b: nk)) {
                    return gval(n: n) // that's it
                }
                else {
                    n = gnext(n: n)
                }
            } while (Node.isNotEqual(n1: n, n2: nil))
            return LuaObject.luaO_nilobject;
        }
    }
    
    //
    //         ** search function for strings
    //
    public static func luaH_getstr(t:Table!, key:TString!) -> TValue! {
        var n:Node! = hashstr(t: t, str: key)
        repeat {
            // check whether `key' is somewhere in the chain
            if (LuaObject.ttisstring(o: gkey(n: n)) && LuaObject.rawtsvalue(o: gkey(n: n)) === key) {
                return gval(n: n) // that's it
            }
            else {
                n = gnext(n: n)
            }
        } while (Node.isNotEqual(n1: n, n2: nil))
        return LuaObject.luaO_nilobject
    }
    
    //
    //         ** main search function
    //
    public static func luaH_get(t:Table!, key:TValue!) -> TValue! {
        switch (LuaObject.ttype(o: key)) {
        case Lua.LUA_TNIL:
            return LuaObject.luaO_nilobject
        
        case Lua.LUA_TSTRING:
            return luaH_getstr(t: t, key: LuaObject.rawtsvalue(o: key))
        
        case Lua.LUA_TNUMBER:
            var k:[Int] = [Int](repeating: 0, count: 1)
            let n:Double = LuaObject.nvalue(o: key) //lua_Number
            LuaConf.lua_number2int(i: k, d: n) //out
            if (LuaConf.luai_numeq(a: LuaLimits.cast_num(i: k[0]), b: LuaObject.nvalue(o: key))) { // index is int?
                return luaH_getnum(t: t, key: k[0]) // use specialized version
            }
            // else go through ... actually on second thoughts don't, because this is C#
            var node:Node! = mainposition(t: t, key: key)
            repeat {
                // check whether `key' is somewhere in the chain
                if (LuaObject.luaO_rawequalObj(t1: key2tval(n: node), t2: key) != 0) {
                    return gval(n: node) // that's it
                }
                else {
                    node = gnext(n: node)
                }
            } while (Node.isNotEqual(n1: node, n2: nil))
            return LuaObject.luaO_nilobject;
        
        default:
            var node:Node! = mainposition(t: t, key: key)
            repeat {
                // check whether `key' is somewhere in the chain
                if (LuaObject.luaO_rawequalObj(t1: key2tval(n: node), t2: key) != 0) {
                    return gval(n: node) // that's it
                }
                else {
                    node = gnext(n: node)
                }
            } while (Node.isNotEqual(n1: node, n2: nil))
            return LuaObject.luaO_nilobject;
        }
    }
    
    public static func luaH_set(L:lua_State!, t:Table!, key:TValue!) -> TValue! {
        let p:TValue! = luaH_get(t: t, key: key)
        t.flags = 0;
        if (p !== LuaObject.luaO_nilobject) {
            return p as TValue!
        }
        else {
            if (LuaObject.ttisnil(o: key)) {
                LuaDebug.luaG_runerror(L: L, fmt: CharPtr.toCharPtr(str: "table index is nil"))
            }
            else if (LuaObject.ttisnumber(o: key) && LuaConf.luai_numisnan(a: LuaObject.nvalue(o: key))) {
                LuaDebug.luaG_runerror(L: L, fmt: CharPtr.toCharPtr(str: "table index is NaN"));
            }
            return newkey(L: L, t: t, key: key)
        }
    }
    
    public static func luaH_setnum(L:lua_State!, t:Table!, key:Int) -> TValue! {
        let p:TValue! = luaH_getnum(t: t, key: key)
        if (p !== LuaObject.luaO_nilobject) {
            return p as TValue!
        }
        else {
            let k:TValue! = TValue()
            LuaObject.setnvalue(obj: k, x: LuaLimits.cast_num(i: key))
            return newkey(L: L, t: t, key: k)
        }
    }
    
    public static func luaH_setstr(L:lua_State!, t:Table!, key:TString!) -> TValue! {
        let p:TValue! = luaH_getstr(t: t, key: key)
        if (p !== LuaObject.luaO_nilobject) {
            return p as TValue!
        }
        else {
            let k:TValue! = TValue()
            LuaObject.setsvalue(L: L, obj: k, x: key)
            return newkey(L: L, t: t, key: k)
        }
    }
    
    public static func unbound_search(t:Table!, j:Int) -> Int { //uint
        var j:Int = j
        var i:Int = j // i is zero or a present index  - uint
        j += 1
        // find `i' and `j' such that i is present and j is not
        while (!LuaObject.ttisnil(o: luaH_getnum(t: t, key: Int(j)))) {
            i = j
            j *= 2
            if (j > Int(LuaLimits.MAX_INT)) { //uint
                // overflow?
                // table was built with bad purposes: resort to linear search
                i = 1
                while (!LuaObject.ttisnil(o: luaH_getnum(t: t, key: Int(i)))) {
                    i += 1
                }
                return Int(i - 1)
            }
        }
        // now do a binary search between them
        while (j - i > 1) {
            let m:Int = (i + j) / 2 //uint
            if (LuaObject.ttisnil(o: luaH_getnum(t: t, key: Int(m)))) {
                j = m
            }
            else {
                i = m
            }
        }
        return Int(i)
    }
    
    //
    //         ** Try to find a boundary in table `t'. A `boundary' is an integer index
    //         ** such that t[i] is non-nil and t[i+1] is nil (and 0 if t[1] is nil).
    //
    public static func luaH_getn(t:Table!) -> Int {
        var j:Int = Int(t.sizearray) //uint - uint
        if (j > 0 && LuaObject.ttisnil(o: t.array[j - 1])) {
            // there is a boundary in the array part: (binary) search for it
            var i:Int = 0; //uint
            while (j - i > 1) {
                let m:Int = (i + j) / 2 //uint
                if (LuaObject.ttisnil(o: t.array[m - 1])) {
                    j = m
                }
                else {
                    i = m
                }
            }
            return Int(i)
        }
        // else must find a boundary in hash part
        else if (Node.isEqual(n1: t.node[0], n2: dummynode)) { // hash part is empty?
            return Int(j) // that is easy...
        }
        else {
            return unbound_search(t: t, j: j)
        }
    }
    
    ///#if defined(LUA_DEBUG)
    
    //Node *luaH_mainposition (const Table *t, const TValue *key) {
    //  return mainposition(t, key);
    //}
    
    //int luaH_isdummy (Node *n) { return n == dummynode; }
    
    ///#endif
}
