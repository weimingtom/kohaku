//package kurumi;

//
// ** $Id: lstring.c,v 2.8.1.1 2007/12/27 13:02:25 roberto Exp $
// ** String table (keeps all strings handled by Lua)
// ** See Copyright Notice in lua.h
//

//using lu_byte = System.Byte;

public class LuaString {
    public static func sizestring(s:TString!) -> Int {
        return (Int(s.len) + 1) * CLib.GetUnmanagedSize(t: ClassType(type: ClassType.TYPE_CHAR)) //char
    }
    
    public static func sizeudata(u:Udata!) -> Int {
        return Int(u.len)
    }
    
    public static func luaS_new(L:lua_State!, s:CharPtr!) -> TString! {
        return luaS_newlstr(L: L, str: s, l: CLib.strlen(str: s)) //(uint)
    }
    
    public static func luaS_newliteral(L:lua_State!, s:CharPtr!) -> TString! {
        return luaS_newlstr(L: L, str: s, l: CLib.strlen(str: s)) //(uint)
    }
    
    public static func luaS_fix(s:TString!) {
        var marked:Int8 = s.getTsv().marked // can't pass properties in as ref - lu_byte
        var marked_ref:[Int8] = [Int8](repeating: 0, count: 1)
        marked_ref[0] = marked
        _ = LuaGC.l_setbit(x: marked_ref, b: LuaGC.FIXEDBIT) //ref
        marked = marked_ref[0]
        s.getTsv().marked = marked
    }
    
    public static func luaS_resize(L:lua_State!, newsize:Int) {
        var newhash:[GCObject?]!
        var tb:stringtable!
        if (LuaState.G(L: L).gcstate == LuaGC.GCSsweepstring) {
            return // cannot resize during GC traverse
        }
        
        // todo: fix this up
        // I'm treating newhash as a regular C# array, but I need to allocate a dummy array
        // so that the garbage collector behaves identical to the C version.
        //newhash = luaM_newvector<GCObjectRef>(L, newsize);
        newhash = [GCObject?](repeating: nil, count: newsize)
        LuaMem.AddTotalBytes(L: L, num_bytes: newsize * CLib.GetUnmanagedSize(t: ClassType(type: ClassType.TYPE_GCOBJECTREF))); //typeof(GCObjectRef)
        
        tb = LuaState.G(L: L).strt;
        for i:Int in 0 ..< newsize {
            newhash[i] = nil
        }
        
        // rehash
        for i in 0 ..< tb.size {
            var p:GCObject! = tb.hash[i];
            while (p != nil) {
                // for each node in the list
                let next:GCObject! = p.getGch().next // save next
                let h:Int64 = LuaState.gco2ts(o: p).hash //uint - int
                let h1:Int = Int(CLib.lmod(a: Double(h), b: Double(newsize))) // new position
                LuaLimits.lua_assert(c: Int(Int(h) % newsize) == CLib.lmod(a: Double(h), b: Double(newsize)))
                p.getGch().next = newhash[h1] // chain it
                newhash[h1] = p
                p = next
            }
        }
        //luaM_freearray(L, tb.hash);
        if (tb.hash != nil) {
            LuaMem.SubtractTotalBytes(L: L, num_bytes: tb.hash.count * CLib.GetUnmanagedSize(t: ClassType(type: ClassType.TYPE_GCOBJECTREF))); //typeof(GCObjectRef)
        }
        tb.size = newsize;
        tb.hash = newhash;
    }
    
    public static func newlstr(L:lua_State!, str:CharPtr!, l:Int, h:Int64) -> TString! { //uint - int - uint
        var h:Int64 = h
        var ts:TString!
        var tb:stringtable!
        if (l + 1 > LuaLimits.MAX_SIZET / CLib.GetUnmanagedSize(t: ClassType(type: ClassType.TYPE_CHAR))) { //typeof(char)
            _ = LuaMem.luaM_toobig(L: L)
        }
        ts = TString(str: CharPtr.toCharPtr(chars: [Character](repeating: "\0", count: l + 1)))
        LuaMem.AddTotalBytes(L: L, num_bytes: Int((l + 1) * CLib.GetUnmanagedSize(t: ClassType(type: ClassType.TYPE_CHAR)) + CLib.GetUnmanagedSize(t: ClassType(type: ClassType.TYPE_TSTRING)))) //typeof(TString)//typeof(char)
        ts.getTsv().len = l
        ts.getTsv().hash = h
        ts.getTsv().marked = LuaGC.luaC_white(g: LuaState.G(L: L))
        ts.getTsv().tt = Int8(Lua.LUA_TSTRING)
        ts.getTsv().reserved = 0
        //memcpy(ts+1, str, l*GetUnmanagedSize(typeof(char)));
        CLib.memcpy_char(dst: ts.str.chars, src: str.chars, srcofs: str.index, length: Int(l))
        ts.str.set(offset: l, val: "\0") // ending 0
        tb = LuaState.G(L: L).strt
        h = CLib.lmod(a: Double(h), b: Double(tb.size)) //uint
        ts.getTsv().next = tb.hash[Int(h)] // chain new entry
        tb.hash[Int(h)] = LuaState.obj2gco(v: ts)
        tb.nuse += 1
        if ((tb.nuse > Int(tb.size)) && (tb.size <= LuaLimits.MAX_INT / 2)) {
            luaS_resize(L: L, newsize: tb.size * 2) // too crowded
        }
        return ts
    }
    
    public static func luaS_newlstr(L:lua_State!, str:CharPtr!, l:Int) -> TString! { //uint
        var o:GCObject!
        //FIXME:
        var h:Int64 = Int64(l) & 0xffffffff // seed  - (uint) - uint - int
        let step:Int = (l >> 5) + 1 // if string is too long, don't hash all its chars  - uint
        var l1:Int = l
        while (l1 >= step) {
            //FIXME:
            // compute h
            let _h1:Int64 = Int64(ClassType.charToByte(ch: str.get(offset: l1 - 1)))
            let _h2:Int64 = ((h << 5)+(h >> 2) + _h1)
            h = (0xffffffff) & (Int64(h ^ _h2))
            l1 -= step
        }
        o = LuaState.G(L: L).strt.hash[Int(CLib.lmod(a: Double(h), b: Double(LuaState.G(L: L).strt.size)))]
        while (o != nil) {
            let ts:TString! = LuaState.rawgco2ts(o: o)
            if (ts.getTsv().len == l && (CLib.memcmp(ptr1: str, ptr2: LuaObject.getstr(ts: ts), size: l) == 0)) {
                // string may be dead
                if (LuaGC.isdead(g: LuaState.G(L: L), v: o)) {
                    LuaGC.changewhite(x: o)
                }
                return ts
            }
            o = o.getGch().next
        }
        //return newlstr(L, str, l, h);  /* not found */
        let res:TString! = newlstr(L: L, str: str, l: l, h: h)
        return res
    }
    
    public static func luaS_newudata(L:lua_State!, s:Int, e:Table!) -> Udata! { //uint
        let u:Udata! = Udata()
        u.uv.marked = LuaGC.luaC_white(g: LuaState.G(L: L)) // is not finalized
        u.uv.tt = Int8(Lua.LUA_TUSERDATA)
        u.uv.len = s
        u.uv.metatable = nil
        u.uv.env = e
        u.user_data = [Int8](repeating: 0, count: s)
        // chain it on udata list (after main thread)
        u.uv.next = LuaState.G(L: L).mainthread.next
        LuaState.G(L: L).mainthread.next = LuaState.obj2gco(v: u)
        return u
    }
    
    public static func luaS_newudata(L:lua_State!, t:ClassType!, e:Table!) -> Udata! {
        let u:Udata! = Udata()
        u.uv.marked = LuaGC.luaC_white(g: LuaState.G(L: L)) // is not finalized
        u.uv.tt = Int8(Lua.LUA_TUSERDATA)
        u.uv.len = 0
        u.uv.metatable = nil
        u.uv.env = e
        u.user_data = LuaMem.luaM_realloc_(L: L, t: t);
        LuaMem.AddTotalBytes(L: L, num_bytes: CLib.GetUnmanagedSize(t: ClassType(type: ClassType.TYPE_UDATA))) //typeof(Udata)
        // chain it on udata list (after main thread)
        u.uv.next = LuaState.G(L: L).mainthread.next
        LuaState.G(L: L).mainthread.next = LuaState.obj2gco(v: u)
        return u
    }
}
