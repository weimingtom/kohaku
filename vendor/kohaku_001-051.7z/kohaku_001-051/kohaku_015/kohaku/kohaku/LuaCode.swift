public class LuaCode {

}

public class InstructionPtr {
    
}
