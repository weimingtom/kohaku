public class LuaConf {
    public static let LUA_IDSIZE:Int = 60
}

public class op_delegate {
    
}
