public class LuaObject {

}

public class TValue {
    
}

public class Table {
    
}

public class TString {
    
}

public class Proto {
    
}
