public class lua_State {
    
}

public class LuaState {

}

public class global_State {
    
}
