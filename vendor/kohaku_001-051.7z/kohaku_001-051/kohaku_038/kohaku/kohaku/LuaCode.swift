public class LuaCode {

}

public class InstructionPtr {
    
}

public enum UnOpr : Int {
    case OPR_MINUS
    case OPR_NOT
    case OPR_LEN
    case OPR_NOUNOPR
    
    public func getValue() -> Int {
        return self.rawValue
    }
    
    public static func forValue(value:Int) -> UnOpr {
        return UnOpr(rawValue: value)!
    }
}

/*
 ** grep "ORDER OPR" if you change these enums
 */
public enum BinOpr : Int {
    case OPR_ADD
    case OPR_SUB
    case OPR_MUL
    case OPR_DIV
    case OPR_MOD
    case OPR_POW
    case OPR_CONCAT
    case OPR_NE
    case OPR_EQ
    case OPR_LT
    case OPR_LE
    case OPR_GT
    case OPR_GE
    case OPR_AND
    case OPR_OR
    case OPR_NOBINOPR
    
    public func getValue() -> Int {
        return self.rawValue
    }
    
    public static func forValue(value:Int) -> BinOpr {
        return BinOpr(rawValue: value)!
    }
}
