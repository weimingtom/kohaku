//package kurumi;

//
// ** $Id: lgc.c,v 2.38.1.1 2007/12/27 13:02:25 roberto Exp $
// ** Garbage Collector
// ** See Copyright Notice in lua.h
//

//using lu_int32 = System.UInt32;
//using l_mem = System.Int32;
//using lu_mem = System.UInt32;
//using TValue = Lua.TValue;
//using StkId = TValue;
//using lu_byte = System.Byte;
//using Instruction = System.UInt32;

public class LuaGC {
    //
    //         ** Possible states of the Garbage Collector
    //
    public static let GCSpause:Int = 0
    public static let GCSpropagate:Int = 1
    public static let GCSsweepstring:Int = 2
    public static let GCSsweep:Int = 3
    public static let GCSfinalize:Int = 4

    //
    //         ** some userful bit tricks
    //
    public static func resetbits(x:[Int8]!, m:Int) -> Int { //lu_byte - ref
//        x[0] &= (byte)~m; //lu_byte
//        return x[0];
        return 0
    }
    
    public static func setbits(x:[Int8]!, m:Int) -> Int { //lu_byte - ref
//        x[0] |= (byte)m; //lu_byte
//        return x[0];
        return 0
    }
    
    public static func testbits(x:Int8, m:Int) -> Bool { //lu_byte
//        return (x & (byte)m) != 0; //lu_byte
        return false
    }
    
    public static func bitmask(b:Int) -> Int {
//        return 1 << b;
        return 0
    }
    
    public static func bit2mask(b1:Int, b2:Int) -> Int {
//        return (bitmask(b1) | bitmask(b2));
        return 0
    }
    
    public static func l_setbit(x:[Int8]!, b:Int) -> Int { //lu_byte - ref
//        return setbits(x, bitmask(b)); //ref
        return 0
    }
    
    public static func resetbit(x:[Int8]!, b:Int) -> Int { //lu_byte - ref
//        return resetbits(x, bitmask(b)); //ref
        return 0
    }
    
    public static func testbit(x:Int8, b:Int) -> Bool { //lu_byte
//        return testbits(x, bitmask(b));
        return false
    }
    
    public static func set2bits(x:[Int8]!, b1:Int, b2:Int) -> Int { //lu_byte - ref
//        return setbits(x, (bit2mask(b1, b2))); //ref
        return 0
    }
    
    public static func reset2bits(x:[Int8]!, b1:Int, b2:Int) -> Int { //lu_byte - ref
//        return resetbits(x, (bit2mask(b1, b2))); //ref
        return 0
    }
    
    public static func test2bits(x:Int8, b1:Int, b2:Int) -> Bool { //lu_byte
//        return testbits(x, (bit2mask(b1, b2)));
        return false
    }
    
    //
    //         ** Layout for bit use in `marked' field:
    //         ** bit 0 - object is white (type 0)
    //         ** bit 1 - object is white (type 1)
    //         ** bit 2 - object is black
    //         ** bit 3 - for userdata: has been finalized
    //         ** bit 3 - for tables: has weak keys
    //         ** bit 4 - for tables: has weak values
    //         ** bit 5 - object is fixed (should not be collected)
    //         ** bit 6 - object is "super" fixed (only the main thread)
    //
    public static let WHITE0BIT:Int = 0
    public static let WHITE1BIT:Int = 1
    public static let BLACKBIT:Int = 2
    public static let FINALIZEDBIT:Int = 3
    public static let KEYWEAKBIT:Int = 3
    public static let VALUEWEAKBIT:Int = 4
    public static let FIXEDBIT:Int = 5
    public static let SFIXEDBIT:Int = 6
    public static let WHITEBITS:Int = bit2mask(b1: WHITE0BIT, b2: WHITE1BIT)
    
    public static func iswhite(x:GCObject!) -> Bool {
//        return test2bits(x.getGch().marked, WHITE0BIT, WHITE1BIT);
        return false
    }

    public static func isblack(x:GCObject!) -> Bool {
//        return testbit(x.getGch().marked, BLACKBIT);
        return false
    }
    
    public static func isgray(x:GCObject!) -> Bool {
//        return (!isblack(x) && !iswhite(x));
        return false
    }
    
    public static func otherwhite(g:global_State!) -> Int {
//        return g.currentwhite ^ WHITEBITS;
        return 0
    }
    
    public static func isdead(g:global_State!, v:GCObject!) -> Bool {
//        return (v.getGch().marked & otherwhite(g) & WHITEBITS) != 0;
        return false
    }
    
    public static func changewhite(x:GCObject!) {
//        x.getGch().marked ^= (byte)WHITEBITS;
    }
    
    public static func gray2black(x:GCObject!) {
//        byte[] marked_ref = new byte[1];
//        LuaObject.GCheader gcheader = x.getGch();
//        marked_ref[0] = gcheader.marked;
//        l_setbit(marked_ref, BLACKBIT); //ref
//        gcheader.marked = marked_ref[0];
    }
    
    public static func valiswhite(x:TValue) -> Bool {
//        return (LuaObject.iscollectable(x) && iswhite(LuaObject.gcvalue(x)));
        return false
    }
    
    public static func luaC_white(g:global_State!) -> Int8 {
//        return (byte)(g.currentwhite & WHITEBITS);
        return 0
    }
    
    public static func luaC_checkGC(L:lua_State!) {
//        //condhardstacktests(luaD_reallocstack(L, L.stacksize - EXTRA_STACK - 1));
//        //luaD_reallocstack(L, L.stacksize - EXTRA_STACK - 1);
//        if (LuaState.G(L).totalbytes >= LuaState.G(L).GCthreshold) {
//        luaC_step(L);
//        }
    }
    
    public static func luaC_barrier(L:lua_State!, p:Any!, v:TValue!) {
//        if (valiswhite(v) && isblack(LuaState.obj2gco(p))) {
//        luaC_barrierf(L, LuaState.obj2gco(p), LuaObject.gcvalue(v));
//        }
    }
    
    public static func luaC_barriert(L:lua_State!, t:Table!, v:TValue!) {
//        if (valiswhite(v) && isblack(LuaState.obj2gco(t))) {
//        luaC_barrierback(L, t);
//        }
    }
    
    public static func luaC_objbarrier(L:lua_State!, p:Any!, o:Any!) {
//        if (iswhite(LuaState.obj2gco(o)) && isblack(LuaState.obj2gco(p))) {
//        luaC_barrierf(L, LuaState.obj2gco(p), LuaState.obj2gco(o));
//        }
    }
    
    public static func luaC_objbarriert(L:lua_State!, t:Table!, o:Any!) {
//        if (iswhite(LuaState.obj2gco(o)) && isblack(LuaState.obj2gco(t))) {
//        luaC_barrierback(L, t);
//        }
    }
    
    public static let GCSTEPSIZE:Int = 1024 //uint
    public static let GCSWEEPMAX:Int = 40
    public static let GCSWEEPCOST:Int = 10
    public static let GCFINALIZECOST:Int = 100
    
    
    public static let maskmarks:Int8 = Int8(~(bitmask(b: BLACKBIT) | WHITEBITS))

    
    public static func makewhite(g:global_State!, x:GCObject!) {
//        x.getGch().marked = (byte)(x.getGch().marked & maskmarks | luaC_white(g));
    }
    
    public static func white2gray(x:GCObject!) {
//        byte[] marked_ref = new byte[1];
//        LuaObject.GCheader gcheader = x.getGch();
//        marked_ref[0] = gcheader.marked;
//        reset2bits(marked_ref, WHITE0BIT, WHITE1BIT); //ref
//        gcheader.marked = marked_ref[0];
    }
    
    public static func black2gray(x:GCObject!) {
//        byte[] marked_ref = new byte[1];
//        LuaObject.GCheader gcheader = x.getGch();
//        marked_ref[0] = gcheader.marked;
//        resetbit(marked_ref, BLACKBIT); //ref
//        gcheader.marked = marked_ref[0];
    }
    
    public static func stringmark(s:TString!) {
//        byte[] marked_ref = new byte[1];
//        LuaObject.GCheader gcheader = s.getGch();
//        marked_ref[0] = gcheader.marked;
//        reset2bits(marked_ref, WHITE0BIT, WHITE1BIT); //ref
//        gcheader.marked = marked_ref[0];
    }
    
    public static func isfinalized(u:Udata_uv!) -> Bool {
//        return testbit(u.marked, FINALIZEDBIT);
        return false
    }
    
    public static func markfinalized(u:Udata_uv!) {
//        byte marked = u.marked; // can't pass properties in as ref - lu_byte
//        byte[] marked_ref = new byte[1];
//        marked_ref[0] = marked;
//        l_setbit(marked_ref, FINALIZEDBIT); //ref
//        marked = marked_ref[0];
//        u.marked = marked;
    }
    
    public static var KEYWEAK:Int = bitmask(b: KEYWEAKBIT)
    public static var VALUEWEAK:Int = bitmask(b: VALUEWEAKBIT)
    
    public static func markvalue(g:global_State!, o:TValue!) {
//        LuaObject.checkconsistency(o);
//        if (LuaObject.iscollectable(o) && iswhite(LuaObject.gcvalue(o))) {
//        reallymarkobject(g, LuaObject.gcvalue(o));
//        }
    }
    
    public static func markobject(g:global_State!, t:Any!) {
//        if (iswhite(LuaState.obj2gco(t))) {
//        reallymarkobject(g, LuaState.obj2gco(t));
//        }
    }
    
    public static func setthreshold(g:global_State!) {
//        g.GCthreshold = ((g.estimate / 100) * g.gcpause); //(uint)
    }
    
    private static func removeentry(n:Node!) {
//        LuaLimits.lua_assert(LuaObject.ttisnil(LuaTable.gval(n)));
//        if (LuaObject.iscollectable(LuaTable.gkey(n))) {
//        LuaObject.setttype(LuaTable.gkey(n), LuaObject.LUA_TDEADKEY); // dead key; remove it
//        }
    }
    
    private static func reallymarkobject(g:global_State!, o:GCObject!) {
//        LuaLimits.lua_assert(iswhite(o) && !isdead(g, o));
//        white2gray(o);
//        switch (o.getGch().tt) {
//        case Lua.LUA_TSTRING: {
//        return;
//        }
//        case Lua.LUA_TUSERDATA: {
//        LuaObject.Table mt = LuaState.gco2u(o).metatable;
//        gray2black(o); // udata are never gray
//        if (mt != null) {
//        markobject(g, mt);
//        }
//        markobject(g, LuaState.gco2u(o).env);
//        return;
//        }
//        case LuaObject.LUA_TUPVAL: {
//        LuaObject.UpVal uv = LuaState.gco2uv(o);
//        markvalue(g, uv.v);
//        if (uv.v == uv.u.value) { // closed?
//        gray2black(o); // open upvalues are never black
//        }
//        return;
//        }
//        case Lua.LUA_TFUNCTION: {
//        LuaState.gco2cl(o).c.setGclist(g.gray);
//        g.gray = o;
//        break;
//        }
//        case Lua.LUA_TTABLE: {
//        LuaState.gco2h(o).gclist = g.gray;
//        g.gray = o;
//        break;
//        }
//        case Lua.LUA_TTHREAD: {
//        LuaState.gco2th(o).gclist = g.gray;
//        g.gray = o;
//        break;
//        }
//        case LuaObject.LUA_TPROTO: {
//        LuaState.gco2p(o).gclist = g.gray;
//        g.gray = o;
//        break;
//        }
//        default: {
//        LuaLimits.lua_assert(0);
//        break;
//        }
//        }
    }
    
    private static func marktmu(g:global_State!) {
//        LuaState.GCObject u = g.tmudata;
//        if (u != null) {
//        do {
//        u = u.getGch().next;
//        makewhite(g, u); // may be marked, if left from previous GC
//        reallymarkobject(g, u);
//        } while (u != g.tmudata);
//        }
    }
    
    // move `dead' udata that need finalization to list `tmudata'
    public static func luaC_separateudata(L:lua_State!, all:Int) -> Int { //uint
//        LuaState.global_State g = LuaState.G(L);
//        int deadmem = 0; //uint
//        LuaState.GCObjectRef p = new LuaState.NextRef(g.mainthread);
//        LuaState.GCObject curr;
//        while ((curr = p.get()) != null) {
//        if (!(iswhite(curr) || (all != 0)) || isfinalized(LuaState.gco2u(curr))) {
//        p = new LuaState.NextRef(curr.getGch()); // don't bother with them
//        }
//        else if (LuaTM.fasttm(L, LuaState.gco2u(curr).metatable, LuaTM.TMS.TM_GC) == null) {
//        markfinalized(LuaState.gco2u(curr)); // don't need finalization
//        p = new LuaState.NextRef(curr.getGch());
//        }
//        else {
//        // must call its gc method
//        deadmem += LuaString.sizeudata(LuaState.gco2u(curr)); //(uint)
//        markfinalized(LuaState.gco2u(curr));
//        p.set(curr.getGch().next);
//        // link `curr' at the end of `tmudata' list
//        if (g.tmudata == null) { // list is empty?
//        g.tmudata = curr.getGch().next = curr; // creates a circular list
//        }
//        else {
//        curr.getGch().next = g.tmudata.getGch().next;
//        g.tmudata.getGch().next = curr;
//        g.tmudata = curr;
//        }
//        }
//        }
//        return deadmem;
        return 0
    }
    
    private static func traversetable(g:global_State!, h:Table!) -> Int {
//        int i;
//        int weakkey = 0;
//        int weakvalue = 0;
//        //const
//        LuaObject.TValue mode;
//        if (h.metatable != null) {
//        markobject(g, h.metatable);
//        }
//        mode = LuaTM.gfasttm(g, h.metatable, LuaTM.TMS.TM_MODE);
//        if ((mode != null) && LuaObject.ttisstring(mode)) {
//        // is there a weak mode?
//        weakkey = (CLib.CharPtr.isNotEqual(CLib.strchr(LuaObject.svalue(mode), 'k'), null)) ? 1 : 0;
//        weakvalue = (CLib.CharPtr.isNotEqual(CLib.strchr(LuaObject.svalue(mode), 'v'), null)) ? 1 : 0;
//        if ((weakkey != 0) || (weakvalue != 0)) {
//        // is really weak?
//        h.marked &= (byte)~(KEYWEAK | VALUEWEAK); // clear bits
//        h.marked |= LuaLimits.cast_byte((weakkey << KEYWEAKBIT) | (weakvalue << VALUEWEAKBIT));
//        h.gclist = g.weak; // must be cleared after GC,...
//        g.weak = LuaState.obj2gco(h); //... so put in the appropriate list
//        }
//        }
//        if ((weakkey != 0) && (weakvalue != 0)) {
//        return 1;
//        }
//        if (weakvalue == 0) {
//        i = h.sizearray;
//        while ((i--) != 0) {
//        markvalue(g, h.array[i]);
//        }
//        }
//        i = LuaObject.sizenode(h);
//        while ((i--) != 0) {
//        LuaObject.Node n = LuaTable.gnode(h, i);
//        LuaLimits.lua_assert(LuaObject.ttype(LuaTable.gkey(n)) != LuaObject.LUA_TDEADKEY || LuaObject.ttisnil(LuaTable.gval(n)));
//        if (LuaObject.ttisnil(LuaTable.gval(n))) {
//        removeentry(n); // remove empty entries
//        }
//        else {
//        LuaLimits.lua_assert(LuaObject.ttisnil(LuaTable.gkey(n)));
//        if (weakkey == 0) {
//        markvalue(g, LuaTable.gkey(n));
//        }
//        if (weakvalue == 0) {
//        markvalue(g, LuaTable.gval(n));
//        }
//        }
//        }
//        return ((weakkey != 0) || (weakvalue != 0)) ? 1 : 0;
        return 0
    }
    
    //
    //         ** All marks are conditional because a GC may happen while the
    //         ** prototype is still being created
    //
    private static func traverseproto(g:global_State!, f:Proto!) {
//        int i;
//        if (f.source != null) {
//        stringmark(f.source);
//        }
//        for (i = 0; i < f.sizek; i++) { // mark literals
//        markvalue(g, f.k[i]);
//        }
//        for (i = 0; i < f.sizeupvalues; i++) {
//        // mark upvalue names
//        if (f.upvalues[i] != null) {
//        stringmark(f.upvalues[i]);
//        }
//        }
//        for (i = 0; i < f.sizep; i++) {
//        // mark nested protos
//        if (f.p[i] != null) {
//        markobject(g, f.p[i]);
//        }
//        }
//        for (i = 0; i < f.sizelocvars; i++) {
//        // mark local-variable names
//        if (f.locvars[i].varname != null) {
//        stringmark(f.locvars[i].varname);
//        }
//        }
    }
    
    private static func traverseclosure(g:global_State!, cl:Closure!) {
//        markobject(g, cl.c.getEnv());
//        if (cl.c.getIsC() != 0) {
//        int i;
//        for (i = 0; i < cl.c.getNupvalues(); i++) { // mark its upvalues
//        markvalue(g, cl.c.upvalue[i]);
//        }
//        }
//        else {
//        int i;
//        LuaLimits.lua_assert(cl.l.getNupvalues() == cl.l.p.nups);
//        markobject(g, cl.l.p);
//        for (i = 0; i < cl.l.getNupvalues(); i++) { // mark its upvalues
//        markobject(g, cl.l.upvals[i]);
//        }
//        }
    }
    
    private static func checkstacksizes(L:lua_State!, max:TValue!) { //StkId
//        int ci_used = LuaLimits.cast_int(LuaState.CallInfo.minus(L.ci, L.base_ci[0])); // number of `ci' in use
//        int s_used = LuaLimits.cast_int(LuaObject.TValue.minus(max, L.stack)); // part of stack in use
//        if (L.size_ci > LuaConf.LUAI_MAXCALLS) { // handling overflow?
//        return; // do not touch the stacks
//        }
//        if (4*ci_used < L.size_ci && 2*LuaState.BASIC_CI_SIZE < L.size_ci) {
//        LuaDo.luaD_reallocCI(L, L.size_ci / 2); // still big enough...
//        }
//        //condhardstacktests(luaD_reallocCI(L, ci_used + 1));
//        if (4*s_used < L.stacksize && 2 * (LuaState.BASIC_STACK_SIZE + LuaState.EXTRA_STACK) < L.stacksize) {
//        LuaDo.luaD_reallocstack(L, L.stacksize / 2); // still big enough...
//        }
//        //condhardstacktests(luaD_reallocstack(L, s_used));
    }
    
    private static func traversestack(g:global_State!, l:lua_State!) {
//        LuaObject.TValue[] o = new LuaObject.TValue[1]; //StkId
//        o[0] = new LuaObject.TValue();
//        LuaObject.TValue lim; //StkId
//        LuaState.CallInfo[] ci = new LuaState.CallInfo[1];
//        ci[0] = new LuaState.CallInfo();
//        markvalue(g, LuaState.gt(l));
//        lim = l.top;
//        for (ci[0] = l.base_ci[0]; LuaState.CallInfo.lessEqual(ci[0], l.ci); LuaState.CallInfo.inc(ci)) { //ref
//        LuaLimits.lua_assert(LuaObject.TValue.lessEqual(ci[0].top, l.stack_last));
//        if (LuaObject.TValue.lessThan(lim, ci[0].top)) {
//        lim = ci[0].top;
//        }
//        }
//        for (o[0] = l.stack[0]; LuaObject.TValue.lessThan(o[0], l.top); LuaObject.TValue.inc(o)) { //ref - StkId
//        markvalue(g, o[0]);
//        }
//        for (; LuaObject.TValue.lessEqual(o[0], lim); LuaObject.TValue.inc(o)) { //ref - StkId
//        LuaObject.setnilvalue(o[0]);
//        }
//        checkstacksizes(l, lim);
    }
    
    //
    //         ** traverse one gray object, turning it to black.
    //         ** Returns `quantity' traversed.
    //
    private static func propagatemark(g:global_State!) -> Int { //l_mem - Int32
//        LuaState.GCObject o = g.gray;
//        LuaLimits.lua_assert(isgray(o));
//        gray2black(o);
//        switch (o.getGch().tt) {
//        case Lua.LUA_TTABLE: {
//        LuaObject.Table h = LuaState.gco2h(o);
//        g.gray = h.gclist;
//        if (traversetable(g, h) != 0) { // table is weak?
//        black2gray(o); // keep it gray
//        }
//        return CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_TABLE)) + CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_TVALUE)) * h.sizearray + CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_NODE)) * LuaObject.sizenode(h); //typeof(Node) - typeof(TValue) - typeof(Table)
//        }
//        case Lua.LUA_TFUNCTION: {
//        LuaObject.Closure cl = LuaState.gco2cl(o);
//        g.gray = cl.c.getGclist();
//        traverseclosure(g, cl);
//        return (cl.c.getIsC() != 0) ? LuaFunc.sizeCclosure(cl.c.getNupvalues()) : LuaFunc.sizeLclosure(cl.l.getNupvalues());
//        }
//        case Lua.LUA_TTHREAD: {
//        LuaState.lua_State th = LuaState.gco2th(o);
//        g.gray = th.gclist;
//        th.gclist = g.grayagain;
//        g.grayagain = o;
//        black2gray(o);
//        traversestack(g, th);
//        //typeof(lua_State)
//        //typeof(TValue)
//        //typeof(CallInfo)
//        return CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_LUA_STATE)) + CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_TVALUE)) * th.stacksize + CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_CALLINFO)) * th.size_ci;
//        }
//        case LuaObject.LUA_TPROTO: {
//        LuaObject.Proto p = LuaState.gco2p(o);
//        g.gray = p.gclist;
//        traverseproto(g, p);
//        //typeof(Proto)
//        //typeof(long/*UInt32*//*Instruction*/)
//        //typeof(Proto)
//        //typeof(TValue)
//        //typeof(int)
//        //typeof(LocVar)
//        //typeof(TString)
//        return CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_PROTO)) + CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_LONG)) * p.sizecode + CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_PROTO)) * p.sizep + CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_TVALUE)) * p.sizek + CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_INT)) * p.sizelineinfo + CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_LOCVAR)) * p.sizelocvars + CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_TSTRING)) * p.sizeupvalues;
//        }
//        default: {
//        LuaLimits.lua_assert(0);
//        return 0;
//        }
//        }
        return 0
    }
    
    private static func propagateall(g:global_State!) -> Int { //uint
//        int m = 0; //uint
//        while (g.gray != null) {
//        m += propagatemark(g); //(uint)
//        }
//        return m;
        return 0
    }
    
    //
    //         ** The next function tells whether a key or value can be cleared from
    //         ** a weak table. Non-collectable objects are never removed from weak
    //         ** tables. Strings behave as `values', so are never removed too. for
    //         ** other objects: if really collected, cannot keep them; for userdata
    //         ** being finalized, keep them in keys, but not in values
    //
    private static func iscleared(o:TValue!, iskey:Bool) -> Bool {
//        if (!LuaObject.iscollectable(o)) {
//        return false;
//        }
//        if (LuaObject.ttisstring(o)) {
//        stringmark(LuaObject.rawtsvalue(o)); // strings are `values', so are never weak
//        return false;
//        }
//        return iswhite(LuaObject.gcvalue(o)) || (LuaObject.ttisuserdata(o) && (!iskey && isfinalized(LuaObject.uvalue(o))));
        return false
    }
    
    
    //
    //         ** clear collected entries from weaktables
    //
    private static func cleartable(l:GCObject!) {
//        while (l != null) {
//        LuaObject.Table h = LuaState.gco2h(l);
//        int i = h.sizearray;
//        LuaLimits.lua_assert(testbit(h.marked, VALUEWEAKBIT) || testbit(h.marked, KEYWEAKBIT));
//        if (testbit(h.marked, VALUEWEAKBIT)) {
//        while (i--!= 0) {
//        LuaObject.TValue o = h.array[i];
//        if (iscleared(o, false)) { // value was collected?
//        LuaObject.setnilvalue(o); // remove value
//        }
//        }
//        }
//        i = LuaObject.sizenode(h);
//        while (i-- != 0) {
//        LuaObject.Node n = LuaTable.gnode(h, i);
//        if (!LuaObject.ttisnil(LuaTable.gval(n)) && (iscleared(LuaTable.key2tval(n), true) || iscleared(LuaTable.gval(n), false))) { // non-empty entry?
//        LuaObject.setnilvalue(LuaTable.gval(n)); // remove value...
//        removeentry(n); // remove entry from Table
//        }
//        }
//        l = h.gclist;
//        }
    }
    
    
    private static func freeobj(L:lua_State!, o:GCObject!) {
//        switch (o.getGch().tt) {
//        case LuaObject.LUA_TPROTO: {
//        LuaFunc.luaF_freeproto(L, LuaState.gco2p(o));
//        break;
//        }
//        case Lua.LUA_TFUNCTION: {
//        LuaFunc.luaF_freeclosure(L, LuaState.gco2cl(o));
//        break;
//        }
//        case LuaObject.LUA_TUPVAL: {
//        LuaFunc.luaF_freeupval(L, LuaState.gco2uv(o));
//        break;
//        }
//        case Lua.LUA_TTABLE: {
//        LuaTable.luaH_free(L, LuaState.gco2h(o));
//        break;
//        }
//        case Lua.LUA_TTHREAD: {
//        LuaLimits.lua_assert(LuaState.gco2th(o) != L && LuaState.gco2th(o) != LuaState.G(L).mainthread);
//        LuaState.luaE_freethread(L, LuaState.gco2th(o));
//        break;
//        }
//        case Lua.LUA_TSTRING: {
//        LuaState.G(L).strt.nuse--;
//        LuaMem.SubtractTotalBytes(L, LuaString.sizestring(LuaState.gco2ts(o)));
//        LuaMem.luaM_freemem_TString(L, LuaState.gco2ts(o), new ClassType(ClassType.TYPE_TSTRING));
//        break;
//        }
//        case Lua.LUA_TUSERDATA: {
//        LuaMem.SubtractTotalBytes(L, LuaString.sizeudata(LuaState.gco2u(o)));
//        LuaMem.luaM_freemem_Udata(L, LuaState.gco2u(o), new ClassType(ClassType.TYPE_UDATA));
//        break;
//        }
//        default: {
//        LuaLimits.lua_assert(0);
//        break;
//        }
//        }
    }
    
    public static func sweepwholelist(L:lua_State!, p:GCObjectRef!) {
//        sweeplist(L, p, LuaLimits.MAX_LUMEM);
    }
    
    private static func sweeplist(L:lua_State!, p:GCObjectRef!, count:Int64) -> GCObjectRef! { //lu_mem - UInt32
//        LuaState.GCObject curr;
//        LuaState.global_State g = LuaState.G(L);
//        int deadmask = otherwhite(g);
//        while ((curr = p.get()) != null && count-- > 0) {
//        if (curr.getGch().tt == Lua.LUA_TTHREAD) { // sweep open upvalues of each thread
//        sweepwholelist(L, new LuaState.OpenValRef(LuaState.gco2th(curr)));
//        }
//        if (((curr.getGch().marked ^ WHITEBITS) & deadmask) != 0) {
//        // not dead?
//        LuaLimits.lua_assert(isdead(g, curr) || testbit(curr.getGch().marked, FIXEDBIT));
//        makewhite(g, curr); // make it white (for next cycle)
//        p = new LuaState.NextRef(curr.getGch());
//        }
//        else {
//        // must erase `curr'
//        LuaLimits.lua_assert(isdead(g, curr) || deadmask == bitmask(SFIXEDBIT));
//        p.set(curr.getGch().next);
//        if (curr == g.rootgc) { // is the first element of the list?
//        g.rootgc = curr.getGch().next; // adjust first
//        }
//        freeobj(L, curr);
//        }
//        }
//        return p;
        return nil
    }
    
    private static func checkSizes(L:lua_State!) {
//        LuaState.global_State g = LuaState.G(L);
//        // check size of string hash
//        if (g.strt.nuse < (long)(g.strt.size / 4) && g.strt.size > LuaLimits.MINSTRTABSIZE * 2) { //lu_int32 - UInt32
//        LuaString.luaS_resize(L, g.strt.size / 2); // table is too big
//        }
//        // check size of buffer
//        if (LuaZIO.luaZ_sizebuffer(g.buff) > LuaLimits.LUA_MINBUFFER * 2) {
//        // buffer too big?
//        int newsize = LuaZIO.luaZ_sizebuffer(g.buff) / 2; //uint
//        LuaZIO.luaZ_resizebuffer(L, g.buff, newsize); //(int)
//        }
    }
    
    private static func GCTM(L:lua_State!) {
//        LuaState.global_State g = LuaState.G(L);
//        LuaState.GCObject o = g.tmudata.getGch().next; // get first element
//        LuaObject.Udata udata = LuaState.rawgco2u(o);
//        LuaObject.TValue tm;
//        // remove udata from `tmudata'
//        if (o == g.tmudata) { // last element?
//        g.tmudata = null;
//        }
//        else {
//        g.tmudata.getGch().next = udata.uv.next;
//        }
//        udata.uv.next = g.mainthread.next; // return it to `root' list
//        g.mainthread.next = o;
//        makewhite(g, o);
//        tm = LuaTM.fasttm(L, udata.uv.metatable, LuaTM.TMS.TM_GC);
//        if (tm != null) {
//        byte oldah = L.allowhook; //lu_byte
//        long oldt = (long)g.GCthreshold; //lu_mem - UInt32 - lu_mem - UInt32
//        L.allowhook = 0; // stop debug hooks during GC tag method
//        g.GCthreshold = 2*g.totalbytes; // avoid GC steps
//        LuaObject.setobj2s(L, L.top, tm);
//        LuaObject.setuvalue(L, LuaObject.TValue.plus(L.top, 1), udata);
//        L.top = LuaObject.TValue.plus(L.top, 2);
//        LuaDo.luaD_call(L, LuaObject.TValue.minus(L.top, 2), 0);
//        L.allowhook = oldah; // restore hooks
//        g.GCthreshold = oldt; // restore threshold  - (uint)
//        }
    }
    
    //
    //         ** Call all GC tag methods
    //
    public static func luaC_callGCTM(L:lua_State!) {
//        while (LuaState.G(L).tmudata != null) {
//        GCTM(L);
//        }
    }
    
    public static func luaC_freeall(L:lua_State!) {
//        LuaState.global_State g = LuaState.G(L);
//        int i;
//        g.currentwhite = (byte)(WHITEBITS | bitmask(SFIXEDBIT)); // mask to collect all elements
//        sweepwholelist(L, new LuaState.RootGCRef(g));
//        for (i = 0; i < g.strt.size; i++) { // free all string lists
//        sweepwholelist(L, new LuaState.ArrayRef(g.strt.hash, i));
//        }
    }
    
    private static func markmt(g:global_State!) {
//        int i;
//        for (i = 0; i < LuaObject.NUM_TAGS; i++) {
//        if (g.mt[i] != null) {
//        markobject(g, g.mt[i]);
//        }
//        }
    }
    
    // mark root set
    private static func markroot(L:lua_State!) {
//        LuaState.global_State g = LuaState.G(L);
//        g.gray = null;
//        g.grayagain = null;
//        g.weak = null;
//        markobject(g, g.mainthread);
//        // make global table be traversed before main stack
//        markvalue(g, LuaState.gt(g.mainthread));
//        markvalue(g, LuaState.registry(L));
//        markmt(g);
//        g.gcstate = GCSpropagate;
    }
    
    private static func remarkupvals(g:global_State!) {
//        LuaObject.UpVal uv;
//        for (uv = g.uvhead.u.l.next; uv != g.uvhead; uv = uv.u.l.next) {
//        LuaLimits.lua_assert(uv.u.l.next.u.l.prev == uv && uv.u.l.prev.u.l.next == uv);
//        if (isgray(LuaState.obj2gco(uv))) {
//        markvalue(g, uv.v);
//        }
//        }
    }
    
    private static func atomic(L:lua_State!) {
//        LuaState.global_State g = LuaState.G(L);
//        int udsize; // total size of userdata to be finalized  - uint
//        // remark occasional upvalues of (maybe) dead threads
//        remarkupvals(g);
//        // traverse objects cautch by write barrier and by 'remarkupvals'
//        propagateall(g);
//        // remark weak tables
//        g.gray = g.weak;
//        g.weak = null;
//        LuaLimits.lua_assert(!iswhite(LuaState.obj2gco(g.mainthread)));
//        markobject(g, L); // mark running thread
//        markmt(g); // mark basic metatables (again)
//        propagateall(g);
//        // remark gray again
//        g.gray = g.grayagain;
//        g.grayagain = null;
//        propagateall(g);
//        udsize = luaC_separateudata(L, 0); // separate userdata to be finalized
//        marktmu(g); // mark `preserved' userdata
//        udsize += propagateall(g); // remark, to propagate `preserveness'
//        cleartable(g.weak); // remove collected objects from weak tables
//        // flip current white
//        g.currentwhite = LuaLimits.cast_byte(otherwhite(g));
//        g.sweepstrgc = 0;
//        g.sweepgc = new LuaState.RootGCRef(g);
//        g.gcstate = GCSsweepstring;
//        g.estimate = g.totalbytes - udsize; // first estimate
    }
    
    
    private static func singlestep(L:lua_State!) -> Int { //l_mem - Int32
//        LuaState.global_State g = LuaState.G(L);
//        //lua_checkmemory(L);
//        switch (g.gcstate) {
//        case GCSpause: {
//        markroot(L); // start a new collection
//        return 0;
//        }
//        case GCSpropagate: {
//        if (g.gray != null) {
//        return propagatemark(g);
//        }
//        else {
//        // no more `gray' objects
//        atomic(L); // finish mark phase
//        return 0;
//        }
//        }
//        case GCSsweepstring: {
//        long old = (long)g.totalbytes; //lu_mem - UInt32 - lu_mem - UInt32
//        sweepwholelist(L, new LuaState.ArrayRef(g.strt.hash, g.sweepstrgc++));
//        if (g.sweepstrgc >= g.strt.size) { // nothing more to sweep?
//        g.gcstate = GCSsweep; // end sweep-string phase
//        }
//        LuaLimits.lua_assert(old >= g.totalbytes);
//        g.estimate -= (old - g.totalbytes); //(uint)
//        return GCSWEEPCOST;
//        }
//        case GCSsweep: {
//        long old = (long)g.totalbytes; //lu_mem - UInt32 - lu_mem - UInt32
//        g.sweepgc = sweeplist(L, g.sweepgc, GCSWEEPMAX);
//        if (g.sweepgc.get() == null) {
//        // nothing more to sweep?
//        checkSizes(L);
//        g.gcstate = GCSfinalize; // end sweep phase
//        }
//        LuaLimits.lua_assert(old >= g.totalbytes);
//        g.estimate -= (old - g.totalbytes); //(uint)
//        return GCSWEEPMAX*GCSWEEPCOST;
//        }
//        case GCSfinalize: {
//        if (g.tmudata != null) {
//        GCTM(L);
//        if (g.estimate > GCFINALIZECOST) {
//        g.estimate -= GCFINALIZECOST;
//        }
//        return GCFINALIZECOST;
//        }
//        else {
//        g.gcstate = GCSpause; // end collection
//        g.gcdept = 0;
//        return 0;
//        }
//        }
//        default: {
//        LuaLimits.lua_assert(0);
//        return 0;
//        }
//        }
        return 0
    }
    
    public static func luaC_step(L:lua_State!) {
//        LuaState.global_State g = LuaState.G(L);
//        int lim = (int)((GCSTEPSIZE / 100) * g.gcstepmul); //l_mem - Int32 - l_mem - Int32
//        if (lim == 0) {
//        lim = (int)((LuaLimits.MAX_LUMEM - 1) / 2); // no limit  - l_mem - Int32
//        }
//        g.gcdept += g.totalbytes - g.GCthreshold;
//        do {
//        lim -= singlestep(L);
//        if (g.gcstate == GCSpause) {
//        break;
//        }
//        } while (lim > 0);
//        if (g.gcstate != GCSpause) {
//        if (g.gcdept < GCSTEPSIZE) {
//        g.GCthreshold = g.totalbytes + GCSTEPSIZE; // - lim/g.gcstepmul;
//        }
//        else {
//        g.gcdept -= GCSTEPSIZE;
//        g.GCthreshold = g.totalbytes;
//        }
//        }
//        else {
//        LuaLimits.lua_assert(g.totalbytes >= g.estimate);
//        setthreshold(g);
//        }
    }
    
    public static func luaC_fullgc(L:lua_State!) {
//        LuaState.global_State g = LuaState.G(L);
//        if (g.gcstate <= GCSpropagate) {
//        // reset sweep marks to sweep all elements (returning them to white)
//        g.sweepstrgc = 0;
//        g.sweepgc = new LuaState.RootGCRef(g);
//        // reset other collector lists
//        g.gray = null;
//        g.grayagain = null;
//        g.weak = null;
//        g.gcstate = GCSsweepstring;
//        }
//        LuaLimits.lua_assert(g.gcstate != GCSpause && g.gcstate != GCSpropagate);
//        // finish any pending sweep phase
//        while (g.gcstate != GCSfinalize) {
//        LuaLimits.lua_assert(g.gcstate == GCSsweepstring || g.gcstate == GCSsweep);
//        singlestep(L);
//        }
//        markroot(L);
//        while (g.gcstate != GCSpause) {
//        singlestep(L);
//        }
//        setthreshold(g);
    }
    
    public static func luaC_barrierf(L:lua_State!, o:GCObject!, v:GCObject!) {
//        LuaState.global_State g = LuaState.G(L);
//        LuaLimits.lua_assert(isblack(o) && iswhite(v) && !isdead(g, v) && !isdead(g, o));
//        LuaLimits.lua_assert(g.gcstate != GCSfinalize && g.gcstate != GCSpause);
//        LuaLimits.lua_assert(LuaObject.ttype(o.getGch()) != Lua.LUA_TTABLE);
//        // must keep invariant?
//        if (g.gcstate == GCSpropagate) {
//        reallymarkobject(g, v); // restore invariant
//        }
//        else { // don't mind
//        makewhite(g, o); // mark as white just to avoid other barriers
//        }
    }
    
    
    public static func luaC_barrierback(L:lua_State!, t:Table!) {
//        LuaState.global_State g = LuaState.G(L);
//        LuaState.GCObject o = LuaState.obj2gco(t);
//        LuaLimits.lua_assert(isblack(o) && !isdead(g, o));
//        LuaLimits.lua_assert(g.gcstate != GCSfinalize && g.gcstate != GCSpause);
//        black2gray(o); // make table gray (again)
//        t.gclist = g.grayagain;
//        g.grayagain = o;
    }
    
    public static func luaC_link(L:lua_State!, o:GCObject!, tt:Int8) { //lu_byte
//        LuaState.global_State g = LuaState.G(L);
//        o.getGch().next = g.rootgc;
//        g.rootgc = o;
//        o.getGch().marked = luaC_white(g);
//        o.getGch().tt = tt;
    }
    
    public static func luaC_linkupval(L:lua_State!, uv:UpVal!) {
//        LuaState.global_State g = LuaState.G(L);
//        LuaState.GCObject o = LuaState.obj2gco(uv);
//        o.getGch().next = g.rootgc; // link upvalue into `rootgc' list
//        g.rootgc = o;
//        if (isgray(o)) {
//        if (g.gcstate == GCSpropagate) {
//        gray2black(o); // closed upvalues need barrier
//        luaC_barrier(L, uv, uv.v);
//        }
//        else {
//        // sweep phase: sweep it (turning it into white)
//        makewhite(g, o);
//        LuaLimits.lua_assert(g.gcstate != GCSfinalize && g.gcstate != GCSpause);
//        }
//        }
    }
}
