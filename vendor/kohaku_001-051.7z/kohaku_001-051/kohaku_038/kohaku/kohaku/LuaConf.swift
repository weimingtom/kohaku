public class LuaConf {
    public static let LUA_IDSIZE:Int = 60
    public static let LUA_MAXCAPTURES:Int = 32
    public static let LUA_INTFRMLEN:String = "l"
    public static let LUA_PROGNAME:String = "lua"
    public static let LUAI_MAXUPVALUES:Int = 60
    public static let LUAI_MAXVARS:Int = 200
    public static let LUAL_BUFFERSIZE:Int = 1024
}

public class op_delegate {
    
}
