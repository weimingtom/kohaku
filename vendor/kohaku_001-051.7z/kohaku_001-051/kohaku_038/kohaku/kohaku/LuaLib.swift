/*
 ** $Id: lualib.h,v 1.36.1.1 2007/12/27 13:02:25 roberto Exp $
 ** Lua standard libraries
 ** See Copyright Notice in lua.h
 */
//package kurumi;
//{
public class LuaLib {
    /* Key to file-handle type */
    public static let LUA_FILEHANDLE:String = "FILE*"
    
    public static let LUA_COLIBNAME:String = "coroutine"
    public static let LUA_TABLIBNAME:String = "table"
    public static let LUA_IOLIBNAME:String = "io"
    public static let LUA_OSLIBNAME:String = "os"
    public static let LUA_STRLIBNAME:String = "string"
    public static let LUA_MATHLIBNAME:String = "math"
    public static let LUA_DBLIBNAME:String = "debug"
    public static let LUA_LOADLIBNAME:String = "package"
}
//}

