public class CharPtr {
    public static func toCharPtr(str:String!) -> CharPtr! {
//        return new CharPtr(str);
        return nil
    }
    
    public static func toCharPtr(chars:[Character]!) -> CharPtr! {
//        return new CharPtr(str);
        return nil
    }
}

public class CLib {

}
