public class LuaDo {

}

public class lua_longjmp {
    
}

public protocol Pfunc {
    func exec(L:lua_State!, ud:Any!)
}
