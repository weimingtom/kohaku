//package kurumi;

public class StreamProxy {
    private static let TYPE_FILE:Int = 0
    private static let TYPE_STDOUT:Int = 1
    private static let TYPE_STDIN:Int = 2
    private static let TYPE_STDERR:Int = 3
    public var type:Int = StreamProxy.TYPE_FILE
    public var isOK:Bool = false
//    private RandomAccessFile _file = null;
    
    private init() {
        self.isOK = false
    }
    
    public init(path:String, modeStr:String) {
        self.isOK = false
//        try {
//            this._file = new RandomAccessFile(path, modeStr);
//            this.isOK = true;
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }
        self.type = StreamProxy.TYPE_FILE
    }
    
    public func Flush() {
        if (self.type == StreamProxy.TYPE_STDOUT) {
            //RandomAccessFile flush not need ?
        }
    }
    
    public func Close() {
        if (self.type == StreamProxy.TYPE_STDOUT) {
//            if (this._file != null) {
//                try {
//                    this._file.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//                this._file = null;
//            }
        }
    }
    
    
    public func Write(buffer:[UInt8]!, offset:Int, count:Int) {
        if (self.type == StreamProxy.TYPE_STDOUT) {
//            System.out.print(new String(buffer, offset, count));
        } else if (self.type == StreamProxy.TYPE_STDERR) {
//            System.err.print(new String(buffer, offset, count));
        } else if (self.type == StreamProxy.TYPE_FILE) {
//            if (this._file != null) {
//                try {
//                    this._file.writeBytes(new String(buffer, offset, count));
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
        } else {
            //FIXME:TODO
        }
    }
    
    
    public func Read(buffer:[UInt8]!, offset:Int, count:Int) -> Int {
        if (type == StreamProxy.TYPE_FILE) {
//            if (this._file != null) {
//                try {
//                    return this._file.read(buffer, offset, count);
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
        }
        return 0
    }
    
    
    public func Seek(offset:Int64, origin:Int) -> Int {
        if (type == StreamProxy.TYPE_FILE) {
//            if (this._file != null) {
//                //CLib.SEEK_SET,
//                //CLib.SEEK_CUR,
//                //CLib.SEEK_END
//                long pos = -1;
//                if (origin == CLib.SEEK_CUR) {
//                    pos = offset;
//                } else if (origin == CLib.SEEK_CUR) {
//                    try {
//                        pos = this._file.getFilePointer() + offset;
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                } else if (origin == CLib.SEEK_END) {
//                    try {
//                        pos = this._file.length() + offset;
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }
//                try {
//                    this._file.seek(pos);
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
        }
        return 0
    }

    
    public func ReadByte() -> Int {
        if (type == StreamProxy.TYPE_STDIN) {
//            try {
//                return System.in.read();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
            return 0
        } else if (type == StreamProxy.TYPE_FILE) {
//            if (this._file != null) {
//                try {
//                    return this._file.read();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
            return 0
        } else {
            return 0
        }
    }
    
    public func ungetc(c:Int) {
        if (type == StreamProxy.TYPE_FILE) {
//            if (this._file != null) {
//                try {
//                    this._file.seek(this._file.getFilePointer() - 1);
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
        }
    }
    
    
    public func getPosition() -> Int64 {
        if (type == StreamProxy.TYPE_FILE) {
//            if (this._file != null) {
//                try {
//                    return this._file.getFilePointer();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
        }
        return 0
    }
    
    public func isEof() -> Bool {
        if (type == StreamProxy.TYPE_FILE) {
//            if (this._file != null) {
//                try {
//                    return this._file.getFilePointer() >= this._file.length();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
        }
        return true
    }
    
    //--------------------------------------
    
    public static func tmpfile() -> StreamProxy {
        let result:StreamProxy = StreamProxy()
        return result;
    }
    
    public static func OpenStandardOutput() -> StreamProxy {
        let result:StreamProxy = StreamProxy()
        result.type = TYPE_STDOUT
        result.isOK = true
        return result
    }
    
    public static func OpenStandardInput() -> StreamProxy {
        let result:StreamProxy = StreamProxy()
        result.type = TYPE_STDIN
        result.isOK = true
        return result
    }
    
    public static func OpenStandardError() -> StreamProxy {
        let result:StreamProxy = StreamProxy()
        result.type = TYPE_STDERR
        result.isOK = true
        return result
    }
    
    public static func GetCurrentDirectory() -> String! {
//        File directory = new File("");
//        return directory.getAbsolutePath();
        return nil
    }
    
    public static func Delete(path:String!) {
//        new File(path).delete();
    }
    
    public static func Move(path1:String!, path2:String!) {
//        new File(path1).renameTo(new File(path2));
    }
    
    public static func GetTempFileName() -> String! {
//        try {
//            return File.createTempFile("abc", ".tmp").getAbsolutePath();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        return nil
    }
    
    public static func ReadLine() -> String! {
//        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
//        try {
//            return in.readLine();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        return nil
    }
    
    public static func Write(str:String) {
//        System.out.print(str);
    }
    
    public static func WriteLine() {
//        System.out.println();
    }

    public static func ErrorWrite(str:String) {
//        System.err.print(str);
//        System.err.flush();
    }
}
