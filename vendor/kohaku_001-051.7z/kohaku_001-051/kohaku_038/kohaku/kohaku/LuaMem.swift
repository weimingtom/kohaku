//package kurumi;

//
// ** $Id: lmem.c,v 1.70.1.1 2007/12/27 13:02:25 roberto Exp $
// ** Interface to Memory Manager
// ** See Copyright Notice in lua.h
//

public class LuaMem {
    public static let MEMERRMSG:String = "not enough memory"
    
    //-------------------------------
    
    public static func luaM_reallocv_char(L:lua_State!, block:[Character]!, new_size:Int, t:ClassType!) -> [Character]! {
//        return (char[])luaM_realloc__char(L, block, new_size, t);
        return nil
    }
    
    public static func luaM_reallocv_TValue(L:lua_State!, block:[TValue]!, new_size:Int, t:ClassType!) -> [TValue]! {
//        return (LuaObject.TValue[])luaM_realloc__TValue(L, block, new_size, t);
        return nil
    }
    
    public static func luaM_reallocv_TString(L:lua_State!, block:[TString]!, new_size:Int, t:ClassType!) -> [TString]! {
//        return (LuaObject.TString[])luaM_realloc__TString(L, block, new_size, t);
        return nil
    }
    
    public static func luaM_reallocv_CallInfo(L:lua_State!, block:[CallInfo]!, new_size:Int, t:ClassType!) -> [CallInfo]! {
//        return (LuaState.CallInfo[])luaM_realloc__CallInfo(L, block, new_size, t);
        return nil
    }
    
    public static func luaM_reallocv_long(L:lua_State!, block:[Int64]!, new_size:Int, t:ClassType!) -> [Int64]! {
//        return (long[])luaM_realloc__long(L, block, new_size, t);
        return nil
    }
    
    public static func luaM_reallocv_int(L:lua_State!, block:[Int]!, new_size:Int, t:ClassType!) -> [Int]! {
//        return (int[])luaM_realloc__int(L, block, new_size, t);
        return nil
    }
    
    public static func luaM_reallocv_Proto(L:lua_State!, block:[Proto]!, new_size:Int, t:ClassType!) -> [Proto]! {
//        return (LuaObject.Proto[])luaM_realloc__Proto(L, block, new_size, t);
        return nil
    }
    
    public static func luaM_reallocv_LocVar(L:lua_State!, block:[LocVar]!, new_size:Int, t:ClassType!) -> [LocVar]! {
//        return (LuaObject.LocVar[])luaM_realloc__LocVar(L, block, new_size, t);
        return nil
    }
    
    public static func luaM_reallocv_Node(L:lua_State!, block:[Node]!, new_size:Int, t:ClassType!) -> [Node]! {
//        return (LuaObject.Node[])luaM_realloc__Node(L, block, new_size, t);
        return nil
    }
    
    public static func luaM_reallocv_GCObject(L:lua_State!, block:[GCObject]!, new_size:Int, t:ClassType!) -> [GCObject]! {
//        return (LuaState.GCObject[])luaM_realloc__GCObject(L, block, new_size, t);
        return nil
    }
    
    //-------------------------------
    
    ///#define luaM_freemem(L, b, s)    luaM_realloc_(L, (b), (s), 0)
    ///#define luaM_free(L, b)        luaM_realloc_(L, (b), sizeof(*(b)), 0)
    //public static void luaM_freearray(lua_State L, object b, int n, Type t) { luaM_reallocv(L, b, n, 0, Marshal.SizeOf(b)); }
    
    // C# has it's own gc, so nothing to do here...in theory...
    public static func luaM_freemem_Udata(L:lua_State!, b:Udata!, t:ClassType!) {
//        luaM_realloc__Udata(L, new LuaObject.Udata[] {b}, 0, t);
    }
    
    public static func luaM_freemem_TString(L:lua_State!, b:TString!, t:ClassType!) {
//        luaM_realloc__TString(L, new LuaObject.TString[] { b }, 0, t);
    }
    
    //-------------------------------
    
    public static func luaM_free_Table(L:lua_State!, b:Table!, t:ClassType!) {
//        luaM_realloc__Table(L, new LuaObject.Table[] {b}, 0, t);
    }
    
    public static func luaM_free_UpVal(L:lua_State!, b:UpVal!, t:ClassType!) {
//        luaM_realloc__UpVal(L, new LuaObject.UpVal[] { b }, 0, t);
    }
    
    public static func luaM_free_Proto(L:lua_State!, b:Proto!, t:ClassType!) {
//        luaM_realloc__Proto(L, new LuaObject.Proto[] { b }, 0, t);
    }
    
    //-------------------------------
    
    public static func luaM_freearray_long(L:lua_State!, b:[Int64]!, t:ClassType!) {
//        luaM_reallocv_long(L, b, 0, t);
    }
    
    public static func luaM_freearray_Proto(L:lua_State!, b:[Proto]!, t:ClassType!) {
//        luaM_reallocv_Proto(L, b, 0, t);
    }
    
    public static func luaM_freearray_TValue(L:lua_State!, b:[TValue]!, t:ClassType!) {
//        luaM_reallocv_TValue(L, b, 0, t);
    }
    
    public static func luaM_freearray_int(L:lua_State!, b:[Int]!, t:ClassType!) {
//        luaM_reallocv_int(L, b, 0, t);
    }
    
    public static func luaM_freearray_LocVar(L:lua_State!, b:[LocVar]!, t:ClassType!) {
//        luaM_reallocv_LocVar(L, b, 0, t);
    }
    
    public static func luaM_freearray_TString(L:lua_State!, b:[TString]!, t:ClassType!) {
//        luaM_reallocv_TString(L, b, 0, t);
    }
    
    public static func luaM_freearray_Node(L:lua_State!, b:[Node]!, t:ClassType!) {
//        luaM_reallocv_Node(L, b, 0, t);
    }
    
    public static func luaM_freearray_CallInfo(L:lua_State!, b:[CallInfo]!, t:ClassType!) {
//        luaM_reallocv_CallInfo(L, b, 0, t);
    }
    
    public static func luaM_freearray_GCObject(L:lua_State!, b:[GCObject]!, t:ClassType!) {
//        luaM_reallocv_GCObject(L, b, 0, t);
    }
    
    //-------------------------------
    
    
    //public static T luaM_malloc<T>(lua_State L, ClassType t)
    //{
    //    return (T)luaM_realloc_<T>(L, t);
    //}
    
    public static func luaM_new_Proto(L:lua_State!, t:ClassType!) -> Proto! {
//        return (LuaObject.Proto)luaM_realloc__Proto(L, t);
        return nil
    }
    
    public static func luaM_new_Closure(L:lua_State!, t:ClassType!) -> Closure! {
//        return (LuaObject.Closure)luaM_realloc__Closure(L, t);
        return nil
    }
    
    public static func luaM_new_UpVal(L:lua_State!, t:ClassType!) -> UpVal! {
//        return (LuaObject.UpVal)luaM_realloc__UpVal(L, t);
        return nil
    }
    
    public static func luaM_new_lua_State(L:lua_State!, t:ClassType!) -> lua_State! {
//        return (LuaState.lua_State)luaM_realloc__lua_State(L, t);
        return nil
    }
    
    public static func luaM_new_Table(L:lua_State!, t:ClassType!) -> Table! {
//        return (LuaObject.Table)luaM_realloc__Table(L, t);
        return nil
    }
    
    
    //-------------------------------
    
    public static func luaM_newvector_long(L:lua_State!, n:Int, t:ClassType!) -> [Int64]! {
//        return luaM_reallocv_long(L, null, n, t);
        return nil
    }
    
    public static func luaM_newvector_TString(L:lua_State!, n:Int, t:ClassType!) -> [TString]! {
//        return luaM_reallocv_TString(L, null, n, t);
        return nil
    }
    
    public static func luaM_newvector_LocVar(L:lua_State!, n:Int, t:ClassType!) -> [LocVar]! {
//        return luaM_reallocv_LocVar(L, null, n, t);
        return nil
    }
    
    public static func luaM_newvector_int(L:lua_State!, n:Int, t:ClassType!) -> [Int]! {
//        return luaM_reallocv_int(L, null, n, t);
        return nil
    }
    
    public static func luaM_newvector_Proto(L:lua_State!, n:Int, t:ClassType!) -> [Proto]! {
//        return luaM_reallocv_Proto(L, null, n, t);
        return nil
    }
    
    public static func luaM_newvector_TValue(L:lua_State!, n:Int, t:ClassType!) -> [TValue]! {
//        return luaM_reallocv_TValue(L, null, n, t);
        return nil
    }
    
    public static func luaM_newvector_CallInfo(L:lua_State!, n:Int, t:ClassType!) -> [CallInfo]! {
//        return luaM_reallocv_CallInfo(L, null, n, t);
        return nil
    }
    
    public static func luaM_newvector_Node(L:lua_State!, n:Int, t:ClassType!) -> [Node]! {
//        return luaM_reallocv_Node(L, null, n, t);
        return nil
    }
    
    //-------------------------------
    
    
    
    
    
    
    
    public static func luaM_growvector_long(L:lua_State!, v:[[Int64]]!, nelems:Int, size:[Int]!, limit:Int, e:CharPtr!, t:ClassType!) { //ref - ref
//        if (nelems + 1 > size[0]) {
//        v[0] = (long[])luaM_growaux__long(L, v, size, limit, e, t); //ref - ref
//        }
    }
    
    public static func luaM_growvector_Proto(L:lua_State!, v:[[Proto]]!, nelems:Int, size:[Int]!, limit:Int, e:CharPtr!, t:ClassType!) { //ref - ref
//        if (nelems + 1 > size[0]) {
//        v[0] = (LuaObject.Proto[])luaM_growaux__Proto(L, v, size, limit, e, t); //ref - ref
//        }
    }
    
    public static func luaM_growvector_TString(L:lua_State!, v:[[TString]]!, nelems:Int, size:[Int]!, limit:Int, e:CharPtr!, t:ClassType!) { //ref - ref
//        if (nelems + 1 > size[0]) {
//        v[0] = (LuaObject.TString[])luaM_growaux__TString(L, v, size, limit, e, t); //ref - ref
//        }
    }
    
    public static func luaM_growvector_TValue(L:lua_State!, v:[[TValue]]!, nelems:Int, size:[Int]!, limit:Int, e:CharPtr!, t:ClassType!) { //ref - ref
//        if (nelems + 1 > size[0]) {
//        v[0] = (LuaObject.TValue[])luaM_growaux__TValue(L, v, size, limit, e, t); //ref - ref
//        }
    }
    
    public static func luaM_growvector_LocVar(L:lua_State!, v:[[LocVar]]!, nelems:Int, size:[Int]!, limit:Int, e:CharPtr!, t:ClassType!) { //ref - ref
//        if (nelems + 1 > size[0]) {
//        v[0] = (LuaObject.LocVar[])luaM_growaux__LocVar(L, v, size, limit, e, t); //ref - ref
//        }
    }
    
    public static func luaM_growvector_int(L:lua_State!, v:[[Int]]!, nelems:Int, size:[Int]!, limit:Int, e:CharPtr!, t:ClassType!) { //ref - ref
//        if (nelems + 1 > size[0]) {
//        v[0] = (int[])luaM_growaux__int(L, v, size, limit, e, t); //ref - ref
//        }
    }
    
    //-------------------------------
    
    
    
    public static func luaM_reallocvector_char(L:lua_State!, v:[[Character]]!, oldn:Int, n:Int, t:ClassType!) -> [Character]! { //ref
//        ClassType.Assert((v[0] == null && oldn == 0) || (v[0].length == oldn));
//        v[0] = luaM_reallocv_char(L, v[0], n, t);
//        return v[0];
        return nil
    }
    
    public static func luaM_reallocvector_TValue(L:lua_State!, v:[[TValue]]!, oldn:Int, n:Int, t:ClassType!) -> [TValue]! { //ref
//        ClassType.Assert((v[0] == null && oldn == 0) || (v[0].length == oldn));
//        v[0] = luaM_reallocv_TValue(L, v[0], n, t);
//        return v[0];
        return nil
    }
    
    public static func luaM_reallocvector_TString(L:lua_State!, v:[[TString]]!, oldn:Int, n:Int, t:ClassType!) -> [TString]! { //ref
//        ClassType.Assert((v[0] == null && oldn == 0) || (v[0].length == oldn));
//        v[0] = luaM_reallocv_TString(L, v[0], n, t);
//        return v[0];
        return nil
    }
    
    public static func luaM_reallocvector_CallInfo(L:lua_State!, v:[[CallInfo]]!, oldn:Int, n:Int, t:ClassType!) -> [CallInfo]! { //ref
//        ClassType.Assert((v[0] == null && oldn == 0) || (v[0].length == oldn));
//        v[0] = luaM_reallocv_CallInfo(L, v[0], n, t);
//        return v[0];
        return nil
    }
    
    public static func luaM_reallocvector_long(L:lua_State!, v:[[Int64]]!, oldn:Int, n:Int, t:ClassType!) -> [Int64]! { //ref
//        ClassType.Assert((v[0] == null && oldn == 0) || (v[0].length == oldn));
//        v[0] = luaM_reallocv_long(L, v[0], n, t);
//        return v[0];
        return nil
    }
    
    
    public static func luaM_reallocvector_int(L:lua_State!, v:[[Int]]!, oldn:Int, n:Int, t:ClassType!) -> [Int]! { //ref
//        ClassType.Assert((v[0] == null && oldn == 0) || (v[0].length == oldn));
//        v[0] = luaM_reallocv_int(L, v[0], n, t);
//        return v[0];
        return nil
    }
    
    public static func luaM_reallocvector_Proto(L:lua_State!, v:[[Proto]]!, oldn:Int, n:Int, t:ClassType!) -> [Proto]! { //ref
//        ClassType.Assert((v[0] == null && oldn == 0) || (v[0].length == oldn));
//        v[0] = luaM_reallocv_Proto(L, v[0], n, t);
//        return v[0];
        return nil
    }
    
    public static func luaM_reallocvector_LocVar(L:lua_State!, v:[[LocVar]]!, oldn:Int, n:Int, t:ClassType!) -> [LocVar]! { //ref
//        ClassType.Assert((v[0] == null && oldn == 0) || (v[0].length == oldn));
//        v[0] = luaM_reallocv_LocVar(L, v[0], n, t);
//        return v[0];
        return nil
    }
    
    //-------------------------------
    
    
    //
    //         ** About the realloc function:
    //         ** void * frealloc (void *ud, void *ptr, uint osize, uint nsize);
    //         ** (`osize' is the old size, `nsize' is the new size)
    //         **
    //         ** Lua ensures that (ptr == null) iff (osize == 0).
    //         **
    //         ** * frealloc(ud, null, 0, x) creates a new block of size `x'
    //         **
    //         ** * frealloc(ud, p, x, 0) frees the block `p'
    //         ** (in this specific case, frealloc must return null).
    //         ** particularly, frealloc(ud, null, 0, 0) does nothing
    //         ** (which is equivalent to free(null) in ANSI C)
    //         **
    //         ** frealloc returns null if it cannot create or reallocate the area
    //         ** (any reallocation to an equal or smaller size cannot fail!)
    //
    public static let MINSIZEARRAY:Int = 4
    
    
    
    public static func luaM_growaux__long(L:lua_State!, block:[[Int64]], size:[Int], limit:Int, errormsg:CharPtr!, t:ClassType!) -> [Int64]! { //ref - ref
//        long[] newblock;
//        int newsize;
//        if (size[0] >= limit / 2) {
//        // cannot double it?
//        if (size[0] >= limit) { // cannot grow even a little?
//        LuaDebug.luaG_runerror(L, errormsg);
//        }
//        newsize = limit; // still have at least one free place
//        }
//        else {
//        newsize = size[0] * 2;
//        if (newsize < MINSIZEARRAY) {
//        newsize = MINSIZEARRAY; // minimum size
//        }
//        }
//        newblock = luaM_reallocv_long(L, block[0], newsize, t);
//        size[0] = newsize; // update only when everything else is OK
//        return newblock;
        return nil
    }
    
    public static func luaM_growaux__Proto(L:lua_State!, block:[[Proto]], size:[Int], limit:Int, errormsg:CharPtr!, t:ClassType!) -> [Proto]! { //ref - ref
//        LuaObject.Proto[] newblock;
//        int newsize;
//        if (size[0] >= limit / 2) {
//        // cannot double it?
//        if (size[0] >= limit) { // cannot grow even a little?
//        LuaDebug.luaG_runerror(L, errormsg);
//        }
//        newsize = limit; // still have at least one free place
//        }
//        else {
//        newsize = size[0] * 2;
//        if (newsize < MINSIZEARRAY) {
//        newsize = MINSIZEARRAY; // minimum size
//        }
//        }
//        newblock = luaM_reallocv_Proto(L, block[0], newsize, t);
//        size[0] = newsize; // update only when everything else is OK
//        return newblock;
        return nil
    }
    
    public static func luaM_growaux__TString(L:lua_State!, block:[[Proto]], size:[Int], limit:Int, errormsg:CharPtr!, t:ClassType!) -> [Proto]! { //ref - ref
//        LuaObject.TString[] newblock;
//        int newsize;
//        if (size[0] >= limit / 2) {
//        // cannot double it?
//        if (size[0] >= limit) { // cannot grow even a little?
//        LuaDebug.luaG_runerror(L, errormsg);
//        }
//        newsize = limit; // still have at least one free place
//        }
//        else {
//        newsize = size[0] * 2;
//        if (newsize < MINSIZEARRAY) {
//        newsize = MINSIZEARRAY; // minimum size
//        }
//        }
//        newblock = luaM_reallocv_TString(L, block[0], newsize, t);
//        size[0] = newsize; // update only when everything else is OK
//        return newblock;
        return nil
    }
    
    public static func luaM_growaux__TValue(L:lua_State!, block:[[TValue]], size:[Int], limit:Int, errormsg:CharPtr!, t:ClassType!) -> [TValue]! { //ref - ref
//        LuaObject.TValue[] newblock;
//        int newsize;
//        if (size[0] >= limit / 2) {
//        // cannot double it?
//        if (size[0] >= limit) { // cannot grow even a little?
//        LuaDebug.luaG_runerror(L, errormsg);
//        }
//        newsize = limit; // still have at least one free place
//        }
//        else {
//        newsize = size[0] * 2;
//        if (newsize < MINSIZEARRAY) {
//        newsize = MINSIZEARRAY; // minimum size
//        }
//        }
//        newblock = luaM_reallocv_TValue(L, block[0], newsize, t);
//        size[0] = newsize; // update only when everything else is OK
//        return newblock;
        return nil
    }
    
    public static func luaM_growaux__LocVar(L:lua_State!, block:[[LocVar]], size:[Int], limit:Int, errormsg:CharPtr!, t:ClassType!) -> [LocVar]! { //ref - ref
//        LuaObject.LocVar[] newblock;
//        int newsize;
//        if (size[0] >= limit / 2) {
//        // cannot double it?
//        if (size[0] >= limit) { // cannot grow even a little?
//        LuaDebug.luaG_runerror(L, errormsg);
//        }
//        newsize = limit; // still have at least one free place
//        }
//        else {
//        newsize = size[0] * 2;
//        if (newsize < MINSIZEARRAY) {
//        newsize = MINSIZEARRAY; // minimum size
//        }
//        }
//        newblock = luaM_reallocv_LocVar(L, block[0], newsize, t);
//        size[0] = newsize; // update only when everything else is OK
//        return newblock;
        return nil
    }
    
    public static func luaM_growaux__int(L:lua_State!, block:[[Int]], size:[Int], limit:Int, errormsg:CharPtr!, t:ClassType!) -> [Int]! { //ref - ref
//        int[] newblock;
//        int newsize;
//        if (size[0] >= limit / 2) {
//        // cannot double it?
//        if (size[0] >= limit) { // cannot grow even a little?
//        LuaDebug.luaG_runerror(L, errormsg);
//        }
//        newsize = limit; // still have at least one free place
//        }
//        else {
//        newsize = size[0] * 2;
//        if (newsize < MINSIZEARRAY) {
//        newsize = MINSIZEARRAY; // minimum size
//        }
//        }
//        newblock = luaM_reallocv_int(L, block[0], newsize, t);
//        size[0] = newsize; // update only when everything else is OK
//        return newblock;
        return nil
    }
    
    //-------------------------------
    
    public static func luaM_toobig(L:lua_State!) -> Any! {
//        LuaDebug.luaG_runerror(L, CLib.CharPtr.toCharPtr("memory allocation error: block too big"));
//        return null; // to avoid warnings
        return nil
    }
    
    //
    //         ** generic allocation routine.
    //
    public static func luaM_realloc_(L:lua_State!, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)CLib.GetUnmanagedSize(t);
//        int nsize = unmanaged_size;
//        Object new_obj = t.Alloc();
//        AddTotalBytes(L, nsize);
//        return new_obj;
        return nil
    }
    
    public static func luaM_realloc__Proto(L:lua_State!, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int nsize = unmanaged_size;
//        LuaObject.Proto new_obj = (LuaObject.Proto)t.Alloc(); //System.Activator.CreateInstance(typeof(T));
//        AddTotalBytes(L, nsize);
//        return new_obj;
        return nil
    }
    
    public static func luaM_realloc__Closure(L:lua_State!, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int nsize = unmanaged_size;
//        LuaObject.Closure new_obj = (LuaObject.Closure)t.Alloc(); //System.Activator.CreateInstance(typeof(T));
//        AddTotalBytes(L, nsize);
//        return new_obj;
        return nil
    }
    
    public static func luaM_realloc__UpVal(L:lua_State!, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int nsize = unmanaged_size;
//        LuaObject.UpVal new_obj = (LuaObject.UpVal)t.Alloc(); //System.Activator.CreateInstance(typeof(T));
//        AddTotalBytes(L, nsize);
//        return new_obj;
        return nil
    }
    
    public static func luaM_realloc__lua_State(L:lua_State!, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int nsize = unmanaged_size;
//        LuaState.lua_State new_obj = (LuaState.lua_State)t.Alloc(); //System.Activator.CreateInstance(typeof(T));
//        AddTotalBytes(L, nsize);
//        return new_obj;
        return nil
    }
    
    public static func luaM_realloc__Table(L:lua_State!, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int nsize = unmanaged_size;
//        LuaObject.Table new_obj = (LuaObject.Table)t.Alloc(); //System.Activator.CreateInstance(typeof(T));
//        AddTotalBytes(L, nsize);
//        return new_obj;
        return nil
    }
    
    
    
    
    
    
    
    //---------------------------------
    
    
    //public static object luaM_realloc_<T>(lua_State L, T obj, ClassType t)
    //{
    //    int unmanaged_size = (int)t.GetUnmanagedSize();//CLib.GetUnmanagedSize(typeof(T))
    //    int old_size = (obj == null) ? 0 : unmanaged_size;
    //    int osize = old_size * unmanaged_size;
    //    int nsize = unmanaged_size;
    //   T new_obj = (T)t.Alloc(); //System.Activator.CreateInstance(typeof(T))
    //    SubtractTotalBytes(L, osize);
    //    AddTotalBytes(L, nsize);
    //    return new_obj;
    //}
    
    //public static object luaM_realloc_<T>(lua_State L, T[] old_block, int new_size, ClassType t)
    //{
    //    int unmanaged_size = (int)t.GetUnmanagedSize();//CLib.GetUnmanagedSize(typeof(T));
    //    int old_size = (old_block == null) ? 0 : old_block.Length;
    //    int osize = old_size * unmanaged_size;
    //    int nsize = new_size * unmanaged_size;
    //    T[] new_block = new T[new_size];
    //    for (int i = 0; i < Math.Min(old_size, new_size); i++)
    //    {
    //        new_block[i] = old_block[i];
    //    }
    //    for (int i = old_size; i < new_size; i++)
    //    {
    //       new_block[i] = (T)t.Alloc();// System.Activator.CreateInstance(typeof(T));
    //    }
    //    if (CanIndex(t))
    //    {
    //        for (int i = 0; i < new_size; i++)
    //        {
    //            ArrayElement elem = new_block[i] as ArrayElement;
    //            ClassType.Assert(elem != null, String.Format("Need to derive type {0} from ArrayElement", t.GetTypeString()));
    //            elem.set_index(i);
    //            elem.set_array(new_block);
    //        }
    //    }
    //    SubtractTotalBytes(L, osize);
    //    AddTotalBytes(L, nsize);
    //    return new_block;
    //}
    
    public static func luaM_realloc__Table(L:lua_State!, old_block:[Table]!, new_size:Int, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int old_size = (old_block == null) ? 0 : old_block.length;
//        int osize = old_size * unmanaged_size;
//        int nsize = new_size * unmanaged_size;
//        LuaObject.Table[] new_block = new LuaObject.Table[new_size];
//        for (int i = 0; i < Math.min(old_size, new_size); i++) {
//        new_block[i] = old_block[i];
//        }
//        for (int i = old_size; i < new_size; i++) {
//        new_block[i] = (LuaObject.Table)t.Alloc(); // System.Activator.CreateInstance(typeof(T));
//        }
//        if (CanIndex(t)) {
//        for (int i = 0; i < new_size; i++) {
//        LuaObject.ArrayElement elem = (LuaObject.ArrayElement)((new_block[i] instanceof LuaObject.ArrayElement) ? new_block[i] : null);
//        ClassType.Assert(elem != null, String.format("Need to derive type %1$s from ArrayElement", t.GetTypeString()));
//        elem.set_index(i);
//        elem.set_array(new_block);
//        }
//        }
//        SubtractTotalBytes(L, osize);
//        AddTotalBytes(L, nsize);
//        return new_block;
        return nil
    }
    
    public static func luaM_realloc__UpVal(L:lua_State!, old_block:[UpVal]!, new_size:Int, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int old_size = (old_block == null) ? 0 : old_block.length;
//        int osize = old_size * unmanaged_size;
//        int nsize = new_size * unmanaged_size;
//        LuaObject.UpVal[] new_block = new LuaObject.UpVal[new_size];
//        for (int i = 0; i < Math.min(old_size, new_size); i++) {
//        new_block[i] = old_block[i];
//        }
//        for (int i = old_size; i < new_size; i++) {
//        new_block[i] = (LuaObject.UpVal)t.Alloc(); // System.Activator.CreateInstance(typeof(T));
//        }
//        if (CanIndex(t)) {
//        for (int i = 0; i < new_size; i++) {
//        LuaObject.ArrayElement elem = (LuaObject.ArrayElement)((new_block[i] instanceof LuaObject.ArrayElement) ? new_block[i] : null);
//        ClassType.Assert(elem != null, String.format("Need to derive type %1$s from ArrayElement", t.GetTypeString()));
//        elem.set_index(i);
//        elem.set_array(new_block);
//        }
//        }
//        SubtractTotalBytes(L, osize);
//        AddTotalBytes(L, nsize);
//        return new_block;
        return nil
    }
    
    public static func luaM_realloc__char(L:lua_State!, old_block:[Character], new_size:Int, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int old_size = (old_block == null) ? 0 : old_block.length;
//        int osize = old_size * unmanaged_size;
//        int nsize = new_size * unmanaged_size;
//        char[] new_block = new char[new_size];
//        for (int i = 0; i < Math.min(old_size, new_size); i++) {
//        new_block[i] = old_block[i];
//        }
//        for (int i = old_size; i < new_size; i++) {
//        new_block[i] = ((Character)t.Alloc()).charValue(); // System.Activator.CreateInstance(typeof(T));
//        }
//        if (CanIndex(t)) { // FIXME:not necessary
//        //
//        //                for (int i = 0; i < new_size; i++)
//        //                {
//        //                    ArrayElement elem = new_block[i] as ArrayElement;
//        //                    ClassType.Assert(elem != null, String.Format("Need to derive type {0} from ArrayElement", t.GetTypeString()));
//        //                    elem.set_index(i);
//        //                    elem.set_array(new_block);
//        //                }
//        //
//        }
//        SubtractTotalBytes(L, osize);
//        AddTotalBytes(L, nsize);
//        return new_block;
        return nil
    }
    
    public static func luaM_realloc__TValue(L:lua_State!, old_block:[TValue]!, new_size:Int, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int old_size = (old_block == null) ? 0 : old_block.length;
//        int osize = old_size * unmanaged_size;
//        int nsize = new_size * unmanaged_size;
//        LuaObject.TValue[] new_block = new LuaObject.TValue[new_size];
//        for (int i = 0; i < Math.min(old_size, new_size); i++) {
//        new_block[i] = old_block[i];
//        }
//        for (int i = old_size; i < new_size; i++) {
//        new_block[i] = (LuaObject.TValue)t.Alloc(); // System.Activator.CreateInstance(typeof(T));
//        }
//        if (CanIndex(t)) {
//        for (int i = 0; i < new_size; i++) {
//        LuaObject.ArrayElement elem = (LuaObject.ArrayElement)((new_block[i] instanceof LuaObject.ArrayElement) ? new_block[i] : null);
//        ClassType.Assert(elem != null, String.format("Need to derive type %1$s from ArrayElement", t.GetTypeString()));
//        elem.set_index(i);
//        elem.set_array(new_block);
//        }
//        }
//        SubtractTotalBytes(L, osize);
//        AddTotalBytes(L, nsize);
//        return new_block;
        return nil
    }
    
    public static func luaM_realloc__TString(L:lua_State!, old_block:[TString]!, new_size:Int, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int old_size = (old_block == null) ? 0 : old_block.length;
//        int osize = old_size * unmanaged_size;
//        int nsize = new_size * unmanaged_size;
//        LuaObject.TString[] new_block = new LuaObject.TString[new_size];
//        for (int i = 0; i < Math.min(old_size, new_size); i++) {
//        new_block[i] = old_block[i];
//        }
//        for (int i = old_size; i < new_size; i++) {
//        new_block[i] = (LuaObject.TString)t.Alloc(); // System.Activator.CreateInstance(typeof(T));
//        }
//        if (CanIndex(t)) {
//        for (int i = 0; i < new_size; i++) {
//        LuaObject.ArrayElement elem = (LuaObject.ArrayElement)((new_block[i] instanceof LuaObject.ArrayElement) ? new_block[i] : null);
//        ClassType.Assert(elem != null, String.format("Need to derive type %1$s from ArrayElement", t.GetTypeString()));
//        elem.set_index(i);
//        elem.set_array(new_block);
//        }
//        }
//        SubtractTotalBytes(L, osize);
//        AddTotalBytes(L, nsize);
//        return new_block;
        return nil
    }
    
    public static func luaM_realloc__Udata(L:lua_State!, old_block:[Udata]!, new_size:Int, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int old_size = (old_block == null) ? 0 : old_block.length;
//        int osize = old_size * unmanaged_size;
//        int nsize = new_size * unmanaged_size;
//        LuaObject.Udata[] new_block = new LuaObject.Udata[new_size];
//        for (int i = 0; i < Math.min(old_size, new_size); i++) {
//        new_block[i] = old_block[i];
//        }
//        for (int i = old_size; i < new_size; i++) {
//        new_block[i] = (LuaObject.Udata)t.Alloc(); // System.Activator.CreateInstance(typeof(T));
//        }
//        if (CanIndex(t)) {
//        for (int i = 0; i < new_size; i++) {
//        LuaObject.ArrayElement elem = (LuaObject.ArrayElement)((new_block[i] instanceof LuaObject.ArrayElement) ? new_block[i] : null);
//        ClassType.Assert(elem != null, String.format("Need to derive type %1$s from ArrayElement", t.GetTypeString()));
//        elem.set_index(i);
//        elem.set_array(new_block);
//        }
//        }
//        SubtractTotalBytes(L, osize);
//        AddTotalBytes(L, nsize);
//        return new_block;
        return nil
    }
    
    public static func luaM_realloc__CallInfo(L:lua_State!, old_block:[CallInfo]!, new_size:Int, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int old_size = (old_block == null) ? 0 : old_block.length;
//        int osize = old_size * unmanaged_size;
//        int nsize = new_size * unmanaged_size;
//        LuaState.CallInfo[] new_block = new LuaState.CallInfo[new_size];
//        for (int i = 0; i < Math.min(old_size, new_size); i++) {
//        new_block[i] = old_block[i];
//        }
//        for (int i = old_size; i < new_size; i++) {
//        new_block[i] = (LuaState.CallInfo)t.Alloc(); // System.Activator.CreateInstance(typeof(T));
//        }
//        if (CanIndex(t)) {
//        for (int i = 0; i < new_size; i++) {
//        LuaObject.ArrayElement elem = (LuaObject.ArrayElement)((new_block[i] instanceof LuaObject.ArrayElement) ? new_block[i] : null);
//        ClassType.Assert(elem != null, String.format("Need to derive type %1$s from ArrayElement", t.GetTypeString()));
//        elem.set_index(i);
//        elem.set_array(new_block);
//        }
//        }
//        SubtractTotalBytes(L, osize);
//        AddTotalBytes(L, nsize);
//        return new_block;
        return nil
    }
    
    public static func luaM_realloc__long(L:lua_State!, old_block:[Int64]!, new_size:Int, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int old_size = (old_block == null) ? 0 : old_block.length;
//        int osize = old_size * unmanaged_size;
//        int nsize = new_size * unmanaged_size;
//        long[] new_block = new long[new_size];
//        for (int i = 0; i < Math.min(old_size, new_size); i++) {
//        new_block[i] = old_block[i];
//        }
//        for (int i = old_size; i < new_size; i++) {
//        new_block[i] = ((Long)t.Alloc()).longValue(); // System.Activator.CreateInstance(typeof(T));
//        }
//        if (CanIndex(t)) { //FIXME: not necessary
//        //
//        //                for (int i = 0; i < new_size; i++)
//        //                {
//        //                    ArrayElement elem = new_block[i] as ArrayElement;
//        //                    ClassType.Assert(elem != null, String.Format("Need to derive type {0} from ArrayElement", t.GetTypeString()));
//        //                    elem.set_index(i);
//        //                    elem.set_array(new_block);
//        //                }
//        //
//        }
//        SubtractTotalBytes(L, osize);
//        AddTotalBytes(L, nsize);
//        return new_block;
        return nil
    }
    
    public static func luaM_realloc__int(L:lua_State!, old_block:[Int]!, new_size:Int, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int old_size = (old_block == null) ? 0 : old_block.length;
//        int osize = old_size * unmanaged_size;
//        int nsize = new_size * unmanaged_size;
//        int[] new_block = new int[new_size];
//        for (int i = 0; i < Math.min(old_size, new_size); i++) {
//        new_block[i] = old_block[i];
//        }
//        for (int i = old_size; i < new_size; i++) {
//        new_block[i] = ((Integer)t.Alloc()).intValue(); // System.Activator.CreateInstance(typeof(T));
//        }
//        if (CanIndex(t)) { //FIXME: not necessary
//        //
//        //                for (int i = 0; i < new_size; i++)
//        //                {
//        //                    ArrayElement elem = new_block[i] as ArrayElement;
//        //                    ClassType.Assert(elem != null, String.Format("Need to derive type {0} from ArrayElement", t.GetTypeString()));
//        //                    elem.set_index(i);
//        //                    elem.set_array(new_block);
//        //                }
//        //
//        }
//        SubtractTotalBytes(L, osize);
//        AddTotalBytes(L, nsize);
//        return new_block;
        return nil
    }
    
    public static func luaM_realloc__Proto(L:lua_State!, old_block:[Proto]!, new_size:Int, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int old_size = (old_block == null) ? 0 : old_block.length;
//        int osize = old_size * unmanaged_size;
//        int nsize = new_size * unmanaged_size;
//        LuaObject.Proto[] new_block = new LuaObject.Proto[new_size];
//        for (int i = 0; i < Math.min(old_size, new_size); i++) {
//        new_block[i] = old_block[i];
//        }
//        for (int i = old_size; i < new_size; i++) {
//        new_block[i] = (LuaObject.Proto)t.Alloc(); // System.Activator.CreateInstance(typeof(T));
//        }
//        if (CanIndex(t)) {
//        for (int i = 0; i < new_size; i++) {
//        LuaObject.ArrayElement elem = (LuaObject.ArrayElement)((new_block[i] instanceof LuaObject.ArrayElement) ? new_block[i] : null);
//        ClassType.Assert(elem != null, String.format("Need to derive type %1$s from ArrayElement", t.GetTypeString()));
//        elem.set_index(i);
//        elem.set_array(new_block);
//        }
//        }
//        SubtractTotalBytes(L, osize);
//        AddTotalBytes(L, nsize);
//        return new_block;
        return nil
    }
    
    public static func luaM_realloc__LocVar(L:lua_State!, old_block:[LocVar]!, new_size:Int, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int old_size = (old_block == null) ? 0 : old_block.length;
//        int osize = old_size * unmanaged_size;
//        int nsize = new_size * unmanaged_size;
//        LuaObject.LocVar[] new_block = new LuaObject.LocVar[new_size];
//        for (int i = 0; i < Math.min(old_size, new_size); i++) {
//        new_block[i] = old_block[i];
//        }
//        for (int i = old_size; i < new_size; i++) {
//        new_block[i] = (LuaObject.LocVar)t.Alloc(); // System.Activator.CreateInstance(typeof(T));
//        }
//        if (CanIndex(t)) {
//        for (int i = 0; i < new_size; i++) {
//        LuaObject.ArrayElement elem = (LuaObject.ArrayElement)((new_block[i] instanceof LuaObject.ArrayElement) ? new_block[i] : null);
//        ClassType.Assert(elem != null, String.format("Need to derive type %1$s from ArrayElement", t.GetTypeString()));
//        elem.set_index(i);
//        elem.set_array(new_block);
//        }
//        }
//        SubtractTotalBytes(L, osize);
//        AddTotalBytes(L, nsize);
//        return new_block;
        return nil
    }
    
    public static func luaM_realloc__Node(L:lua_State!, old_block:[Node]!, new_size:Int, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int old_size = (old_block == null) ? 0 : old_block.length;
//        int osize = old_size * unmanaged_size;
//        int nsize = new_size * unmanaged_size;
//        LuaObject.Node[] new_block = new LuaObject.Node[new_size];
//        for (int i = 0; i < Math.min(old_size, new_size); i++) {
//        new_block[i] = old_block[i];
//        }
//        for (int i = old_size; i < new_size; i++) {
//        new_block[i] = (LuaObject.Node)t.Alloc(); // System.Activator.CreateInstance(typeof(T));
//        }
//        if (CanIndex(t)) {
//        for (int i = 0; i < new_size; i++) {
//        LuaObject.ArrayElement elem = (LuaObject.ArrayElement)((new_block[i] instanceof LuaObject.ArrayElement) ? new_block[i] : null);
//        ClassType.Assert(elem != null, String.format("Need to derive type %1$s from ArrayElement", t.GetTypeString()));
//        elem.set_index(i);
//        elem.set_array(new_block);
//        }
//        }
//        SubtractTotalBytes(L, osize);
//        AddTotalBytes(L, nsize);
//        return new_block;
        return nil
    }
    
    public static func luaM_realloc__GCObject(L:lua_State!, old_block:[GCObject]!, new_size:Int, t:ClassType!) -> Any! {
//        int unmanaged_size = (int)t.GetUnmanagedSize(); //CLib.GetUnmanagedSize(typeof(T));
//        int old_size = (old_block == null) ? 0 : old_block.length;
//        int osize = old_size * unmanaged_size;
//        int nsize = new_size * unmanaged_size;
//        LuaState.GCObject[] new_block = new LuaState.GCObject[new_size];
//        for (int i = 0; i < Math.min(old_size, new_size); i++) {
//        new_block[i] = old_block[i];
//        }
//        for (int i = old_size; i < new_size; i++) {
//        new_block[i] = (LuaState.GCObject)t.Alloc(); // System.Activator.CreateInstance(typeof(T));
//        }
//        if (CanIndex(t)) {
//        for (int i = 0; i < new_size; i++) {
//        LuaObject.ArrayElement elem = (LuaObject.ArrayElement)((new_block[i] instanceof LuaObject.ArrayElement) ? new_block[i] : null);
//        ClassType.Assert(elem != null, String.format("Need to derive type %1$s from ArrayElement", t.GetTypeString()));
//        elem.set_index(i);
//        elem.set_array(new_block);
//        }
//        }
//        SubtractTotalBytes(L, osize);
//        AddTotalBytes(L, nsize);
//        return new_block;
        return nil
    }
    
    
    public static func CanIndex(t:ClassType!) -> Bool {
//        return t.CanIndex();
        return false
    }
    
    public static func AddTotalBytes(L:lua_State!, num_bytes:Int) {
//        LuaState.G(L).totalbytes += (int)num_bytes; //uint
    }
    
    public static func SubtractTotalBytes(L:lua_State!, num_bytes:Int) {
//        LuaState.G(L).totalbytes -= (int)num_bytes; //uint
    }
    
    //static void AddTotalBytes(lua_State L, uint num_bytes) {G(L).totalbytes += num_bytes;}
    //static void SubtractTotalBytes(lua_State L, uint num_bytes) {G(L).totalbytes -= num_bytes;}
}
