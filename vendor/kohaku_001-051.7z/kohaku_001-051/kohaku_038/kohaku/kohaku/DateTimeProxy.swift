//package kurumi;

public class DateTimeProxy {
    //see https://github.com/weimingtom/mochalua/blob/master/Mochalua/src/com/groundspeak/mochalua/LuaOSLib.java
//    private Calendar _calendar;
    
    public init() {
//        this._calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
    }
    
    public init(year:Int, month:Int, day:Int, hour:Int, min:Int, sec:Int) {
//        this._calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
//        this._calendar.set(year, month, day, hour, min, sec);
    }
    
    public func setUTCNow() {
//        _calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
    }
    
    public func setNow() {
//        _calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
    }
    
    public func getSecond() -> Int {
//        return _calendar.get(Calendar.SECOND);
        return 0
    }
    
    public func getMinute() -> Int {
//        return _calendar.get(Calendar.MINUTE);
        return 0
    }
    
    public func getHour() -> Int {
//        return _calendar.get(Calendar.HOUR_OF_DAY);
        return 0
    }
    
    public func getDay() -> Int {
//        return _calendar.get(Calendar.DATE);
        return 0
    }
    
    public func getMonth() -> Int {
//        return _calendar.get(Calendar.MONTH) + 1;
        return 0
    }
    
    public func getYear() -> Int {
//        return _calendar.get(Calendar.YEAR);
        return 0
    }
    
    public func getDayOfWeek() -> Int {
//        return _calendar.get(Calendar.DAY_OF_WEEK);
        return 0
    }
    
    public func getDayOfYear() -> Int {
//        return _calendar.get(Calendar.DAY_OF_YEAR);
        return 0
    }
    
    //http://www.cnblogs.com/zyw-205520/p/4632490.html
    //https://github.com/anonl/luajpp2/blob/master/core/src/main/java/nl/weeaboo/lua2/lib/OsLib.java
    public func IsDaylightSavingTime() -> Bool {
//        return _calendar.get(Calendar.DST_OFFSET) != 0;
        return false
    }
    
    //https://github.com/weimingtom/mochalua/blob/master/Mochalua/src/com/groundspeak/mochalua/LuaOSLib.java
    public func getTicks() -> Double {
//        return _calendar.getTime().getTime();
        return 0
    }
    
    //https://github.com/anonl/luajpp2/blob/master/core/src/main/java/nl/weeaboo/lua2/lib/OsLib.java
//    private static final long _t0 = System.currentTimeMillis();
    public static func getClock() -> Double {
//        return (System.currentTimeMillis() - _t0) / 1000.;
        return 0
    }
}
