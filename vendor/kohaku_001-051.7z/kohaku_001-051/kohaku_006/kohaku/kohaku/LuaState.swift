public class lua_State {
    
}

public class LuaState {

}
