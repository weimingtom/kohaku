public class LuaConf {
    public static let LUA_IDSIZE:Int = 60
}
