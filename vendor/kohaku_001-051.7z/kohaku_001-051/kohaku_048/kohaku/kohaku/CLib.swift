//package kurumi;

public class CLib {
    // misc stuff needed for the compile
    
    public static func isalpha(c:Character) -> Bool {
//        return Character.isLetter(c);
        return false
    }
    
    public static func iscntrl(c:Character) -> Bool {
//    return Character.isISOControl(c);
        return false
    }
    
    public static func isdigit(c:Character) -> Bool {
//    return Character.isDigit(c);
        return false
    }
    
    public static func islower(c:Character) -> Bool {
//    return Character.isLowerCase(c);
        return false
    }
    
    public static func ispunct(c:Character) -> Bool {
//    return ClassType.IsPunctuation(c);
        return false
    }
    
    public static func isspace(c:Character) -> Bool {
//    return (c==' ') || (c>=(char)0x09 && c<=(char)0x0D);
        return false
    }
    
    public static func isupper(c:Character) -> Bool {
//    return Character.isUpperCase(c);
        return false
    }
    
    public static func isalnum(c:Character) -> Bool {
//    return Character.isLetterOrDigit(c);
        return false
    }
    
    public static func isxdigit(c:Character) -> Bool {
//    return (new String("0123456789ABCDEFabcdef")).indexOf(c) >= 0;
        return false
    }
    
    public static func isalpha(c:Int) -> Bool {
//    return Character.isLetter((char)c);
        return false
    }
    
    public static func iscntrl(c:Int) -> Bool {
//    return Character.isISOControl((char)c);
        return false
    }
    
    public static func isdigit(c:Int) -> Bool {
//    return Character.isDigit((char)c);
        return false
    }
    
    public static func islower(c:Int) -> Bool {
//    return Character.isLowerCase((char)c);
        return false
    }
    
    public static func ispunct(c:Int) -> Bool {
//    return ((char)c != ' ') && !isalnum((char)c);
        return false
    } // *not* the same as Char.IsPunctuation
    
    public static func isspace(c:Int) -> Bool {
//    return ((char)c == ' ') || ((char)c >= (char)0x09 && (char)c <= (char)0x0D);
        return false
    }
    
    public static func isupper(c:Int) -> Bool {
//    return Character.isUpperCase((char)c);
        return false
    }
    
    public static func isalnum(c:Int) -> Bool {
//    return Character.isLetterOrDigit((char)c);
        return false
    }
    
    public static func tolower(c:Character) -> Character {
//        return Character.toLowerCase(c);
        return Character("")
    }
    
    public static func toupper(c:Character) -> Character {
//    return Character.toUpperCase(c);
        return Character("")
    }
    
    public static func tolower(c:Int) -> Character {
//    return Character.toLowerCase((char)c);
        return Character("")
    }
    
    public static func toupper(c:Int) -> Character {
//    return Character.toUpperCase((char)c);
        return Character("")
    }
    
    
    public static func strtoul(s:CharPtr!, end:[CharPtr]!, base_:Int) -> Int64 { //out - ulong
//        try {
//        end[0] = new CharPtr(s.chars, s.index);
//
//        // skip over any leading whitespace
//        while (end[0].get(0) == ' ') {
//        end[0] = end[0].next();
//        }
//        
//        // ignore any leading 0x
//        if ((end[0].get(0) == '0') && (end[0].get(1) == 'x')) {
//        end[0] = end[0].next().next();
//        }
//        else if ((end[0].get(0) == '0') && (end[0].get(1) == 'X')) {
//        end[0] = end[0].next().next();
//        }
//        
//        // do we have a leading + or - sign?
//        boolean negate = false;
//        if (end[0].get(0) == '+') {
//        end[0] = end[0].next();
//        }
//        else if (end[0].get(0) == '-') {
//        negate = true;
//        end[0] = end[0].next();
//        }
//        
//        // loop through all chars
//        boolean invalid = false;
//        boolean had_digits = false;
//        long result = 0; //ulong
//        while (true) {
//        // get this char
//        char ch = end[0].get(0);
//        
//        // which digit is this?
//        int this_digit = 0;
//        if (isdigit(ch)) {
//        this_digit = ch - '0';
//        }
//        else if (isalpha(ch)) {
//        this_digit = tolower(ch) - 'a' + 10;
//        }
//        else {
//        break;
//        }
//        
//        // is this digit valid?
//        if (this_digit >= base_) {
//        invalid = true;
//        }
//        else {
//        had_digits = true;
//        result = result * (long)base_ + (long)this_digit; //ulong - ulong
//        }
//        
//        end[0] = end[0].next();
//        }
//        
//        // were any of the digits invalid?
//        if (invalid || (!had_digits)) {
//        end[0] = s;
//        return Long.MAX_VALUE; //Int64.MaxValue - UInt64.MaxValue
//        }
//        
//        // if the value was a negative then negate it here
//        if (negate) {
//        result = (long)-(long)result; //ulong
//        }
//        
//        // ok, we're done
//        return (long)result; //ulong
//        }
//        catch (java.lang.Exception e) {
//        end[0] = s;
//        return 0;
//        }
        return 0
    }
    
    public static func putchar(ch:Character) {
//    StreamProxy.Write("" + ch);
    }
    
    public static func putchar(ch:Int) {
//    StreamProxy.Write("" + (char)ch);
    }
    
    public static func isprint(c:Int8) -> Bool {
//    return (c >= (byte)' ') && (c <= (byte)127);
        return false
    }
    
    public static func parse_scanf(str:String!, fmt:CharPtr!, argp:Any!...) -> Int {
//        int parm_index = 0;
//        int index = 0;
//        while (fmt.get(index) != 0) {
//        if (fmt.get(index++) == '%') {
//        switch (fmt.get(index++)) {
//        case 's': {
//        argp[parm_index++] = str;
//        break;
//        }
//        case 'c': {
//        argp[parm_index++] = ClassType.ConvertToChar(str);
//        break;
//        }
//        case 'd': {
//        argp[parm_index++] = ClassType.ConvertToInt32(str);
//        break;
//        }
//        case 'l': {
//        argp[parm_index++] = ClassType.ConvertToDouble(str, null);
//        break;
//        }
//        case 'f': {
//        argp[parm_index++] = ClassType.ConvertToDouble(str, null);
//        break;
//        }
//        //case 'p':
//        //    {
//        //        result += "(pointer)";
//        //        break;
//        //    }
//        }
//        }
//        }
//        return parm_index;
        return 0
    }
    
    public static func printf(str:CharPtr!, argv:Any!...) {
//        Tools.printf(str.toString(), argv);
    }
    
    public static func sprintf(buffer:CharPtr!, str:CharPtr!, argv:Any!...) {
//        String temp = Tools.sprintf(str.toString(), argv);
//        strcpy(buffer, CharPtr.toCharPtr(temp));
    }
    
    public static func fprintf(stream:StreamProxy!, str:CharPtr!, argv:Any!...) -> Int {
//        String result = Tools.sprintf(str.toString(), argv);
//        char[] chars = result.toCharArray();
//        byte[] bytes = new byte[chars.length];
//        for (int i=0; i<chars.length; i++) {
//        bytes[i] = (byte)chars[i];
//        }
//        stream.Write(bytes, 0, bytes.length);
//        return 1;
        return 0
    }
    
    public static let EXIT_SUCCESS:Int = 0
    public static let EXIT_FAILURE:Int = 1
    
    public static func errno() -> Int {
        return -1; // todo: fix this - mjf
    }
    
    public static func strerror(error:Int) -> CharPtr! {
//        return CharPtr.toCharPtr(String.format("error #%1$s", error)); // todo: check how this works - mjf
    //FIXME:
        return nil
    }
    
    public static func getenv(envname:CharPtr!) -> CharPtr! {
//        // todo: fix this - mjf
//        //if (envname.Equals("LUA_PATH"))
//        //return "MyPath";
//        String result = System.getenv(envname.toString());
//        return result != null ? new CharPtr(result) : null;
        return nil
    }
}

public class CharPtr {
    public var chars:[Character]!
    public var index:Int = 0
    
    //public char this[int offset] get
    public func get(offset:Int) -> Character {
//        return chars[index + offset];
        return Character("")
    }
    
    //public char this[int offset] set
    public func set(offset:Int, val:Character) {
//        chars[index + offset] = val;
    }
    
    //public char this[long offset] get
    public func get(offset:Int64) -> Character {
//        return chars[index + (int)offset];
        return Character("")
    }
    
    //public char this[long offset] set
    public func set(offset:Int64, val:Character) {
//        chars[index + (int)offset] = val;
    }
    
    //implicit operator CharPtr
    public static func toCharPtr(str:String!) -> CharPtr! {
        //        return new CharPtr(str);
        return nil
    }
    
    //implicit operator CharPtr
    public static func toCharPtr(chars:[Character]!) -> CharPtr! {
        //        return new CharPtr(str);
        return nil
    }
    
    public init() {
//        this.chars = null;
//        this.index = 0;
    }
    
    public init(str:String!) {
//        this.chars = (str + '\0').toCharArray();
//        this.index = 0;
    }
    
    public init(ptr:CharPtr!) {
//    this.chars = ptr.chars;
//    this.index = ptr.index;
    }
    
    public init(ptr:CharPtr!, index:Int) {
//        this.chars = ptr.chars;
//        this.index = index;
    }
    
    public init(chars:[Character]!) {
//        this.chars = chars;
//        this.index = 0;
    }
    
    public init(chars:[Character]!, index:Int) {
//        this.chars = chars;
//        this.index = index;
    }
    
    //public CharPtr(IntPtr ptr)
    //{
    //    this.chars = new char[0];
    //    this.index = 0;
    //}
    
    public static func plus(ptr:CharPtr!, offset:Int) -> CharPtr! {
//        return new CharPtr(ptr.chars, ptr.index + offset);
        return nil
    }
    
    public static func minus(ptr:CharPtr!, offset:Int) -> CharPtr! {
//        return new CharPtr(ptr.chars, ptr.index - offset);
        return nil
    }
    
    public func inc() {
//        this.index++;
    }
    
    public func dec() {
//        this.index--;
    }
    
    public func next() -> CharPtr! {
//    return new CharPtr(this.chars, this.index + 1);
        return nil
    }
    
    public func prev() -> CharPtr! {
//        return new CharPtr(this.chars, this.index - 1);
        return nil
    }
    
    public func add(ofs:Int) -> CharPtr! {
//        return new CharPtr(this.chars, this.index + ofs);
        return nil
    }
    
    public func sub(ofs:Int) -> CharPtr! {
//        return new CharPtr(this.chars, this.index - ofs);
        return nil
    }
    
    //operator ==
    public static func isEqualChar(ptr:CharPtr!, ch:Character) -> Bool {
//        return ptr.get(0) == ch;
        return false
    }
    
    //operator ==
    public static func isEqualChar(ch:Character, ptr:CharPtr!) -> Bool {
//        return ptr.get(0) == ch;
        return false
    }
    
    //operator !=
    public static func isNotEqualChar(ptr:CharPtr!, ch:Character) -> Bool {
//        return ptr.get(0) != ch;
        return false
    }
    
    //operator !=
    public static func isNotEqualChar(ch:Character, ptr:CharPtr!) -> Bool {
//        return ptr.get(0) != ch;
        return false
    }
    
    public static func plus(ptr1:CharPtr!, ptr2:CharPtr!) -> CharPtr! {
//        String result = "";
//        for (int i = 0; ptr1.get(i) != '\0'; i++)
//        {
//        result += ptr1.get(i);
//        }
//        for (int i = 0; ptr2.get(i) != '\0'; i++)
//        {
//        result += ptr2.get(i);
//        }
//        return new CharPtr(result);
        return nil
    }
    
    public static func minus(ptr1:CharPtr!, ptr2:CharPtr!) -> Int {
//    ClassType.Assert(ptr1.chars == ptr2.chars); return ptr1.index - ptr2.index;
        return 0
    }
    
    //operator <
    public static func lessThan(ptr1:CharPtr!, ptr2:CharPtr!) -> Bool {
//    ClassType.Assert(ptr1.chars == ptr2.chars); return ptr1.index < ptr2.index;
        return false
    }
    //operator <=
    public static func lessEqual(ptr1:CharPtr!, ptr2:CharPtr!) -> Bool {
//    ClassType.Assert(ptr1.chars == ptr2.chars); return ptr1.index <= ptr2.index;
        return false
    }
    public static func greaterThan(ptr1:CharPtr!, ptr2:CharPtr!) -> Bool {
//    ClassType.Assert(ptr1.chars == ptr2.chars); return ptr1.index > ptr2.index;
        return false
    }
    //operator >=
    public static func greaterEqual(ptr1:CharPtr!, ptr2:CharPtr!) -> Bool {
//    ClassType.Assert(ptr1.chars == ptr2.chars); return ptr1.index >= ptr2.index;
        return false
    }
    
    //operator ==
    public static func isEqual(ptr1:CharPtr!, ptr2:Character) -> Bool {
//        Object o1 = (CharPtr)((ptr1 instanceof CharPtr) ? ptr1 : null);
//        Object o2 = (CharPtr)((ptr2 instanceof CharPtr) ? ptr2 : null);
//        if ((o1 == null) && (o2 == null))
//        {
//        return true;
//        }
//        if (o1 == null)
//        {
//        return false;
//        }
//        if (o2 == null)
//        {
//        return false;
//        }
//        return (ptr1.chars == ptr2.chars) && (ptr1.index == ptr2.index);
        return false
    }
    
    //operator !=
    public static func isNotEqual(ptr1:CharPtr!, ptr2:CharPtr!) -> Bool {
//        return !(CharPtr.isEqual(ptr1, ptr2));
        return false
    }
    
    //FIXME:
    //@Override
    public func equals(o:Any!) -> Bool {
//    return CharPtr.isEqual(this, ((CharPtr)((o instanceof CharPtr) ? o : null)));
        return false
    }
    
    //FIXME:
    //@Override
    public func hashCode() -> Int {
        return 0;
    }
    
    //FIXME:
    //@Override
    public func toString() -> String! {
//        String result = "";
//        for (int i = index; (i < chars.length) && (chars[i] != '\0'); i++)
//        {
//        result += chars[i];
//        }
//        return result;
        return nil
    }
    

}

extension CLib {
    
    //public static int memcmp(CharPtr ptr1, CharPtr ptr2, uint size)
    //{
    //    return memcmp(ptr1, ptr2, (int)size);
    //}
    
    public static func memcmp(ptr1:CharPtr!, ptr2:CharPtr!, size:Int) -> Int {
//        for (int i = 0; i < size; i++) {
//        if (ptr1.get(i) != ptr2.get(i)) {
//        if (ptr1.get(i) < ptr2.get(i)) {
//        return -1;
//        }
//        else {
//        return 1;
//        }
//        }
//        }
//        return 0;
        return 0
    }
    
    public static func memchr(ptr:CharPtr!, c:Character, count:Int) -> CharPtr! { //uint
//        for (int i = 0; i < count; i++) { //uint
//        if (ptr.get(i) == c) {
//        return new CharPtr(ptr.chars, (int)(ptr.index + i));
//        }
//        }
//        return null;
        return nil
    }
    
    public static func strpbrk(str:CharPtr!, charset:CharPtr!) -> CharPtr! {
//        for (int i = 0; str.get(i) != '\0'; i++) {
//        for (int j = 0; charset.get(j) != '\0'; j++) {
//        if (str.get(i) == charset.get(j)) {
//        return new CharPtr(str.chars, str.index + i);
//        }
//        }
//        }
//        return null;
        return nil
    }
    
    // find c in str
    public static func strchr(str:CharPtr!, c:Character) -> CharPtr! {
//        for (int index = str.index; str.chars[index] != 0; index++) {
//        if (str.chars[index] == c) {
//        return new CharPtr(str.chars, index);
//        }
//        }
//        return null;
        return nil
    }
    
    public static func strcpy(dst:CharPtr!, src:CharPtr!) -> CharPtr! {
//        int i;
//        for (i = 0; src.get(i) != '\0'; i++) {
//        dst.set(i, src.get(i));
//        }
//        dst.set(i, '\0');
//        return dst;
        return nil
    }
    
    public static func strcat(dst:CharPtr!, src:CharPtr!) -> CharPtr! {
//        int dst_index = 0;
//        while (dst.get(dst_index) != '\0') {
//        dst_index++;
//        }
//        int src_index = 0;
//        while (src.get(src_index) != '\0') {
//        dst.set(dst_index++, src.get(src_index++));
//        }
//        dst.set(dst_index++, '\0');
//        return dst;
        return nil
    }
    
    public static func strncat(dst:CharPtr!, src:Character, count:Int) -> CharPtr! {
//        int dst_index = 0;
//        while (dst.get(dst_index) != '\0') {
//        dst_index++;
//        }
//        int src_index = 0;
//        while ((src.get(src_index) != '\0') && (count-- > 0)) {
//        dst.set(dst_index++, src.get(src_index++));
//        }
//        return dst;
        return nil
    }
    
    public static func strcspn(str:CharPtr!, charset:CharPtr!) -> Int { //uint
//        //int index = str.ToString().IndexOfAny(charset.ToString().ToCharArray());
//        int index = ClassType.IndexOfAny(str.toString(), charset.toString().toCharArray());
//        if (index < 0) {
//        index = str.toString().length();
//        }
//        return index; //(uint)
        return 0
    }
    
    public static func strncpy(dst:CharPtr!, src:CharPtr!, length:Int) -> CharPtr! {
//        int index = 0;
//        while ((src.get(index) != '\0') && (index < length)) {
//        dst.set(index, src.get(index));
//        index++;
//        }
//        while (index < length) {
//        dst.set(index++, '\0');
//        }
//        return dst;
        return nil
    }
    
    public static func strlen(str:CharPtr!) -> Int {
//        int index = 0;
//        while (str.get(index) != '\0') {
//        index++;
//        }
//        return index;
        return 0
    }
    
    public static func fmod(a:Double, b:Double) -> Double { //lua_Number - lua_Number - lua_Number
//        float quotient = (int)Math.floor(a / b);
//        return a - quotient * b;
        return 0
    }
    
    public static func modf(a:Double, b:[Double]) -> Double { //lua_Number - out - lua_Number - lua_Number
//        b[0] = Math.floor(a);
//        return a - Math.floor(a);
        return 0
    }
    
    public static func lmod(a:Double, b:Double) -> Int64 { //lua_Number - lua_Number
//        return (long)a % (long)b;
        return 0
    }
    
    public static func getc(f:StreamProxy!) -> Int {
//        return f.ReadByte();
        return 0
    }
    
    public static func ungetc(c:Int, f:StreamProxy!) {
//        f.ungetc(c);
    }
    
    public static var stdout:StreamProxy! = StreamProxy.OpenStandardOutput()
    public static var stdin:StreamProxy! = StreamProxy.OpenStandardInput()
    public static var stderr:StreamProxy! = StreamProxy.OpenStandardError()
    public static let EOF:Int = -1;
    
    public static func fputs(str:CharPtr!, stream:StreamProxy!) {
//        StreamProxy.Write(str.toString()); //FIXME:
    }
    
    public static func feof(s:StreamProxy!) -> Int {
//        return (s.isEof()) ? 1 : 0;
        return 0
    }
    
    public static func fread(ptr:CharPtr!, size:Int, num:Int, stream:StreamProxy!) -> Int {
//        int num_bytes = num * size;
//        byte[] bytes = new byte[num_bytes];
//        try {
//        int result = stream.Read(bytes, 0, num_bytes);
//        for (int i = 0; i < result; i++) {
//        ptr.set(i, (char)bytes[i]);
//        }
//        return result/size;
//        }
//        catch (java.lang.Exception e) {
//        return 0;
//        }
        return 0
    }
    
    public static func fwrite(ptr:CharPtr!, size:Int, num:Int, stream:StreamProxy!) -> Int {
//        int num_bytes = num * size;
//        byte[] bytes = new byte[num_bytes];
//        for (int i = 0; i < num_bytes; i++) {
//        bytes[i] = (byte)ptr.get(i);
//        }
//        try {
//        stream.Write(bytes, 0, num_bytes);
//        }
//        catch (java.lang.Exception e) {
//        return 0;
//        }
//        return num;
        return 0
    }
    
    public static func strcmp(s1:CharPtr!, s2:CharPtr!) -> Int {
//        if (CharPtr.isEqual(s1, s2)) {
//        return 0;
//        }
//        if (CharPtr.isEqual(s1, null)) {
//        return -1;
//        }
//        if (CharPtr.isEqual(s2, null)) {
//        return 1;
//    }
//
//    for (int i = 0; ; i++) {
//    if (s1.get(i) != s2.get(i)) {
//    if (s1.get(i) < s2.get(i)) {
//    return -1;
//    }
//    else {
//    return 1;
//    }
//    }
//    if (s1.get(i) == '\0') {
//    return 0;
//    }
//    }
        return 0
    }
    
    public static func fgets(str:CharPtr!, stream:StreamProxy!) -> CharPtr! {
//        int index = 0;
//        try {
//        while (true) {
//        str.set(index, (char)stream.ReadByte());
//        if (str.get(index) == '\n') {
//        break;
//        }
//        if (index >= str.chars.length) {
//        break;
//        }
//        index++;
//        }
//        }
//        catch (java.lang.Exception e) {
//        
//        }
//        return str;
        return nil
    }
    
    public static func frexp(x:Double, expptr:[Int]!) -> Double { //out
//        expptr[0] = ClassType.log2(x) + 1;
//        double s = x / Math.pow(2, expptr[0]);
//        return s;
        return 0
    }
    
    public static func ldexp(x:Double, expptr:Int) -> Double {
//        return x * Math.pow(2, expptr);
        return 0
    }
    
    public static func strstr(str:CharPtr!, substr:CharPtr!) -> CharPtr! {
//        int index = str.toString().indexOf(substr.toString());
//        if (index < 0) {
//        return null;
//        }
//        return new CharPtr(CharPtr.plus(str, index));
        return nil
    }
    
    public static func strrchr(str:CharPtr!, ch:Character) -> CharPtr! {
//        int index = str.toString().lastIndexOf(ch);
//        if (index < 0) {
//        return null;
//        }
//        return CharPtr.plus(str, index);
        return nil
    }
    
    public static func fopen(filename:CharPtr!, mode:CharPtr!) -> StreamProxy! {
//        String str = filename.toString();
//        String modeStr = "";
//        for (int i = 0; mode.get(i) != '\0'; i++) {
//        modeStr += mode.get(i);
//        }
//        try {
//        StreamProxy result = new StreamProxy(str, modeStr);
//        if (result.isOK) {
//        return result;
//        }
//        else {
//        return null;
//        }
//        }
//        catch (java.lang.Exception e) {
//        return null;
//        }
        return nil
    }
    
    public static func freopen(filename:CharPtr!, mode:CharPtr!, stream:StreamProxy!) -> StreamProxy! {
//        try {
//        stream.Flush();
//        stream.Close();
//        }
//        catch (java.lang.Exception e) {
//
//        }
//        return fopen(filename, mode);
        return nil
    }
    
    public static func fflush(stream:StreamProxy!) {
//        stream.Flush();
    }
    
    public static func ferror(stream:StreamProxy!) -> Int {
//        //FIXME:
//        return 0; // todo: fix this - mjf
        return 0
    }
    
    public static func fclose(stream:StreamProxy!) -> Int {
//    stream.Close();
//    return 0;
        return 0
    }
    
    public static func tmpfile() -> StreamProxy! {
//        //new FileStream(Path.GetTempFileName(), FileMode.Create, FileAccess.ReadWrite);
//        return StreamProxy.tmpfile();
        return nil
    }
    
    public static func fscanf(f:StreamProxy!, format:CharPtr!, argp:Any!...) -> Int {
//        String str = StreamProxy.ReadLine(); //FIXME: f
//        return parse_scanf(str, format, argp);
        return 0
    }
    
    public static func fseek(f:StreamProxy!, offset:Int64, origin:Int) -> Int {
//        return f.Seek(offset, origin);
        return 0
    }
    
    
    public static func ftell(f:StreamProxy!) -> Int {
//        return (int)f.getPosition();
        return 0
    }
    
    public static func clearerr(f:StreamProxy!) -> Int {
//        //ClassType.Assert(false, "clearerr not implemented yet - mjf");
//        return 0;
        return 0
    }
    
    public static func setvbuf(stream:StreamProxy!, buffer:CharPtr!, mode:Int, size:Int) -> Int { //uint
//        //FIXME:stream
//        ClassType.Assert(false, "setvbuf not implemented yet - mjf");
//        return 0;
        return 0
    }
    
    //public static void memcpy<T>(T[] dst, T[] src, int length)
    //{
    //    for (int i = 0; i < length; i++)
    //    {
    //        dst[i] = src[i];
    //    }
    //}
    
    public static func memcpy_char(dst:[Character]!, offset:Int, src:[Character]!, length:Int) {
//        for (int i=0; i<length; i++) {
//        dst[offset+i] = src[i];
//        }
    }
    
    public static func memcpy_char(dst:[Character]!, src:[Character]!, srcofs:Int, length:Int) {
//        for (int i = 0; i < length; i++) {
//        dst[i] = src[srcofs+i];
//        }
    }
    
    //public static void memcpy(CharPtr ptr1, CharPtr ptr2, uint size)
    //{
    //    memcpy(ptr1, ptr2, (int)size);
    //}
    
    public static func memcpy(ptr1:CharPtr!, ptr2:CharPtr!, size:Int) {
//        for (int i = 0; i < size; i++) {
//        ptr1.set(i, ptr2.get(i));
//        }
    }
    
    public static func VOID(f:Any!) -> Any! {
        return f
    }
    
    public static let HUGE_VAL:Double = 0//FIXME: //System.
    public static let SHRT_MAX:Double = 0//FIXME:// Short.MAX_VALUE; //System.UInt16 - uint
    
    public static let _IONBF = 0
    public static let _IOFBF = 1
    public static let _IOLBF = 2
    
    public static let SEEK_SET = 0
    public static let SEEK_CUR = 1
    public static let SEEK_END = 2
    
    // one of the primary objectives of this port is to match the C version of Lua as closely as
    // possible. a key part of this is also matching the behaviour of the garbage collector, as
    // that affects the operation of things such as weak tables. in order for this to occur the
    // size of structures that are allocated must be reported as identical to their C++ equivelents.
    // that this means that variables such as global_State.totalbytes no longer indicate the true
    // amount of memory allocated.
    public static func GetUnmanagedSize(t:ClassType!) -> Int {
//        return t.GetUnmanagedSize();
        return 0
    }
}

